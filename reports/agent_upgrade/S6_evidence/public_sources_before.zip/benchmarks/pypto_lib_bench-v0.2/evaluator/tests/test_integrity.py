from __future__ import annotations

import json
import multiprocessing
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import integrity


def _commit_worker(protection, value, ready=None):
    if ready is not None:
        ready.wait(5)
    integrity.commit_records(Path(protection), {
        "budget": json.dumps({"used": value}).encode(),
        "events": json.dumps({"seq": value}).encode(),
    })


def _crash_commit_worker(protection, point):
    protection = Path(protection)
    write = integrity._write_manifest
    replace = integrity._replace_record
    atomic = integrity.file_tree.atomic_bytes
    count = 0

    def interrupted_write(root, manifest):
        if point == "before_manifest":
            os._exit(23)
        write(root, manifest)
        if point == "after_manifest":
            os._exit(23)

    def interrupted_replace(*args):
        nonlocal count
        replace(*args)
        count += 1
        if point == "after_first_record" and count == 1:
            os._exit(23)
        if point == "after_last_record" and count == 2:
            os._exit(23)

    def interrupted_backup(path, *args, **kwargs):
        if point == "before_backup" and Path(path).parent.name == "backups":
            os._exit(23)
        atomic(path, *args, **kwargs)
        if point == "after_backup" and Path(path).parent.name == "backups":
            os._exit(23)

    integrity._write_manifest = interrupted_write
    integrity._replace_record = interrupted_replace
    integrity.file_tree.atomic_bytes = interrupted_backup
    _commit_worker(protection, 1)


class FileIntegrityTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.assets = self.root / "assets"
        (self.assets / "nested/empty").mkdir(parents=True)
        (self.assets / "a.txt").write_bytes(b"original a")
        (self.assets / "nested/b.pt").write_bytes(b"formal fixture bytes")
        self.protection = self.root / "protection"

    def capture(self, **extra):
        return integrity.capture_protection(self.protection, {
            "assets": integrity.ProtectionRoot(self.assets, "fixed"), **extra,
        })

    def records(self):
        (self.root / "session.json").write_text('{"used": 0}')
        (self.root / "events.jsonl").write_text('{"seq": 0}')
        return {
            "budget": integrity.ProtectionRoot(self.root / "session.json", "records"),
            "events": integrity.ProtectionRoot(self.root / "events.jsonl", "records"),
            "final": integrity.ProtectionRoot(self.root / "final_result.json", "records"),
        }

    def values(self):
        return (json.loads((self.root / "session.json").read_text())["used"],
                json.loads((self.root / "events.jsonl").read_text())["seq"])

    def test_restore_content_empty_directories_types_and_extra_nodes(self):
        self.capture()
        (self.assets / "a.txt").unlink()
        (self.assets / "a.txt").mkdir()
        shutil.rmtree(self.assets / "nested")
        (self.assets / "nested").write_bytes(b"wrong type")
        (self.assets / "extra/deep").mkdir(parents=True)
        (self.assets / "extra/deep/new").write_text("rogue")
        observed = integrity.check_only(self.protection)
        self.assertIn("assets/nested/empty", observed.changed_paths)
        self.assertTrue((self.assets / "nested").is_file(), "check_only must not repair")
        restored = integrity.check_and_restore(self.protection)
        self.assertEqual(restored.changed_paths, restored.restored_paths)
        self.assertFalse(restored.passed, "repair must retain original failure evidence")
        self.assertEqual((self.assets / "a.txt").read_bytes(), b"original a")
        self.assertEqual((self.assets / "nested/b.pt").read_bytes(), b"formal fixture bytes")
        self.assertTrue((self.assets / "nested/empty").is_dir())
        self.assertFalse((self.assets / "extra").exists())
        self.assertTrue(integrity.check_only(self.protection).passed)

    def test_backups_are_independent_deduplicated_and_include_pt(self):
        (self.assets / "same.txt").write_bytes(b"original a")
        manifest = self.capture()
        entries = manifest["roots"]["assets"]["entries"]
        self.assertEqual(entries["a.txt"]["backup"], entries["same.txt"]["backup"])
        backup = self.protection / entries["a.txt"]["backup"]
        self.assertNotEqual(backup.stat().st_ino, (self.assets / "a.txt").stat().st_ino)
        self.assertEqual(backup.stat().st_nlink, 1)
        self.assertIn("nested/b.pt", entries)
        (self.assets / "a.txt").write_bytes(b"updated")
        self.assertEqual(backup.read_bytes(), b"original a")
        integrity.check_and_restore(self.protection)
        self.assertEqual((self.assets / "a.txt").read_bytes(), b"original a")

    def test_root_file_and_inner_links_never_touch_external_sentinel(self):
        self.capture()
        outside = self.root / "outside"
        (outside / "nested").mkdir(parents=True)
        sentinel = outside / "nested/b.pt"
        sentinel.write_bytes(b"external sentinel")
        for location in ("root", "directory", "file", "extra"):
            with self.subTest(location=location):
                if location == "root":
                    shutil.rmtree(self.assets)
                    self.assets.symlink_to(outside, target_is_directory=True)
                elif location == "directory":
                    shutil.rmtree(self.assets / "nested")
                    (self.assets / "nested").symlink_to(outside / "nested", target_is_directory=True)
                elif location == "file":
                    (self.assets / "nested/b.pt").unlink()
                    (self.assets / "nested/b.pt").symlink_to(sentinel)
                else:
                    (self.assets / "extra").symlink_to(outside, target_is_directory=True)
                self.assertFalse(integrity.check_only(self.protection).passed)
                integrity.check_and_restore(self.protection)
                self.assertEqual(sentinel.read_bytes(), b"external sentinel")
                self.assertTrue(integrity.check_only(self.protection).passed)
                self.assertFalse(self.assets.is_symlink())

    def test_ancestor_outside_protected_root_is_not_repaired_or_followed(self):
        holder = self.root / "holder"
        holder.mkdir()
        self.assets.rename(holder / "assets")
        integrity.capture_protection(self.protection, {
            "assets": integrity.ProtectionRoot(holder / "assets", "fixed"),
        })
        holder.rename(self.root / "old_holder")
        outside = self.root / "outside"
        (outside / "assets").mkdir(parents=True)
        sentinel = outside / "assets/a.txt"
        sentinel.write_text("external")
        holder.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(integrity.InfrastructureError) as failure:
            integrity.check_and_restore(self.protection)
        self.assertEqual(failure.exception.error_code, "infrastructure_error")
        self.assertEqual(failure.exception.report.unrecoverable_paths, ["assets"])
        self.assertEqual(sentinel.read_text(), "external")
        self.assertTrue(holder.is_symlink(), "cannot modify an unprotected ancestor")

    def test_corrupt_missing_and_linked_recovery_sources_fail_before_repair(self):
        manifest = self.capture()
        backup = self.protection / manifest["roots"]["assets"]["entries"]["a.txt"]["backup"]
        original = backup.read_bytes()
        (self.assets / "a.txt").write_text("changed")
        sentinel = self.root / "sentinel"
        sentinel.write_text("outside")
        for corruption in ("bytes", "missing", "link"):
            with self.subTest(corruption=corruption):
                if backup.exists() or backup.is_symlink():
                    backup.unlink()
                if corruption == "bytes":
                    backup.write_bytes(b"broken")
                elif corruption == "link":
                    backup.symlink_to(sentinel)
                with self.assertRaises(integrity.InfrastructureError) as failure:
                    integrity.check_and_restore(self.protection)
                self.assertIn("assets/a.txt", failure.exception.report.unrecoverable_paths)
                self.assertEqual((self.assets / "a.txt").read_text(), "changed")
                self.assertEqual(sentinel.read_text(), "outside")
        backup.unlink()
        backup.write_bytes(original)
        integrity.check_and_restore(self.protection)
        self.assertEqual((self.assets / "a.txt").read_bytes(), b"original a")

    def test_corrupt_manifest_and_invalid_paths_are_not_rebaselined(self):
        manifest = self.capture()
        manifest_path = self.protection / "manifest.json"
        original = manifest_path.read_bytes()
        invalid = []
        bad = json.loads(original)
        bad["roots"]["assets"]["entries"]["../escape"] = {"kind": "directory", "mode": 0o755}
        invalid.append(json.dumps(bad).encode())
        bad = json.loads(original)
        bad["roots"]["assets"]["path"] = "/"
        invalid.append(json.dumps(bad).encode())
        bad = json.loads(original)
        bad["roots"]["assets"]["entries"]["a.txt"]["backup"] = "../escape"
        invalid.append(json.dumps(bad).encode())
        for data in [b"not JSON", b"[]", *invalid]:
            with self.subTest(data=data):
                manifest_path.write_bytes(data)
                with self.assertRaises(integrity.InfrastructureError):
                    integrity.check_and_restore(self.protection)
                self.assertEqual(manifest_path.read_bytes(), data)
                self.assertEqual((self.assets / "a.txt").read_bytes(), b"original a")
        manifest_path.write_bytes(original)
        with self.assertRaises(integrity.InfrastructureError):
            self.capture()

    def test_permissions_cache_exclusions_and_expected_absence(self):
        records = self.records()
        original_mode = (self.assets / "a.txt").stat().st_mode & 0o777
        self.capture(**records)
        (self.assets / "__pycache__").mkdir()
        (self.assets / "__pycache__/ignored.pyc").write_bytes(b"cache")
        (self.assets / "nested/cache.pyo").write_bytes(b"cache")
        self.assertTrue(integrity.check_only(self.protection).passed)
        (self.root / "final_result.json").write_text("forged")
        (self.assets / "a.txt").chmod(0o777)
        integrity.check_and_restore(self.protection)
        self.assertFalse((self.root / "final_result.json").exists())
        self.assertEqual((self.assets / "a.txt").stat().st_mode & 0o777, original_mode)
        self.assertTrue((self.assets / "__pycache__/ignored.pyc").exists())
        integrity.commit_records(self.protection, {"final": b'{"status":"completed"}'})
        (self.root / "final_result.json").unlink()
        integrity.check_and_restore(self.protection, "records")
        self.assertEqual((self.root / "final_result.json").read_bytes(), b'{"status":"completed"}')

    def test_special_file_and_missing_root_are_restored_without_opening_fifo(self):
        self.capture()
        (self.assets / "a.txt").unlink()
        os.mkfifo(self.assets / "a.txt")
        integrity.check_and_restore(self.protection)
        self.assertEqual((self.assets / "a.txt").read_bytes(), b"original a")
        shutil.rmtree(self.assets)
        integrity.check_and_restore(self.protection)
        self.assertEqual((self.assets / "nested/b.pt").read_bytes(), b"formal fixture bytes")
        self.assertTrue((self.assets / "nested/empty").is_dir())

    def test_groups_restore_only_selected_assets(self):
        self.capture(**self.records())
        (self.assets / "a.txt").write_text("changed")
        (self.root / "session.json").write_text("forged")
        report = integrity.check_and_restore(self.protection, {"records"})
        self.assertEqual(report.restored_paths, ["budget"])
        self.assertEqual(self.values(), (0, 0))
        self.assertEqual((self.assets / "a.txt").read_text(), "changed")
        with self.assertRaises(integrity.InfrastructureError):
            integrity.check_only(self.protection, {"unknown"})

    def test_committed_budget_events_are_restored_to_latest_values(self):
        self.capture(**self.records())
        _commit_worker(self.protection, 1)
        self.assertEqual(self.values(), (1, 1))
        (self.root / "session.json").write_text('{"used":0}')
        (self.root / "events.jsonl").write_text('{"seq":0}')
        integrity.check_and_restore(self.protection, "records")
        self.assertEqual(self.values(), (1, 1))
        _commit_worker(self.protection, 2)
        (self.root / "session.json").unlink()
        integrity.check_and_restore(self.protection, "records")
        self.assertEqual(self.values(), (2, 2))

    def test_commit_rejects_dirty_records_unregistered_paths_and_asset_updates(self):
        self.capture(**self.records())
        original = (self.protection / "manifest.json").read_bytes()
        for updates in ({"assets/a.txt": b"bad"}, {"unknown": b"bad"},
                        {"budget/../escape": b"bad"}, {"budget": "not bytes"}):
            with self.subTest(updates=updates), self.assertRaises(integrity.InfrastructureError):
                integrity.commit_records(self.protection, updates)
        (self.root / "session.json").write_text('{"used":999}')
        with self.assertRaises(integrity.InfrastructureError):
            _commit_worker(self.protection, 1)
        self.assertEqual((self.protection / "manifest.json").read_bytes(), original)
        integrity.check_and_restore(self.protection, "records")
        _commit_worker(self.protection, 1)
        self.assertEqual(self.values(), (1, 1))

    def test_process_crash_at_every_commit_boundary_recovers_consistent_records(self):
        context = multiprocessing.get_context("fork")
        for point in ("before_backup", "after_backup", "before_manifest", "after_manifest",
                      "after_first_record", "after_last_record"):
            with self.subTest(point=point), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                (root / "budget").write_text('{"used":0}')
                (root / "events").write_text('{"seq":0}')
                protection = root / "protection"
                integrity.capture_protection(protection, {
                    "budget": integrity.ProtectionRoot(root / "budget", "records"),
                    "events": integrity.ProtectionRoot(root / "events", "records"),
                })
                process = context.Process(target=_crash_commit_worker, args=(str(protection), point))
                process.start()
                process.join(5)
                if process.is_alive():
                    process.kill()
                    process.join()
                    self.fail("interrupted commit left its lock held")
                self.assertEqual(process.exitcode, 23)
                before_recovery = (
                    json.loads((root / "budget").read_text())["used"],
                    json.loads((root / "events").read_text())["seq"],
                )
                if point == "after_first_record":
                    self.assertEqual(json.loads((root / "budget").read_text())["used"], 1)
                    self.assertEqual(json.loads((root / "events").read_text())["seq"], 0)
                integrity.check_and_restore(protection, "records")
                expected = 0 if point in {"before_backup", "after_backup", "before_manifest"} else 1
                self.assertEqual(json.loads((root / "budget").read_text())["used"], expected)
                self.assertEqual(json.loads((root / "events").read_text())["seq"], expected)
                self.assertTrue(integrity.check_only(protection).passed)
                print(f"commit crash boundary={point}, exit=23, before={before_recovery}, "
                      f"recovered=({expected}, {expected})", flush=True)
                process.close()

    def test_concurrent_process_commits_are_serialized(self):
        self.capture(**self.records())
        context = multiprocessing.get_context("fork")
        ready = context.Event()
        processes = [context.Process(target=_commit_worker, args=(str(self.protection), value, ready))
                     for value in (41, 73)]
        for process in processes:
            process.start()
        ready.set()
        for process in processes:
            process.join(5)
            if process.is_alive():
                process.kill()
                process.join()
                self.fail("concurrent commit deadlocked")
            self.assertEqual(process.exitcode, 0)
            process.close()
        used, sequence = self.values()
        self.assertIn(used, {41, 73})
        self.assertEqual(used, sequence)
        self.assertTrue(integrity.check_only(self.protection).passed)

    def test_register_new_root_cannot_replace_existing_authority(self):
        self.capture()
        snapshot = self.root / "snapshot"
        snapshot.mkdir()
        (snapshot / "candidate.py").write_text("snapshot")
        (snapshot / "candidate.py").chmod(0o444)
        roots = {"snapshot": integrity.ProtectionRoot(snapshot, "snapshots", readonly=True)}
        integrity.register_roots(self.protection, roots)
        with self.assertRaises(integrity.InfrastructureError):
            integrity.register_roots(self.protection, roots)
        (snapshot / "candidate.py").chmod(0o644)
        (snapshot / "candidate.py").write_text("modified")
        integrity.check_and_restore(self.protection, "snapshots")
        self.assertEqual((snapshot / "candidate.py").read_text(), "snapshot")
        self.assertEqual((snapshot / "candidate.py").stat().st_mode & 0o777, 0o444)

    def test_record_tree_new_files_and_empty_directories(self):
        records = self.root / "records"
        (records / "empty").mkdir(parents=True)
        self.capture(records=integrity.ProtectionRoot(records, "records"))
        integrity.commit_records(self.protection, {"records/action/result.json": b"{}"})
        self.assertEqual((records / "action/result.json").read_bytes(), b"{}")
        shutil.rmtree(records)
        integrity.check_and_restore(self.protection, "records")
        self.assertTrue((records / "empty").is_dir())
        self.assertEqual((records / "action/result.json").read_bytes(), b"{}")

    def test_overlapping_roots_and_control_trees_are_rejected(self):
        for roots in (
            {"asset": integrity.ProtectionRoot(self.assets, "fixed"),
             "nested": integrity.ProtectionRoot(self.assets / "nested", "fixed")},
            {"control": integrity.ProtectionRoot(self.root, "fixed")},
        ):
            with self.subTest(roots=roots), tempfile.TemporaryDirectory(dir=self.root) as temporary:
                with self.assertRaises(integrity.InfrastructureError):
                    integrity.capture_protection(Path(temporary) / "protection", roots)


if __name__ == "__main__":
    unittest.main()
