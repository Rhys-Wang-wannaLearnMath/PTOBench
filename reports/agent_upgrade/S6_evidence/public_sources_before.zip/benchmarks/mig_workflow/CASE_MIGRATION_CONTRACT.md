# Case migration contract

This document is the common engineering contract for all six migration
stages. Stage documents define who may edit each path. This document defines
what a correct migrated Case means.

## 1. Case-specific analysis, not template conversion

Inspect the actual source Case before deciding its v0.2 shape. At minimum read:

- v0.1 metadata, analysis, official source, Ref, Candidate, Oracle, comparator,
  fixtures, and certification records;
- the selected official/upstream implementation and every local dependency
  reachable from its evaluated entry;
- official TensorSpec/ScalarSpec or input builder, golden function, runner,
  CLI defaults, seed behavior, RunConfig, environment, and topology;
- mutation/state behavior and the exact outputs used for correctness.

Do not infer one Case from a related Case. Do not copy shapes, tolerances,
Fixture distributions, environment values, or helper files merely because the
names look similar.

Choose one coherent official source:

- use current upstream when it still represents the intended workload and can
  be migrated by interface-only changes; or
- preserve the frozen v0.1 source when upstream changed the workload itself.

Record the source path/version and reason in `handoff.md`. Do not mix workload
semantics from one version with fixture or golden logic from another.

The workload-source choice does not freeze the comparator at the same revision.
After choosing the coherent workload, reconcile its comparator with current
upstream under [COMPARATOR_POLICY.md](COMPARATOR_POLICY.md). Adopt every latest
upstream semantic change whose assumptions already hold without changing the
fixed workload; keep the selected-source behavior for changes that depend on a
different source, ABI, Fixture, golden, dtype, shape/layout, or state contract.

## 2. Split real preset contracts

A source file may define several named model presets. Create one v0.2 Case per
preset when the presets are part of the selected official configuration set,
produce distinct fixed shapes, dtypes, state layouts, algorithm semantics, or
runtime contracts, and the same source can instantiate each preset by binding
configuration only. The source may select one preset as its CLI/default import;
that default does not collapse other complete supported presets into one Case.

Do not split for unused partial config objects, aliases, helper constants, or a
preset that requires changing the algorithm rather than binding configuration.
Stage 1 must build a preset coverage matrix containing every named preset, its
definition path, source binding/default, entry, builder/runner evidence, ABI,
and `split`, `exclude`, or `blocked` decision. For every resulting Case, record
its Case ID, selected configuration, entry, ABI, fixed Fixture-input bindings,
comparator, and environment independently. Stage 2 must bind the preserved source to that
Case's selected public config without editing the byte-exact official copy.

Name every member of a split sibling series with the same explicit preset
scheme, for example `base_demo`, `base_flash`, and `base_pro`. A source default
such as FLASH does not keep the unsuffixed `base` name while its siblings use
suffixes. The canonical directory, `case_id`, description, dynamic module-load
identity, config comments, and generated certification identity must all use
the selected result Case ID consistently.

## 3. Canonical layout

Required files, with optional dependency files added only when actually used:

```text
cases/<family>/<case>/
├── case.json
└── public/
    ├── config.py
    ├── comparator.json
    └── candidate_seed/
        ├── <case.json module>
        └── ...

sealed_assets/<family>/<case>/
├── official/
│   ├── original.py
│   ├── original_config.py       # when the source has a config dependency
│   ├── source_provenance.json
│   └── ...                      # other real source dependencies only
├── fixture_builder.py
├── fixture_policy.json
├── ref/
│   ├── ref_npu.py
│   └── ...
├── oracle/
│   ├── ref_cpu.py
│   └── ...
├── evaluate.py
├── fixtures/fixture_000/
├── ref_performance.json
└── certification.json
```

Do not manufacture `kernels.py`, `schedule.py`, `helpers/`, or any other
multi-file structure. Preserve a multi-file closure only when this Case really
needs it. No symlinks or imports into another Case are allowed.

`official/original.py` and every preserved source dependency are byte-exact
copies, not current-API adaptations. Preserve a source's complete external
configuration dependency as `official/original_config.py`; do not trim it to
the selected preset and do not call it `official/config.py`, which is ambiguous
with the fixed public contract. If the source is self-contained and has no
config dependency, do not invent `original_config.py`. In particular, do not
extract embedded constants from `original.py`, copy the public fixed config, or
synthesize a configuration snapshot merely to make the official layout uniform.

Every official tree includes `source_provenance.json` with schema version,
authority, repository-relative source paths, SHA-256 for each source and frozen
copy, the selection rationale, and a `dependencies` array (empty when the
source is self-contained). Interface compatibility belongs in the Fixture
adapter or runtime implementation, never in the preserved official files.

The canonical `cases/` files and `sealed_assets/` are authoritative. Files in a
Candidate workspace's `.benchmark_context/` are read-only snapshots for the
Agent; editing or validating only those snapshots does not change the Case and
is not migration evidence.

## 4. Public fixed configuration

`public/config.py` is the single readable source of fixed evaluation values.
Candidate, NPU Ref, and evaluator import the same file. Include every fixed
value that affects the contract:

- input/output/state shapes and layouts;
- dtypes;
- batch, sequence, hidden/head dimensions and other fixed sizes;
- scalar defaults and fixed algorithm semantics;
- cache capacity, rank, epsilon, quantization semantics, and necessary derived
  dimensions.

Do not include tunable implementation choices such as tiles, chunks, blocks,
pipelines, buffering, scheduling, or launch decomposition. Those remain in the
Ref/Candidate implementation and become Agent-editable after publication.

Use the simplest representation suitable for the Case when the source is
self-contained. When the source has a real separate complete config dependency,
preserve its readable organization in each split Case: the config class, exactly
one selected named preset, `CASE_CONFIG`, and then fixed operator/deployment
bindings. This intentionally retains the selected preset's coherent useful
surface beyond only the fields Candidate currently imports, while excluding
other sibling presets and implementation tuning knobs. Do not add a second
summary that merely duplicates the final operator constants.

For every fixed derived value in the selected Case, preserve its meaningful
source operands and expression. For example, retain `DECODE_BATCH`,
`DECODE_SEQ`, and `DECODE_TOKENS = DECODE_BATCH * DECODE_SEQ` instead of
folding the last value to `8`. This is source-structure preservation, not a
license to copy derivation branches belonging only to prefill, cache, MoE, EP,
quantization, or another workload.

## 5. Current environment and RunConfig contract

The migration target is the repository's current official PyPTO/runtime/CANN
environment, not the API shape that happened to exist in v0.1. Before adapting
code, inspect the current installed `pypto.runtime.RunConfig` signature and the
current upstream runner/CI configuration. At the current benchmark baseline,
the supported RunConfig fields are:

```text
arch
execution_mode
device_id
rtol
atol
strategy
dump_passes
save_kernels
save_kernels_dir
codegen_only
enable_chip_swimlane
enable_dump_args
enable_pmu
enable_dep_gen
enable_scope_stats
compile_profiling
diagnostic_phase
disabled_diagnostics
golden_data_dir
aicpu_thread_num
ring_task_window
ring_heap
ring_dep_pool
distributed_config
analyze_auto_scopes_for_deps
memory_planner
dump_ptoas_passes
platform
```

This is a list of currently accepted fields, not a requirement to set all of
them. Use only fields required by the actual Case or by a selected profiling
mode. `ring_task_window`, `ring_heap`, and `ring_dep_pool` are ordinary
Case-specific runtime resources when needed. `distributed_config` and typed
enum/diagnostic objects require the evaluator's current Python construction and
must not be represented as made-up JSON strings.

The evaluator currently builds a RunConfig from:

```text
environment profile runtime/defaults
+ case.json runtime overrides
+ fixed profiling-mode settings
```

`case.json.runtime` may contain only JSON values accepted by the current
evaluator and RunConfig constructor. It is part of the fixed evaluation
contract, not a place for Agent tuning knobs. Benchmark warmup/round counts
come from the environment profile, with an optional Case `benchmark` override
only when the workload contract genuinely requires different fixed counts.
Record and justify such an override; it is benchmark policy, never an editable
tuning choice.

When current interfaces differ from v0.1, make the smallest interface-only
adaptation: update import paths, renamed arguments, runner invocation, current
TensorSpec/ScalarSpec construction, or RunConfig field spelling/types. Do not
change algorithm, topology, tensor shapes/layouts, dtypes, state semantics,
input distribution, comparator tolerance, or workload decomposition. Record
each old/new API symbol and why the adaptation is semantics-preserving. If this
would require a broad rewrite or change workload meaning, stop and report it.

An environment profile contains the Python interpreter, setup scripts, exported
variables, platform/device and shared benchmark defaults. Reuse an existing
profile only when it matches the Case. Otherwise create a new profile named for
this Case or platform under `benchmarks/pypto_lib_bench-v0.2/environments/`.
Do not alter a shared profile merely to make one Case pass. Reference a new
profile from that Case's `case.json.environment`, use current official paths and
values, and test it with init, clean evaluate and profiling attempts.

## 6. Comparator JSON

Every Case follows [COMPARATOR_POLICY.md](COMPARATOR_POLICY.md). That policy is
the single authority for current-upstream discovery, grouped semantic diffs,
`ADOPT`/`KEEP_SELECTED` decisions, JSON schema, evaluator execution, and stale
certification handling.

Every Case uses the same public schema, but each sealed Case evaluator owns the
parsing, strict validation, callback construction, and PASS/FAIL execution for
the methods actually declared by that Case. The intentional local duplication
keeps comparator growth out of common infrastructure.

```json
{
  "schema_version": 1,
  "outputs": {
    "out": {
      "method": "allclose",
      "rtol": 0.003,
      "atol": 0.003
    }
  }
}
```

Supported core methods are `allclose`, `ratio_allclose`, and `exact`.
`ratio_allclose` additionally declares `max_error_ratio`. Every correctness
output must have one explicit complete rule; do not rely on an implicit
`default`, mix `kind` and `method`, add ignored fields, or hide semantics in
evaluator constants. Every method declared by the Case must be implemented and
strictly validated inside that Case's `sealed_assets/.../evaluate.py`; standard
methods not declared by the current JSON are optional local compatibility code
and are not part of the active policy. Do not introduce a common comparator
factory, shared method registry, or family-level helper.

Use `custom` only for a genuinely non-elementwise equivalence rule and name the
Case-local comparator. Derive tolerances from official compare behavior, the
official runner, or an already certified v0.1 contract. Never loosen tolerance
because a migrated implementation currently fails.

## 7. Official source and Fixture builder

Keep the complete selected official source and all its required local helpers
under `sealed/official/`. `fixture_builder.py` is a thin Case-local adapter to
the selected official input/spec/golden construction. It must not copy an old
fixture and pretend to generate a new one.

Historical official builders may use `TensorSpec(is_output=...)`, while the
current Fixture API derives output membership from `case.json` and entry
annotations. In that case, the Fixture builder uses
`evaluator/common.py::load_official_fixture_specs(...)`. The helper temporarily
accepts the legacy flag, optionally installs a Case-built `config_alias`, loads
the byte-exact builder, seeds it, and restores global module/API state. The
alias must be derived from `public/config.py`, not from hidden constants.

This compatibility is deliberately narrow. It must not change TensorSpec
names, shapes, dtypes, initializers, scalar defaults, RNG order, output
membership, distributions, state, or golden semantics, and it must not be used
for Ref/Candidate or runtime adaptation. Inspect the actual historical/current
API difference before using it. A new shared compatibility requirement is an
infrastructure change outside a Case migration; report it rather than silently
expanding the common helper from Stage 2.

Each Case has exactly one deterministic formal Fixture:

```text
fixtures/fixture_000/
```

Preserve official distributions, ranges, dtypes, shapes, scalar defaults, seed
behavior, and initial mutable state. `fixture_policy.json` has schema version 1
and exactly one deterministic seed mapping, `fixture_seeds.fixture_000`. The
current generator calls the Case-local adapter as
`build(case_dir, sealed, case, seed)`; fixed builder inputs must come from the
canonical public config or Case contract, not from an undocumented second
argument channel. Record how each official builder input is bound in the
handoff. A fixed config, official builder, source version, ABI, or Fixture
policy change invalidates the generated Fixture. A comparator-only change
leaves deterministic Fixture inputs unchanged but invalidates cached outputs as
certified evidence, certification, Ref performance, and every downstream
result/workspace; follow the comparator policy's regeneration rules.

All Cases evaluate one invocation only. A stateful Case still captures the
official initial state and restores it before CPU Oracle, Ref correctness,
Candidate correctness, every warmup, and every measured launch. It does not
carry state between measured launches.

The state fields must agree: a stateless Case declares `behavior: none`, an
empty `initial_state`, and `restore_before_each_launch: false`; a mutating Case
declares the complete mutable input set and `restore_before_each_launch: true`.
The current shared lifecycle derives reset behavior from `behavior`, so an
inconsistent descriptive flag is a contract defect, not alternate behavior.

## 8. NPU Ref, Candidate, and multi-file closure

Implement and certify the NPU Ref before creating Candidate Seed. Preserve the
complete entry call closure, including Python modules, generated-source inputs,
tables, and other local runtime assets actually used by the entry.

When any official, Fixture, Ref/Candidate, or Oracle closure has more than one
local file or runtime resource, every Stage must also follow
[MULTI_FILE_MIGRATION.md](MULTI_FILE_MIGRATION.md). Its per-file closure ledger,
global Case-ID collision check, import-root/resource rules, normalized
manifests, and isolation evidence are required acceptance evidence rather than
optional documentation. A new migration must not overwrite an existing
canonical Case ID; this workflow has no implicit supersession mechanism.

Classify every source-side file before placing it:

| Class | Examples | Destination |
| --- | --- | --- |
| Agent-editable NPU implementation | entry, kernels, schedules, implementation helpers, required lookup/source assets | both `sealed/ref/` and `public/candidate_seed/` |
| Fixed public evaluation contract | shapes, dtypes, scalar defaults, fixed semantics, comparator rules | `public/config.py` or `public/comparator.json` only |
| Sealed validation implementation | official source, Fixture builder, CPU golden/Oracle, Case evaluator | the corresponding sealed directory only |
| Generated or local debris | logs, build trees, temporary dumps, compiler output | nowhere in a canonical Case |

Canonical `__pycache__/` directories and `*.pyc` files are permitted and are
not migration defects. They are ignored by Ref/Candidate closure comparisons
and acceptance cleanliness checks. All other generated debris remains
forbidden.

“Multi-file” means the real closure discovered for this Case. It can contain
sibling modules, packages with `__init__.py`, data tables, templates, or source
fragments read at runtime. It does not imply prescribed names such as
`kernels.py` or `helpers/`. Trace ordinary imports, package/relative imports,
imports inside functions, `importlib`, and file opens relative to `__file__` or
the working directory. Preserve the relative layout needed by those accesses.

The complete editable implementation must exist in Ref as well as Candidate:
Ref is the certified baseline that must run independently, while Candidate is
the Agent-editable snapshot. Do not make either tree import implementation
files from the other tree, the official tree, the Oracle, another Case, or a
developer checkout outside the Case.

After certification, Candidate Seed is a snapshot of the final Ref tree:

```text
sealed/ref/ref_npu.py  -> public/candidate_seed/<case.json module>
sealed/ref/<other>     -> public/candidate_seed/<other>
```

Only the entry filename and imports required by that rename may differ. All
other implementation files, constants, and tuning defaults must initially be
identical. Copy real files, not symlinks. Candidate must not import sealed Ref
files or use another Case's implementation.

For a multi-file tree:

- copy directories recursively, including required `__init__.py` and non-Python
  runtime resources;
- keep every helper/resource at the same relative path in Ref and Candidate;
- compare the two file manifests after mapping `ref_npu.py` to the declared
  Candidate module;
- compare all same-path implementation files byte-for-byte;
- inspect and record the minimal entry-file/import diff caused by the rename;
- import and execute through `common.load_ref` and `common.load_candidate`, not
  by adding repository-wide paths or relying on the caller's current directory.

Candidate Seed contains only the evaluated PyPTO implementation closure. It
must not contain TensorSpec/input generation, CPU golden, Fixture data,
expected outputs, Ref caches, certification, `RunConfig`, profiling harness,
standalone test CLI, or unused official test helpers. Do not delete an oddly
named helper if it is actually reachable from the evaluated entry.

### 8.1 Optional human-approved Ref repair

Strict Stage 3 does not relax the preservation rules above. If it stops with a
reproducible NPU Ref correctness failure, a human may explicitly invoke the
optional Repair branch. The branch is never selected automatically and is not
ordinary owner-directed rework.

The branch may propose a limited internal lowering or topology deviation only
to restore the selected workload's observable semantics on the current
official toolchain. Public ABI, shapes/layouts, dtypes, state, input
distribution, Oracle semantics, Fixture inputs, comparator, official source,
and environment/version remain fixed. Comparator or Oracle changes intended to
match a failing Ref are forbidden. Contract, Fixture, Oracle, evaluator,
interface-only, and infrastructure defects return to their normal owners.

A successful Repair run is not approval. The orchestrator records the strict
Stage 3 failure, pre/post Ref manifests and patch, protected canonical hashes,
fresh certification/performance evidence, and toolchain analysis in a
hash-bound proposal. It then stops. Only a separate explicit human approval
command may create `approval.json` and permit Stage 4 to start. Any bound-file
drift invalidates the approval.

Stages 4-6 accept only the exact approved Ref deviation. They still require
Ref/Candidate publication identity, clean closure, comparator/certification
fidelity, fresh clean evaluation, every profiling attempt, and final
acceptance. Stage 6 verifies the approval and evaluates the documented public
semantic invariants; it must not reject the exact approved patch solely because
its internal topology differs. Any unapproved or additional semantic/topology
change remains a Stage 3 defect.

## 9. CPU Oracle

The Oracle is an independent CPU correctness implementation used only by
`prepare-ref`. Preserve its full real dependency closure under `sealed/oracle/`;
multi-file Oracle code is supported and must load through
`evaluator.common.load_oracle` with the Oracle directory as its import root.

The Oracle must not call the Candidate or NPU Ref, import their helper tree, or
derive expected output by running the code under test. It may reuse the chosen
official CPU golden logic and its own local helpers. Oracle-only dependencies
remain sealed and must never be copied into Candidate Seed.

## 10. Case evaluator and common workflow

The shared `evaluator/workflow.py` owns lifecycle mechanics:

```text
fixture iteration -> state restoration -> correctness -> output capture
-> warmup -> measured launches -> result/certification output
```

Case-local `evaluate.py` owns Case-specific ABI behavior and the Case-local
comparator execution boundary:

- TensorSpec/ScalarSpec construction;
- entry/program loading;
- official runner invocation (`run`, `run_jit`, or other current API);
- output/state capture;
- construction and execution of the declared comparator;
- CPU Oracle callback.

It reads the canonical comparator JSON itself and locally owns strict schema and
output validation, dispatch for every method declared by that JSON, callback
construction, and PASS/FAIL execution. It must implement and test every active
method and parameter. It may retain unused standard-method branches, but they
are not required, need no acceptance coverage, and must not affect the active
callbacks. Undeclared custom behavior is forbidden. The local implementation
may repeat standard-method logic used by another Case; it must not delegate
comparator semantics to `common.py`, `workflow.py`, a family helper, or a
registry. It also must not hard-code a second set of tolerance/ratio values
outside JSON. `prepare-ref`
certification binds the comparator SHA-256, and Candidate evaluation rejects
stale certification before using cached Ref outputs; hashing and stale-evidence
rejection remain shared lifecycle responsibilities, not comparison semantics.

It exposes `prepare_ref(...)` and `evaluate_candidate(...)` and delegates the
loop to the common workflow. Load Ref, Oracle, and Candidate through the common
load helpers so local multi-file imports resolve consistently. Do not add a
family-specific shared helper, family branch, `official_replay.py`, abstract
class hierarchy, registry, or evaluator-side shape/entry special case.

Use official current PyPTO run/validate APIs and RunConfig semantics. Interface
adaptation is allowed; changing workload algorithm, topology, shapes, or
correctness semantics is not.

## 11. Environment and profiling

Declare the actual environment profile in `case.json`. Case-specific exports
belong in the corresponding v0.2 environment configuration and are loaded by
the Bench CLI before Case modules. A migrated Case must not require the caller
to source an undocumented shell script manually.

Do not edit shared evaluator infrastructure or an existing environment profile
used by other Cases within a Case migration. Stage 2 may create a new
Case-specific environment JSON when Stage 1 demonstrates that no existing
profile fits. Stage 3 may narrowly complete that new profile, or add current
RunConfig fields to this Case's `case.json.runtime`, when real execution provides
the evidence. Report any change that would affect shared infrastructure to its
owner instead.

Migration qualification must attempt every profiling mode supported by the
current benchmark, not merely one representative mode. The authoritative list
is `evaluator/profile_modes.py:PROFILE_MODES`; it currently contains:

```text
runtime
hardware
compile
```

The migration workspace should expose the complete supported set in
`.benchmark_context/profiling_modes.json`. If a mode is not exposed, record
`UNSUPPORTED` with the reason; do not silently omit it. Agent-facing workspaces
still mention only modes actually exposed by `bench init`.

Stage 4 and Stage 6 must use `bench init` from the canonical Candidate Seed.
Do not use `bench fork`: fork is for optimization branches and copies the
parent's current editable implementation, so it cannot prove that the published
seed itself is valid. Verify the new workspace binding names the expected Case
and that `.benchmark_context/starting_point/` matches the initialized Candidate
tree before any command changes it.

After clean `bench evaluate`, run once per supported mode:

```bash
bench profile runtime <workspace> --result <runtime-result.json>
bench profile hardware <workspace> --result <hardware-result.json>
bench profile compile <workspace> --result <compile-result.json>
```

Each profiling command uses the `correctness` phase declared by
`PROFILE_MODES`. Profiling qualification is a one-dispatch availability and
artifact check, not a performance measurement: do not run profiling warmups or
measured rounds and do not require timing samples. A passing result must still
contain a passed correctness run and the mode's nonempty diagnostics.

Both the initial and final clean evaluations use `phase=all` (the CLI default),
must report `phase: all`, and must contain the configured positive performance
samples in addition to passing correctness. A correctness-only clean result is
useful debugging evidence but is not publication or acceptance evidence.

Run clean evaluation and all profiling modes sequentially. They share the
selected device and may use incompatible diagnostic state; parallel device
commands can turn a valid hardware profile into a PMU permission/resource
failure and are invalid migration evidence.

For every exposed mode, require all of the following rather than command exit
alone:

- result JSON exists, is nonempty and parseable;
- `case_id` is the expected Case;
- `profiling_mode` is the requested mode;
- `official_score` is `false` and `diagnostic_only` is `true`;
- top-level `verdict` and every run's `passed` field indicate success;
- `artifact_dir` resolves to that workspace's
  `.benchmark_outputs/<mode>/`, separate from `clean` and other modes;
- the mode directory/build output contains the diagnostics emitted by the
  current PyPTO runtime/compiler for that mode. Do not invent a universal
  mode-specific filename when the official tool does not define one.

An explicit `--result` may place the summary JSON under the Stage task
directory, but it does not relocate compiler or diagnostic artifacts. Those
remain under the workspace's `.benchmark_outputs/<mode>/`; `build_dir` must
resolve inside that mode's artifact tree.

A mode that compiles but fails during collection is `FAIL`, not
`UNSUPPORTED`. Use `UNSUPPORTED` only with clear evidence that the current
Case/runtime/platform cannot provide that diagnostic, such as an unavailable
hardware PMU or an unimplemented compiler feature. If the same mode fails for
unrelated known-good Cases, assign it to infrastructure; otherwise assign Case
evaluator/RunConfig incompatibility to Stage 3 and an incorrect Candidate
snapshot to Stage 4.

Profiling never determines the official score. After all profiling attempts,
run clean `bench evaluate` again in the same fresh workspace and require
`profiling_mode: clean`, `official_score: true`, and `diagnostic_only: false`.
This final clean run is the accepted score and proves profiling settings did
not leak into evaluation.

Profiling status does not replace the clean correctness gate. A Case may be
recorded as migration `PASS`/`READY` when clean evaluate passes and one or more
profiling modes are `UNSUPPORTED`. The result and handoff must then state the
limitation concisely, for example:

```text
Profiling: PARTIAL
runtime: PASS
hardware: UNSUPPORTED - PMU unavailable on the target platform
compile: PASS
```

An unexpected profiling `FAIL` is recorded with evidence and an owner; it must
not be relabeled `UNSUPPORTED`. `READY` means clean evaluation is valid, not
that every diagnostic mode is available.

## 12. Required commands and acceptance

Use the repository-local CLI:

```bash
benchmarks/pypto_lib_bench-v0.2/bench prepare-ref <family.case>
benchmarks/pypto_lib_bench-v0.2/bench init <family.case> --out <fresh-workspace>
benchmarks/pypto_lib_bench-v0.2/bench evaluate <fresh-workspace> --result <result.json>
```

Run all modes declared by `PROFILE_MODES` using their exposed
`bench profile ...` commands. Never reuse an optimization workspace for final
seed acceptance.

A Case is `READY` only when:

- source, contract, ABI, fixture, dependencies, state, environment, and
  comparator pass independent inspection;
- `prepare-ref` has certified Oracle/Ref agreement and produced cached Ref
  output and the clean Ref baseline for `fixture_000`;
- a fresh workspace from the unmodified Candidate Seed passes clean evaluate;
- every supported profiling mode was attempted and has an explicit result,
  followed by a second clean evaluation.

The initial and final clean records must both be `phase=all`. Any profiling
`FAIL` prevents `READY`; only an evidence-backed `UNSUPPORTED` mode may coexist
with `PASS`/`READY` and `Profiling: PARTIAL`.

Environment/device/compiler unavailability is `BLOCKED`, not correctness
success. Contract or implementation errors are `INVALID` and return to their
owning stage.
