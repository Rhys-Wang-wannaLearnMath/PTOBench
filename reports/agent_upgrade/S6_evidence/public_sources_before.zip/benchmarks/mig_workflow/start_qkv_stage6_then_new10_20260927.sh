#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_qkv_stage6_then_new10_20260927.log"
exec >>"$LOG" 2>&1

echo "===== qkv continuation $(date -Is) ====="
MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.prefill_qkv_proj_rope_v1 --resume
qkv_rc=$?
echo "QKV_CONTINUATION_EXIT=$qkv_rc $(date -Is)"

queue_rc=0
if ((qkv_rc == 0)); then
  while IFS= read -r case_id; do
    [[ -z "$case_id" || "$case_id" == \#* ]] && continue
    echo "CASE $case_id START $(date -Is)"
    MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh \
      --case "$case_id" --resume
    rc=$?
    echo "CASE $case_id EXIT=$rc $(date -Is)"
    ((rc == 0)) || queue_rc=1
  done < benchmarks/mig_workflow/serial_queue_new10_20260927.txt
else
  queue_rc=1
  echo "QKV continuation failed; new10 queue was not started"
fi
echo "QKV_STAGE6_NEW10_EXIT=$queue_rc"
exit "$queue_rc"
