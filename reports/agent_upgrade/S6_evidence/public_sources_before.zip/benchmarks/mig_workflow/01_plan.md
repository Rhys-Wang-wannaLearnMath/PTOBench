# Queue and execution policy

The queue comes from
`benchmarks/mig_data/case_migration_inventory.md`. Inventory batch number and
row order determine priority. The runner defaults to one source Case and never
runs source Cases in parallel.

Each source Case uses six sequential Codex sessions:

```text
analyze -> contract -> implement-certify -> publish -> closure-audit -> accept
```

Stages 1, 2, 3, 5, 6 and Repair start with `gpt-6-astra` at `low` reasoning.
Both models receive the original Stage prompt and formal Skill. No bootstrap
Skill, planning instruction, tool quota, or completion marker is injected.
The external runner observes two successfully completed command tools and no
active tools, interrupts Astra, waits for exit, and resumes the same thread
with the configured execution model in the same `CODEX_HOME`. Astra uses read-only
sandbox; execution restores the Stage sandbox. Stage 4 remains a single GLM
turn. Logs retain `attempt_N.bootstrap.*` for historical compatibility.
A polling race is possible; interruption and resumption must be verified from
actual logs. This mechanism does not guarantee future tool calls are valid.

The analysis stage, not the inventory, decides whether one source Case produces
one or several v0.2 result Cases. A split requires distinct real evaluation
contracts and must be recorded in the handoff. All result Cases from one source
unit stay together through the remaining stages.

Only a `PASS` result starts the next stage. `FAIL`, `BLOCKED`, command failure,
or repeated API failure stops that source Case. A later stage never repairs an
earlier stage's files.

API/network failure on the mimo profile is retried twice on that profile before
switching; other profiles are retried once on their current profile. After the
same-profile allowance, retries use `gpt-5.6-sol-high-api-fallback` (provider
`bf0a6598-e93e-44d0-8eef-107a587fe999`), with six total API retries allowed.
API retries are independent of tool/session retries. For Stages 1-2, 3, 5, 6,
and optional Repair, each attempt first runs the read-only `gpt-6-astra` low
bootstrap and then resumes the same thread with the configured execution
model. A bootstrap or execution tool-session guard failure creates a fresh
two-turn attempt using that Stage's configured profile: mimo for Stages 1-2 and
6, and shaobianer-plus8-1 for Stages 3 and 5 and optional Repair. Allow eight
such retries, then up to three `gpt-5.5` `xhigh` attempts. These retries are
orchestration recovery and do not consume Stage rework.
Before the first execution tool, allow 120 seconds for the first JSONL event,
reset a 120-second inactivity timer whenever JSONL progresses, and retain a
five-minute absolute pre-tool limit. Reject explicit tool-router schema errors
immediately.

Bootstrap and execution use the same `CODEX_HOME`, profile, and thread. The
mimo profile deliberately uses its existing `auth.json` through provider
`custom` for Astra, then provider `mimo_sol` and the separately supplied
`MIMO_SOL_API_KEY` for execution. Other profiles retain provider `custom` for
both turns. A failed bootstrap starts no execution turn and consumes only the
existing transient retry category. A failed execution starts a fresh complete
bootstrap-plus-execution attempt; API, tool-session, output, model fallback,
and content-rework counters remain independent.

## Queue-only prompt

```text
Read benchmarks/mig_data/case_migration_inventory.md and report the pending
source Case order using suggested batch and row order. Do not inspect Case
implementation, decide configuration splits, start migration sessions, or edit
files. The migration runner will process one source Case at a time.
```
