#!/usr/bin/env python3
"""Snapshot interrupted tasks and archive retry state for a fresh serial run."""

import argparse
import json
import shutil
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STAGES = (
    "analyze", "contract", "implement-certify", "publish", "closure-audit", "accept"
)
DIRECTORIES = tuple(f"{index:02d}-{stage}" for index, stage in enumerate(STAGES, 1))


def plan_tasks(run_root):
    tasks = []
    prior_queue_cases = set()
    if run_root.resolve() == (ROOT / "benchmarks/mig_data/runs").resolve():
        for manifest in (ROOT / "benchmarks/mig_data/removed_tasks").glob(
            "progress_requeue_20261001_*/queue.json"
        ):
            try:
                prior_queue_cases.update(
                    entry["case_id"] for entry in json.loads(manifest.read_text()).get("tasks", [])
                )
            except (OSError, json.JSONDecodeError, KeyError, TypeError):
                continue
    for task in sorted(run_root.iterdir()):
        status_file = task / "status"
        if not status_file.is_file():
            continue
        lines = status_file.read_text().strip().splitlines()
        status = lines[0] if lines else ""
        case_id = task.name.replace("__", ".", 1)
        if not (
            status.startswith("REWORKING_FROM=")
            or status in {"OUTPUT_INVALID", "REWORK_LIMIT"}
            or (status == "BLOCKED" and case_id in prior_queue_cases)
        ):
            continue
        for index, directory in enumerate(DIRECTORIES):
            result = task / directory / "result.json"
            if not result.exists():
                mode = "resume"
                break
            try:
                data = json.loads(result.read_text())
            except json.JSONDecodeError:
                mode = "rework"
                break
            if data.get("outcome") != "PASS":
                mode = "rework"
                owner = data.get("owner_stage")
                if owner in STAGES:
                    index = min(index, STAGES.index(owner))
                break
        else:
            # All stages passed but the task status was never finalized.
            index = len(STAGES)
            mode = "resume"
        tasks.append({
            "case_id": case_id,
            "prior_status": status,
            "mode": mode,
            "start_index": index,
            "stage": STAGES[index] if index < len(STAGES) else "complete",
        })
    # Include inventory Cases that have no formal run record yet.  These are
    # deliberately added only for the real migration run root; temporary test
    # roots must remain isolated from the repository inventory.
    real_root = (ROOT / "benchmarks/mig_data/runs").resolve()
    if run_root.resolve() == real_root:
        inventory = ROOT / "benchmarks/mig_data/case_migration_inventory.md"
        known = {task["case_id"] for task in tasks}
        if inventory.is_file():
            for line in inventory.read_text(encoding="utf-8").splitlines():
                if not line.startswith("|"):
                    continue
                cells = [cell.strip() for cell in line.strip("|").split("|")]
                if len(cells) < 2 or "." not in cells[0] or cells[1] not in {"是", "否"}:
                    continue
                case_id = cells[0]
                if cells[1] != "否" or case_id in known:
                    continue
                task = run_root / case_id.replace(".", "__", 1)
                status_file = task / "status"
                if task.exists() and status_file.is_file():
                    continue
                tasks.append({
                    "case_id": case_id,
                    "prior_status": "NO_DIR" if not task.exists() else "NO_STATUS",
                    "mode": "resume",
                    "start_index": 0,
                    "stage": "analyze",
                })
                known.add(case_id)
    # Finish advanced tasks first; every task still runs in the same worker.
    return sorted(tasks, key=lambda task: (-task["start_index"], task["case_id"]))


def archive_retries(run_root, archive, tasks):
    moved = 0
    for entry in tasks:
        task = run_root / entry["case_id"].replace(".", "__", 1)
        destination = archive / task.name
        destination.mkdir()
        status_file = task / "status"
        if status_file.is_file():
            shutil.copy2(status_file, destination / "status.before_requeue")
        else:
            (destination / "status.before_requeue").write_text(
                entry["prior_status"] + "\n", encoding="utf-8"
            )
        for index, directory in enumerate(DIRECTORIES):
            stage = task / directory
            if not stage.is_dir():
                continue
            stage_archive = destination / directory
            for file in list(stage.iterdir()):
                if not file.is_file():
                    continue
                counter = file.name in {".rework_count", "reworks.tsv"}
                retry = index >= entry["start_index"] and (
                    file.name.startswith("attempt_")
                    or file.name in {"sessions.tsv", "api_resume_profile", "api_resume_prompt.txt"}
                    or file.name.endswith("_retries.log")
                    or file.name.endswith("_provider_fallback.log")
                    or file.name.startswith("api_") and file.name.endswith(".log")
                )
                if counter or retry:
                    stage_archive.mkdir(exist_ok=True)
                    shutil.move(str(file), str(stage_archive / file.name))
                    moved += 1
            # An explicit zero also prevents old before_rework files from
            # bootstrapping the exhausted count again during a later rework.
            (stage / ".rework_count").write_text("0\n")
    return moved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    run_root = ROOT / "benchmarks/mig_data/runs"
    tasks = plan_tasks(run_root)
    if not args.apply:
        print(json.dumps({"count": len(tasks), "tasks": tasks}, indent=2))
        return
    removed = ROOT / "benchmarks/mig_data/removed_tasks"
    removed.mkdir(exist_ok=True)
    archive = Path(tempfile.mkdtemp(prefix="progress_requeue_20261001_", dir=removed))
    # Save the exact queue before moving anything; subsequent status changes
    # cannot remove an interrupted task from this worker's snapshot.
    manifest = archive / "queue.json"
    manifest.write_text(json.dumps({"tasks": tasks}, indent=2) + "\n")
    moved = archive_retries(run_root, archive, tasks)
    (archive / "cleanup.json").write_text(json.dumps({"archived_files": moved}, indent=2) + "\n")
    print(manifest)


if __name__ == "__main__":
    main()
