# PyPTO v0.1 -> v0.2 staged migration

One source Case is migrated by six sequential Codex sessions. Each session has
one objective and a fixed write boundary. A later session must not repair work
owned by an earlier session: it records the defect in `handoff.md`, names the
owning stage, and stops.

## Stages

1. [02_analyze.md](02_analyze.md): understand the source and decide the exact
   v0.2 Case set. Read-only except for the handoff.
2. [03_contract.md](03_contract.md): create the public contract, preserved
   official source, and official Fixture builder.
3. [04_implement_and_certify.md](04_implement_and_certify.md): implement the
   NPU Ref, independent CPU Oracle, and Case evaluator, then run `prepare-ref`.
4. [05_publish_candidate.md](05_publish_candidate.md): copy the certified Ref
   implementation into Candidate Seed, verify multi-file identity, and run
   clean evaluation plus every supported profiling mode.
5. [06_closure_audit.md](06_closure_audit.md): independently audit Ref and
   Candidate implementation closure and reject embedded validation or harness
   support code.
6. [06_accept.md](06_accept.md): independently inspect and run the completed
   Case without repairing canonical source.

Strict Stage 3 may stop on a reproducible NPU Ref correctness failure. A human
can then explicitly invoke the optional
[Repair branch](04_repair_and_recertify.md). It is not part of the automatic
sequence: a successful repair is recertified, recorded as a hash-bound
proposal, and stops for separate human approval before Stage 4.

All stages must read [CASE_MIGRATION_CONTRACT.md](CASE_MIGRATION_CONTRACT.md)
and [COMPARATOR_POLICY.md](COMPARATOR_POLICY.md). The latter is the single
authority for reconciling the selected workload's comparator with current
upstream; Stage documents only assign ownership and must not redefine it.
When any source-side or migrated closure contains multiple local files or
runtime resources, all stages also follow
[MULTI_FILE_MIGRATION.md](MULTI_FILE_MIGRATION.md). It defines the shared
per-file ledger, import/resource isolation, manifest reconciliation, and global
Case-ID collision rules.
The Case-specific decisions and stage results are passed through:

```text
benchmarks/mig_data/runs/<family>__<source-case>/handoff.md
```

## Stage execution configuration

The orchestrator loads an isolated Codex profile before every stage attempt,
including an automatic API retry, and then explicitly selects that stage's
model and reasoning effort. The profile is supplied through `CODEX_HOME`, so
the user's global `~/.codex` configuration and active cc-switch provider are
not modified:

| Stages | profile | execution provider source | model | reasoning effort |
| --- | --- | --- | --- | --- |
| 1-2 and 6 | `profiles_codex/gpt-5.6-sol-high-mimo` | `mimo_sol`, with its key supplied locally through `MIMO_SOL_API_KEY` | `gpt-5.6-sol` | `high` |
| 3, 5, and optional Repair | `profiles_codex/gpt-5.6-sol-high-shaobianer-plus8-1` | `aa1c0c9f-7aa4-4fe2-8cc7-add9ea37588d-copy` | `gpt-5.6-sol` | `high` |
| 4 | `profiles_codex/glm-5.3-flash-max` | `e3c77ec9-0be4-477e-a4fa-e17669e47326` | `glm-5.3-flash` | `max` |

Stages 1, 2, 3, 5, 6 and Repair start with `gpt-6-astra` at `low` reasoning.
Both models receive the original Stage prompt and formal Skill. No bootstrap
Skill, planning instruction, tool quota, or completion marker is injected.
The external runner observes two successfully completed command tools and no
active tools, interrupts Astra, waits for exit, and resumes the same thread
with the configured execution model in the same `CODEX_HOME`. Astra uses
read-only sandbox; execution restores the Stage sandbox. In the mimo profile,
Astra explicitly uses provider `custom` and the existing `auth.json`, while
Sol explicitly uses provider `mimo_sol` and `MIMO_SOL_API_KEY`. The runner reads
that variable from
`profiles_codex/gpt-5.6-sol-high-mimo/.secrets/mimo_sol_api_key` unless it is
already present in the environment. The secret file is ignored by Git and
must contain exactly the key on its first line. Other profiles retain their
configured `custom` provider. Stage 4 remains a single GLM turn. Logs retain
`attempt_N.bootstrap.*` for historical compatibility and record provider and
credential source names, never credential values.
A polling race is possible; interruption and resumption must be verified from
actual logs. This mechanism does not guarantee future tool calls are valid.

## Authority and drift

The current v0.2 implementation is authoritative for executable interfaces:
`bench`, `evaluator/workflow.py`, `evaluator/workspace.py`,
`evaluator/profile_modes.py`, the environment profile schema, and current
canonical Case examples. The common migration contract defines the invariants
that all stages share; each Stage document and Skill defines ownership and its
write boundary.

These layers must agree. If a Stage finds that a documented interface no longer
matches current implementation, it records an `infrastructure` blocker and
stops rather than choosing whichever rule is convenient or editing shared code
inside a Case migration. In particular, discover `PROFILE_MODES` at execution
time, use the fixed `fixture_builder.build(case_dir, sealed, case, seed)` entry,
and treat canonical Case/sealed files rather than workspace snapshots as the
evaluation contract.

Comparator policy is public and uniform, but comparator execution is not common
infrastructure. Every sealed Case `evaluate.py` independently reads and
strictly validates its JSON and must implement and test every method and field
that JSON actually declares. Unused standard-method implementations may remain
locally, but are not required, need no acceptance coverage, and must not affect
the active callbacks or PASS/FAIL. Undeclared custom behavior is forbidden.
`evaluator/common.py` and `evaluator/workflow.py` must not acquire comparator
method dispatch, schema interpretation, or a comparator registry; they retain
only generic utilities and lifecycle duties such as certification hash binding.

## Run

```bash
# Show the six sessions and write their prompts without launching Codex.
bash benchmarks/mig_workflow/run_migrations.sh --dry-run

# Migrate the next pending source Case from the inventory.
bash benchmarks/mig_workflow/run_migrations.sh

# Select one source Case explicitly.
bash benchmarks/mig_workflow/run_migrations.sh --case family.case

# Continue explicitly selected interrupted Cases from each first missing Stage.
bash benchmarks/mig_workflow/run_migrations.sh --resume --case family.case

# Process more source Cases sequentially. Cases are never run in parallel.
bash benchmarks/mig_workflow/run_migrations.sh --limit 5

# Rework the stage named by the latest failed result's owner_stage, then rerun
# every downstream stage. An explicit stage name may replace "owner".
bash benchmarks/mig_workflow/run_migrations.sh --case family.case --rework owner
bash benchmarks/mig_workflow/run_migrations.sh --case family.case --rework contract

# After an eligible strict Stage 3 correctness FAIL, prepare a narrow repair
# proposal. This command never continues to Stage 4.
bash benchmarks/mig_workflow/run_migrations.sh --case family.case --repair

# After reviewing proposal.json, repair.patch and the handoff, explicitly
# approve the exact hash-bound repair and continue from Stage 4.
bash benchmarks/mig_workflow/run_migrations.sh --case family.case --approve-repair
```

Each Case has one directory. Each stage has its own prompt, Codex event stream,
stderr, result, and session record:

```text
benchmarks/mig_data/runs/<family>__<source-case>/
├── handoff.md
├── 01-analyze/
├── 02-contract/
├── 03-implement-certify/
├── 03-repair-certify/        # optional; includes proposal/approval evidence
├── 04-publish/
├── 05-closure-audit/
├── 06-accept/
├── result.json
└── status
```

For every Stage whose effective model is `gpt-5.6-sol`, the orchestrator also
guards thread startup. Before the first execution tool, the guard allows 120
seconds for the first JSONL event, resets a 120-second inactivity timer on every
new event, and enforces a five-minute absolute limit. Thus active reasoning is
not rejected merely because no tool arrived within a fixed 90-second window. A
bootstrap or formal execution thread that exits without its required tool event, or whose
stderr contains a Codex tool-router argument/schema error, is recreated. A
thread that stops producing JSONL events for one hour after tools begin is also recreated, up to eight retries
(nine attempts including the initial thread) on the stage's configured
profile. If a `gpt-5.6-sol` stage exhausts those retries, it switches to
`gpt-5.5` with `xhigh` reasoning for up to three additional attempts.
API/network failures on the mimo profile first retry twice on that profile;
other profiles first retry once on their configured profile. After that,
subsequent API retries use `gpt-5.6-sol-high-api-fallback` (provider
`bf0a6598-e93e-44d0-8eef-107a587fe999`), up to six total API retries. API
retries are independent of tool/session and model fallback retries. Every try has its own
`attempt_N` artifacts (and bootstrap phase artifacts where applicable) and
`attempt_N.session_guard.log`; the aggregate decisions
are appended to `session_retries.log`. These are transient Codex-session retries,
not content rework: they do not read, increment, or consume `.rework_count`.
The limits can be overridden for diagnostics with
`MAX_CODEX_SESSION_RETRIES`, `MAX_CODEX_MODEL_FALLBACK_RETRIES`,
`MAX_API_RETRIES`, `MAX_OUTPUT_RETRIES`, `CODEX_FIRST_EVENT_TIMEOUT_SECONDS`,
`CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS`, `CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS`,
and `CODEX_INACTIVITY_TIMEOUT_SECONDS`. The legacy
`CODEX_TOOL_START_TIMEOUT_SECONDS` sets both pre-tool 120-second timers when
their specific variables are unset.

The script stops at the first non-`PASS` stage, except that a Stage 4, Stage 5, or Stage 6 content
`FAIL` with `owner_stage` set to `analyze`, `contract`, `implement-certify`, or
`publish` automatically starts owner-directed rework. Old downstream
results/workspaces are archived, the owner stage and every later stage are
rerun, and the new downstream result becomes authoritative. After six API
retries are exhausted, an API failure is recorded and the Case stops. A
successful acceptance maps to final status `READY`.

The optional Repair branch uses the same API, invalid-output, tool-session, and
gpt-5.5 fallback retry machinery as Stage 3. A branch `PASS` maps to
`AWAITING_REPAIR_APPROVAL`, not migration success. The approval command
re-verifies protected files and current Ref/generated hashes before writing an
immutable local approval record. Drift rejects approval. Models cannot invoke
or manufacture this human gate from an ordinary stage.

## Rework

`--rework owner` reads the latest non-`PASS` stage result. For a content defect
it resumes at `owner_stage`; for an `infrastructure` blocker it retries the
stage that observed the blocker. `--rework <stage>` selects `analyze`,
`contract`, `implement-certify`, `publish`, `closure-audit`, or `accept`
explicitly. Every
downstream stage is rerun because its artifacts may depend on the repaired
stage. Rework requires an explicit `--case` or `--cases-file`; it never picks a
Case implicitly from the inventory.

An `infrastructure` owner always maps the Case status to `BLOCKED`, including
when the failed diagnostic check itself is recorded as `FAIL`; content-owned
failures map to `INVALID`.

Before rework, authoritative `result.json` and `status` files are renamed with
a `before_rework_<timestamp>` suffix. Attempt logs use the next unused
`attempt_N` number. Handoffs and prior logs are append-only, so rework never
erases the evidence that triggered it. Stage-owned workspace/result directories
are also timestamp-archived so publication and acceptance cannot reuse stale
artifacts. `--force` remains the full restart form and is mutually exclusive
with `--rework`.

`--resume` is narrower than rework. It is intended for an interrupted stage or
an invalid/missing structured output where no authoritative Stage result was
created. It verifies that every existing earlier `result.json` is `PASS`, then
continues at the first Stage without a result. It does not archive artifacts or
consume rework counts. If it finds an authoritative non-`PASS` Stage result, it
stops and requires `--rework` so content repair remains counted and auditable.
An approved, currently valid Repair record is the sole exception: it satisfies
the Stage 3 gate for resuming a previously interrupted Stage 4-6 sequence.

A reworked stage must collect fresh evidence and rerun all currently runnable
required commands. Historical handoff failures and `before_rework` artifacts
provide context only and cannot be reused as the new verdict.

Each Stage may be reworked at most three times; its initial execution does not
count. The counter is persisted in the Stage directory and `--force` cannot
bypass it. Starting a rework consumes one count even if that run later fails;
API/network retries do not consume another rework count.
At the limit the Case status is `REWORK_LIMIT` and requires manual review.
Automatic owner-directed rework from Stages 4-6 uses the same counters and
limit. Stages 4-6 must choose the repair owner in their result; they cannot
repair an earlier stage's files themselves. Invalid stage-result JSON is
retried up to two times on the same stage before the Case is marked
`OUTPUT_INVALID`; these output retries are independent of all other counters.

Stages 1-2 run in the workspace sandbox. Stages 3-6 and the optional Repair branch require direct access to
the local NPU device nodes, so their Codex sessions use `danger-full-access`.
Their documented write boundaries remain mandatory and are checked through
the stage result and independent acceptance rather than OS sandboxing.
The Stage 1-2 execution turn explicitly enables
`sandbox_workspace_write.network_access=true`. This retains workspace-scoped
filesystem writes while allowing required current-upstream checks through the
runner's host-local proxy. The read-only Astra bootstrap remains unchanged;
the resumed execution turn owns authoritative external evidence collection.
Before Stage 1, the external runner also refreshes `upstream/main` outside the
Codex sandbox. This is required because the workspace sandbox may read Git
metadata and use the network but intentionally cannot write `.git/FETCH_HEAD`.
A process-local Git config routes these upstream checks through the local
SOCKS5 proxy; it does not modify the user's global Git configuration.
A failed refresh is reported as a warning so Stage 1 can return an auditable
infrastructure blocker from the evidence it observes.

Every profiling mode uses a single correctness dispatch. Profiling is an
availability/artifact check, not a performance measurement, so profiling
warmups and measured rounds are not run and timing samples are not required.
All clean/profile commands run sequentially because they share the selected
device and diagnostic state.

Publication and acceptance create fresh workspaces with `bench init`, not
`bench fork`. Both initial and final clean gates use `phase=all`; explicit
`--result` paths move only the summary JSON, while build and diagnostic output
remains under that workspace's `.benchmark_outputs/<mode>/`.

Migration qualification currently attempts all standard profiling modes defined
in `evaluator/profile_modes.py`: `runtime`, `hardware`, and `compile`. Each gets
an explicit `PASS`, `UNSUPPORTED`, or `FAIL` record. Clean evaluation remains
the formal pass gate, so a Case may be `READY` with `Profiling: PARTIAL` when a
mode is genuinely unavailable, provided the limitation and reason are recorded.

## Session names

Sessions are renamed after their thread ID becomes available:

```text
migrate-<family>__<case>-01-analyze
migrate-<family>__<case>-02-contract
migrate-<family>__<case>-03-implement-certify
migrate-<family>__<case>-03-repair-certify  # optional branch only
migrate-<family>__<case>-04-publish
migrate-<family>__<case>-05-closure-audit
migrate-<family>__<case>-06-accept
```

`codex exec` currently has no start-time session-name option, so the script uses
the app-server `thread/name/set` method. `--no-rename` disables this behavior.
