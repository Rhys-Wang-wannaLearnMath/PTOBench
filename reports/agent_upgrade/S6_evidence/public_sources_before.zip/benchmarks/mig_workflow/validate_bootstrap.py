#!/usr/bin/env python3
"""Validate the bounded, read-only Astra bootstrap turn."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


FORBIDDEN_COMMAND = re.compile(
    r"(?:^|\s)(?:npu-smi|pytest|cmake|ninja|make)(?:\s|$)"
    r"|(?:^|/)bench\s+(?:prepare-ref|evaluate|profile|run)(?:\s|$)"
    r"|(?:^|\s)ptoas(?:\s|$)",
    re.IGNORECASE,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", required=True, type=Path)
    parser.add_argument("--message", type=Path)
    parser.add_argument("--thread-id", default="")
    parser.add_argument("--minimum-tools", type=int, default=2)
    args = parser.parse_args()

    errors: list[str] = []
    completed_tools = 0
    thread_id = args.thread_id
    active = set()

    for line_number, line in enumerate(args.events.read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("type") == "thread.started":
            thread_id = event.get("thread_id", "")
        item = event.get("item") or {}
        item_type = item.get("type")
        if event.get("type") == "item.started" and item_type in {"command_execution", "file_change", "mcp_tool_call"}:
            active.add(item.get("id"))
        if event.get("type") == "item.completed":
            active.discard(item.get("id"))
        if item_type == "file_change":
            errors.append("bootstrap emitted a file_change event")
        if event.get("type") == "item.completed" and item_type == "command_execution":
            if item.get("status") == "completed" and item.get("exit_code", 0) == 0:
                completed_tools += 1
            command = item.get("command", "")
            if FORBIDDEN_COMMAND.search(command):
                errors.append(f"bootstrap ran a forbidden command: {command}")

    if active:
        errors.append("tools still running")
    if not thread_id:
        errors.append("bootstrap did not emit a thread.started event")
    if completed_tools < args.minimum_tools:
        errors.append(
            f"bootstrap completed {completed_tools} successful command tools; "
            f"requires at least {args.minimum_tools}"
        )

    if errors:
        print("\n".join(errors))
        return 1
    print(f"bootstrap valid: thread={thread_id}, successful_tools={completed_tools}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
