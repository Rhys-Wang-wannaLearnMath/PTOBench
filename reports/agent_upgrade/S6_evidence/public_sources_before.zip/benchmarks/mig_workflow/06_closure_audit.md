# Stage 5: Ref/Candidate closure audit

Skill: `audit-pypto-case-v02-closure`

This is a dedicated, independent anti-smuggling gate between publication and
final acceptance. It is read-only for canonical Case and sealed files and may
write only its stage handoff/result artifacts. Audit every Ref and Candidate
implementation closure and reject embedded Fixture/TensorSpec generation,
golden or Oracle computation, expected outputs, RunConfig, evaluator,
profiling, certification, benchmark, test, or standalone CLI support code.

For multi-file Cases, apply `MULTI_FILE_MIGRATION.md` and independently rebuild
the closure ledger, manifests, and import/resource isolation evidence. Include
global Case-ID ownership and sibling load-order/module-cache checks.

Also verify that comparator JSON parsing, validation, construction, and
execution remain sealed in each Case's own `evaluate.py`, are absent from both
Ref and Candidate, and have not migrated into common workflow infrastructure.
Only methods declared by the canonical JSON are required execution behavior;
unused local standard-method branches are allowed and are not closure defects.
Comparator provenance/applicability and public JSON correctness are not
re-decided here; an observed defect is assigned to Stage 1, 2, or 3.

Do not reject legitimate algorithm constants or implementation tiling values,
and ignore only `__pycache__/` and `*.pyc`. For a content defect, return
`FAIL` with the earliest owning stage (`analyze`, `contract`,
`implement-certify`, or `publish`); never repair the Case in this stage.
Infrastructure failures return `BLOCKED` with owner `infrastructure`.

If the Case used the optional Repair branch, independently verify the
hash-bound proposal and human approval before comparing Ref and Candidate. The
exact approved Ref deviation is not smuggling and is not rejected solely for
changing internal topology. Any stale approval, Ref drift, Candidate mismatch,
or extra unapproved deviation is a content failure owned by
`implement-certify` or `publish` as appropriate.

The workflow archives stale closure/acceptance evidence and automatically
reruns the selected owner and every downstream stage. Use the current
`evaluator/profile_modes.py:PROFILE_MODES` inventory in the result, even though
this audit does not launch device profiling.
