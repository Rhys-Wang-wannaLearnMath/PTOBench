#!/usr/bin/env bash
set -u
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
export MIGRATION_GIT_PROXY=""
exec 9>benchmarks/mig_workflow/.serial_queue.lock
flock -n 9 || { echo "Another serial migration queue is already running" >&2; exit 1; }

manifest=benchmarks/mig_data/removed_tasks/progress_requeue_20261001_e8x6s36g/queue.json
mapfile -t entries < <(python3 - "$manifest" <<'PY'
import json, sys
for task in json.load(open(sys.argv[1])).get("tasks", []):
    case = task["case_id"]
    # This Case has its own independent migration process and is intentionally
    # outside this queue.
    if case == "deepseek_v4_pro.synthetic_token_loop_flash5_split_0912":
        continue
    # This source is already delivered by decode_o_proj_grouped.  Its duplicate
    # failed task was archived; old recovery manifests must not recreate it.
    if case == "deepseek_v4.decode_o_proj":
        continue
    print("\t".join((case, task["mode"], task.get("stage", "analyze"))))
for case, mode, stage in (
    ("deepseek_v4.prefill_layer_ep4_csa", "rework", "implement-certify"),
    ("deepseek_v4_flash_mtp.prefill_cp_swa_cp8", "rework", "analyze"),
):
    print("\t".join((case, mode, stage)))
PY
)
echo "Selected ${#entries[@]} Case(s); one serial queue; synthetic loop excluded"
for entry in "${entries[@]}"; do
  IFS=$'\t' read -r case_id mode stage <<<"$entry"
  echo "===== CASE $case_id --$mode $stage ====="
  if [[ "$mode" == rework ]]; then
    bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --rework "$stage" ||
      echo "FAILED $case_id"
  else
    bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume ||
      echo "FAILED $case_id"
  fi
done
