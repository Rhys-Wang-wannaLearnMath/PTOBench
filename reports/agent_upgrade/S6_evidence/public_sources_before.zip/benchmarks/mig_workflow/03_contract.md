# Stage 2: build contract and Fixture path

Skill: `build-pypto-case-v02-contract`

Create each Case's public fixed contract, preserved official source, and
Case-local official Fixture builder from the approved handoff.

For a multi-file official/Fixture closure, follow `MULTI_FILE_MIGRATION.md`:
materialize exactly the approved paths, hash every dependency independently,
and prove official imports resolve inside the preserved tree. Recheck global
Case-ID ownership before writing; a collision returns to Stage 1.

Write `public/comparator.json` exactly from Stage 1's complete reconciliation
decision and validate it against `COMPARATOR_POLICY.md`. Do not revisit
`ADOPT`/`KEEP_SELECTED`, search for a different tolerance, or copy only the
convenient fields of a coupled change. If the handoff lacks upstream commit,
change groups, applicability evidence, full output coverage, or an unambiguous
final rule, stop and return ownership to Stage 1.

This stage writes only the public comparator contract. It does not implement a
parser or callback and must not add comparator interpretation to shared code.
Stage 3 will independently implement and test every method actually declared by
this JSON in each result Case evaluator. Methods absent from the JSON are not
Stage 3 requirements.

Writable paths for result Cases only:

```text
benchmarks/pypto_lib_bench-v0.2/cases/<family>/<case>/case.json
benchmarks/pypto_lib_bench-v0.2/cases/<family>/<case>/public/config.py
benchmarks/pypto_lib_bench-v0.2/cases/<family>/<case>/public/comparator.json
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/official/**
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/fixture_builder.py
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/fixture_policy.json
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/certification.json   # pending skeleton only
benchmarks/pypto_lib_bench-v0.2/environments/<case-profile>.json  # only when an existing profile does not fit
<task-dir>/handoff.md
```

Forbidden in this stage: Candidate Seed, Ref, Oracle, evaluator implementation,
generated fixtures/caches, shared evaluator code, modifying an existing shared
environment profile, and other Cases. A new environment JSON is allowed only
when Stage 1 documented why an existing profile cannot represent this Case.

The official tree must contain byte-exact `original.py`, mandatory
`source_provenance.json`, and `original_config.py` when the source has an
external configuration dependency. Never adapt those preserved files to the
current API; perform compatibility and per-preset binding in the Fixture
adapter. Do not create `original_config.py` for a self-contained source. An
extraction of constants from `original.py`, a copy of public `config.py`, or a
synthesized snapshot is not an original config dependency and is forbidden.

For historical builders using `TensorSpec(is_output=...)` or importing their
source config, use the existing
`evaluator/common.py::load_official_fixture_specs(...)` with an optional alias
derived from public config. Do not duplicate its temporary monkey-patching or
use it to change Fixture semantics. Any unsupported shared compatibility need
is an infrastructure blocker, not permission to edit the common evaluator.

Put only Case-specific, current RunConfig fields in `case.json.runtime`; do not
copy every environment default or add tuning knobs. A new environment JSON must
use the current profile schema and official setup paths.

For split preset siblings, keep the directory name, `case_id`, description,
config identity/comments, and local dynamic module-load names consistent with
the explicit Stage 1 result ID. When a real separate complete
`original_config.py` exists, organize public config as the source config class,
exactly one selected preset, `CASE_CONFIG`, then fixed operator/deployment
bindings. Preserve the selected preset's coherent useful surface; do not reduce
it to currently imported fields, copy unrelated sibling presets, or add
implementation tuning choices. Runtime code consumes the selected preset via
`CASE_CONFIG`; use a temporary historical-name alias only inside the Fixture
adapter when required to load the byte-exact official source.

Preserve meaningful derivations among Case-relevant fixed values. Keep source
operands and formulas such as `DECODE_BATCH`, `DECODE_SEQ`, and
`DECODE_TOKENS = DECODE_BATCH * DECODE_SEQ`; do not replace the formula with a
literal only because Candidate imports the result. Exclude derivation branches
that belong exclusively to other workloads.

Use the current fixed Fixture interface: policy schema v1 with only
`fixture_seeds.fixture_000`, and a Case adapter entry
`build(case_dir, sealed, case, seed)`. Fixed builder inputs come from canonical
public config/Case metadata; this Stage does not generate the Fixture.

If source inspection contradicts Stage 1, stop and return ownership to Stage 1.
Do not silently make a new split or contract decision.

## Prompt

```text
Use $build-pypto-case-v02-contract for <CASE_ID>. Read the shared contract,
comparator policy, and <TASK_DIR>/handoff.md. Create only the allowed public
contract, official source,
Fixture builder/policy, pending certification skeleton, and any Stage-1-approved
new Case-specific environment profile for every approved result Case. Do not
implement Ref, Oracle, Candidate, evaluate.py, generate fixtures, or modify an
existing shared environment profile. Append evidence and output paths to the
handoff. Stop on any analysis contradiction instead of changing Stage 1
decisions silently.
```
