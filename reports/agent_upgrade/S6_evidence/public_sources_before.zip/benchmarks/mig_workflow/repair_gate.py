#!/usr/bin/env python3
"""Create and verify hash-bound human approvals for the optional Ref repair branch."""

from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


IGNORED_PARTS = {"__pycache__"}


def fail(message: str) -> None:
    raise ValueError(message)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        fail(f"expected JSON object: {path}")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def payload_sha(value: dict[str, Any], omitted: str) -> str:
    payload = {key: item for key, item in value.items() if key != omitted}
    return sha256_bytes(
        json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    )


def split_case(case_id: str) -> tuple[str, str]:
    family, separator, case = case_id.partition(".")
    if not separator or not family or not case:
        fail(f"invalid Case ID: {case_id}")
    return family, case


def include_file(path: Path) -> bool:
    return not any(part in IGNORED_PARTS for part in path.parts) and path.suffix != ".pyc"


def iter_files(paths: Iterable[Path]) -> Iterable[Path]:
    for path in paths:
        if not path.exists():
            fail(f"required path is missing: {path}")
        if path.is_symlink():
            fail(f"symlink is not permitted in repair evidence: {path}")
        if path.is_file():
            if include_file(path):
                yield path
            continue
        for child in sorted(path.rglob("*")):
            if child.is_symlink():
                fail(f"symlink is not permitted in repair evidence: {child}")
            if child.is_file() and include_file(child):
                yield child


def manifest(root: Path, paths: Iterable[Path]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for path in iter_files(paths):
        relative = path.relative_to(root).as_posix()
        result[relative] = {"sha256": sha256_file(path), "size": path.stat().st_size}
    return result


def manifest_sha(value: dict[str, Any]) -> str:
    return sha256_bytes(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )


def case_roots(root: Path, case_id: str) -> tuple[Path, Path, dict[str, Any]]:
    family, case = split_case(case_id)
    public = root / "benchmarks/pypto_lib_bench-v0.2/cases" / family / case
    sealed = root / "benchmarks/pypto_lib_bench-v0.2/sealed_assets" / family / case
    case_json = read_json(public / "case.json")
    if case_json.get("case_id") != case_id:
        fail(f"case.json identity mismatch for {case_id}")
    return public, sealed, case_json


def result_case_ids(strict_result: dict[str, Any]) -> list[str]:
    values = strict_result.get("result_case_ids")
    if not isinstance(values, list) or not values or not all(isinstance(v, str) for v in values):
        fail("strict Stage 3 result must declare nonempty result_case_ids")
    return values


def protected_paths(root: Path, case_id: str) -> list[Path]:
    public, sealed, case_json = case_roots(root, case_id)
    environment = case_json.get("environment")
    if not isinstance(environment, str) or not environment:
        fail(f"missing environment in {public / 'case.json'}")
    fixture = sealed / "fixtures/fixture_000"
    paths = [
        public / "case.json",
        public / "public/config.py",
        public / "public/comparator.json",
        sealed / "official",
        sealed / "fixture_builder.py",
        sealed / "fixture_policy.json",
        sealed / "oracle",
        sealed / "evaluate.py",
        fixture / "manifest.json",
        fixture / "in",
        root / "benchmarks/pypto_lib_bench-v0.2/environments" / f"{environment}.json",
    ]
    scalars = fixture / "scalars.json"
    if scalars.exists():
        paths.append(scalars)
    sealed_provenance = sealed / "provenance.json"
    if sealed_provenance.exists():
        paths.append(sealed_provenance)
    return paths


def ref_path(root: Path, case_id: str) -> Path:
    _, sealed, _ = case_roots(root, case_id)
    return sealed / "ref"


def generated_paths(root: Path, case_id: str) -> list[Path]:
    _, sealed, _ = case_roots(root, case_id)
    return [
        sealed / "certification.json",
        sealed / "ref_performance.json",
        sealed / "fixtures/fixture_000/out",
    ]


def combined_manifest(root: Path, case_ids: list[str], selector: str) -> dict[str, Any]:
    combined: dict[str, Any] = {}
    for case_id in case_ids:
        if selector == "protected":
            paths = protected_paths(root, case_id)
        elif selector == "ref":
            paths = [ref_path(root, case_id)]
        elif selector == "generated":
            paths = generated_paths(root, case_id)
        else:
            fail(f"unknown manifest selector: {selector}")
        combined[case_id] = manifest(root, paths)
    return combined


def baseline_ref_manifest(root: Path, task_dir: Path, case_ids: list[str]) -> dict[str, Any]:
    combined: dict[str, Any] = {}
    baseline_root = task_dir / "03-repair-certify/baseline_ref"
    for case_id in case_ids:
        family, case = split_case(case_id)
        before_root = baseline_root / family / case / "ref"
        canonical_root = ref_path(root, case_id)
        entries: dict[str, Any] = {}
        for path in iter_files([before_root]):
            canonical = canonical_root / path.relative_to(before_root)
            relative = canonical.relative_to(root).as_posix()
            entries[relative] = {"sha256": sha256_file(path), "size": path.stat().st_size}
        combined[case_id] = entries
    return combined


def validate_strict_failure(task_dir: Path) -> tuple[Path, dict[str, Any]]:
    path = task_dir / "03-implement-certify/result.json"
    result = read_json(path)
    if result.get("stage") != "implement-certify":
        fail("repair requires an implement-certify result")
    if result.get("outcome") != "FAIL" or result.get("owner_stage") != "implement-certify":
        fail("repair requires Stage 3 FAIL with owner_stage implement-certify")
    result_case_ids(result)
    return path, result


def snapshot(root: Path, task_dir: Path) -> None:
    strict_path, strict = validate_strict_failure(task_dir)
    branch = task_dir / "03-repair-certify"
    baseline_path = branch / "baseline.json"
    case_ids = result_case_ids(strict)
    protected = combined_manifest(root, case_ids, "protected")
    if baseline_path.exists():
        baseline = read_json(baseline_path)
        if baseline.get("strict_result_sha256") != sha256_file(strict_path):
            fail("strict Stage 3 result changed after the repair baseline was created")
        if baseline.get("protected_manifest_sha256") != manifest_sha(protected):
            fail("protected Case content changed after the repair baseline was created")
        return

    baseline_root = branch / "baseline_ref"
    if baseline_root.exists():
        fail(f"unexpected incomplete repair baseline: {baseline_root}")
    for case_id in case_ids:
        family, case = split_case(case_id)
        destination = baseline_root / family / case / "ref"
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(ref_path(root, case_id), destination, symlinks=False)
    refs = combined_manifest(root, case_ids, "ref")
    write_json(
        baseline_path,
        {
            "schema_version": 1,
            "source_case_id": strict.get("case_id"),
            "result_case_ids": case_ids,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "strict_result_sha256": sha256_file(strict_path),
            "before_ref_manifest": refs,
            "before_ref_manifest_sha256": manifest_sha(refs),
            "protected_manifest": protected,
            "protected_manifest_sha256": manifest_sha(protected),
        },
    )


def text_or_none(path: Path) -> list[str] | None:
    if path.stat().st_size > 2 * 1024 * 1024:
        return None
    try:
        return path.read_text(encoding="utf-8").splitlines(keepends=True)
    except UnicodeDecodeError:
        return None


def build_patch(root: Path, task_dir: Path, case_ids: list[str]) -> tuple[str, list[str]]:
    baseline_root = task_dir / "03-repair-certify/baseline_ref"
    chunks: list[str] = []
    changed: list[str] = []
    for case_id in case_ids:
        family, case = split_case(case_id)
        before_root = baseline_root / family / case / "ref"
        after_root = ref_path(root, case_id)
        relative_paths = {
            path.relative_to(before_root).as_posix() for path in iter_files([before_root])
        } | {path.relative_to(after_root).as_posix() for path in iter_files([after_root])}
        for relative in sorted(relative_paths):
            before = before_root / relative
            after = after_root / relative
            if before.exists() and after.exists() and sha256_file(before) == sha256_file(after):
                continue
            label = f"{case_id}/ref/{relative}"
            changed.append(label)
            if before.exists() and after.exists():
                before_text = text_or_none(before)
                after_text = text_or_none(after)
                if before_text is not None and after_text is not None:
                    chunks.extend(
                        difflib.unified_diff(
                            before_text,
                            after_text,
                            fromfile=f"before/{label}",
                            tofile=f"after/{label}",
                        )
                    )
                    continue
            before_hash = sha256_file(before) if before.exists() else "MISSING"
            after_hash = sha256_file(after) if after.exists() else "MISSING"
            chunks.append(f"BINARY {label} {before_hash} -> {after_hash}\n")
    return "".join(chunks), changed


def validate_ready(root: Path, case_ids: list[str]) -> None:
    for case_id in case_ids:
        public, sealed, _ = case_roots(root, case_id)
        certification = read_json(sealed / "certification.json")
        performance = read_json(sealed / "ref_performance.json")
        if certification.get("status") != "ready" or certification.get("case_id") != case_id:
            fail(f"certification is not ready for {case_id}")
        comparator_sha = sha256_file(public / "public/comparator.json")
        if certification.get("comparator_sha256") != comparator_sha:
            fail(f"certification comparator hash is stale for {case_id}")
        if performance.get("status") != "ready" or not performance.get("fixtures"):
            fail(f"Ref performance is not ready for {case_id}")


def proposal(root: Path, task_dir: Path) -> None:
    branch = task_dir / "03-repair-certify"
    if (branch / "proposal.json").exists():
        validate_proposal(root, task_dir)
        return
    baseline = read_json(branch / "baseline.json")
    repair_result_path = branch / "result.json"
    repair_result = read_json(repair_result_path)
    if repair_result.get("stage") != "repair-certify" or repair_result.get("outcome") != "PASS":
        fail("repair proposal requires a PASS repair-certify result")
    case_ids = baseline["result_case_ids"]
    if repair_result.get("case_id") != baseline["source_case_id"]:
        fail("repair result source Case does not match the strict Stage 3 result")
    if repair_result.get("result_case_ids") != case_ids:
        fail("repair result Case set does not match the strict Stage 3 result")
    validate_ready(root, case_ids)
    protected = combined_manifest(root, case_ids, "protected")
    if manifest_sha(protected) != baseline["protected_manifest_sha256"]:
        fail("repair changed protected Case content")
    refs = combined_manifest(root, case_ids, "ref")
    if manifest_sha(refs) == baseline["before_ref_manifest_sha256"]:
        fail("repair proposal has no Ref change")
    generated = combined_manifest(root, case_ids, "generated")
    patch, changed = build_patch(root, task_dir, case_ids)
    if not changed:
        fail("repair proposal has no changed Ref path")
    (branch / "repair.patch").write_text(patch, encoding="utf-8")
    value: dict[str, Any] = {
        "schema_version": 1,
        "source_case_id": baseline["source_case_id"],
        "result_case_ids": case_ids,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "strict_result_sha256": baseline["strict_result_sha256"],
        "repair_result_sha256": sha256_file(repair_result_path),
        "before_ref_manifest_sha256": baseline["before_ref_manifest_sha256"],
        "after_ref_manifest": refs,
        "after_ref_manifest_sha256": manifest_sha(refs),
        "protected_manifest_sha256": manifest_sha(protected),
        "generated_manifest": generated,
        "generated_manifest_sha256": manifest_sha(generated),
        "changed_ref_paths": changed,
        "repair_patch_sha256": sha256_file(branch / "repair.patch"),
    }
    value["proposal_sha256"] = payload_sha(value, "proposal_sha256")
    write_json(branch / "proposal.json", value)


def validate_proposal(root: Path, task_dir: Path) -> dict[str, Any]:
    branch = task_dir / "03-repair-certify"
    value = read_json(branch / "proposal.json")
    if value.get("proposal_sha256") != payload_sha(value, "proposal_sha256"):
        fail("repair proposal self-hash is invalid")
    case_ids = value.get("result_case_ids")
    if not isinstance(case_ids, list) or not case_ids:
        fail("repair proposal has no result Cases")
    baseline = read_json(branch / "baseline.json")
    strict_path, strict_result = validate_strict_failure(task_dir)
    baseline_checks = {
        "source_case_id": strict_result.get("case_id"),
        "result_case_ids": result_case_ids(strict_result),
        "strict_result_sha256": sha256_file(strict_path),
        "before_ref_manifest_sha256": manifest_sha(
            baseline_ref_manifest(root, task_dir, case_ids)
        ),
    }
    for field, actual in baseline_checks.items():
        if baseline.get(field) != actual or value.get(field) != actual:
            fail(f"repair proposal baseline is stale: {field} changed")
    validate_ready(root, case_ids)
    checks = {
        "after_ref_manifest_sha256": manifest_sha(combined_manifest(root, case_ids, "ref")),
        "protected_manifest_sha256": manifest_sha(combined_manifest(root, case_ids, "protected")),
        "generated_manifest_sha256": manifest_sha(combined_manifest(root, case_ids, "generated")),
        "repair_result_sha256": sha256_file(branch / "result.json"),
        "repair_patch_sha256": sha256_file(branch / "repair.patch"),
    }
    for field, actual in checks.items():
        if value.get(field) != actual:
            fail(f"repair proposal is stale: {field} changed")
    return value


def approve(root: Path, task_dir: Path, approved_by: str) -> None:
    branch = task_dir / "03-repair-certify"
    approval_path = branch / "approval.json"
    if approval_path.exists():
        fail(f"repair approval already exists: {approval_path}")
    proposal_value = validate_proposal(root, task_dir)
    value: dict[str, Any] = {
        "schema_version": 1,
        "decision": "approved",
        "approved_at": datetime.now(timezone.utc).isoformat(),
        "approved_by": approved_by,
        "source_case_id": proposal_value["source_case_id"],
        "result_case_ids": proposal_value["result_case_ids"],
        "proposal_sha256": proposal_value["proposal_sha256"],
        "after_ref_manifest_sha256": proposal_value["after_ref_manifest_sha256"],
        "protected_manifest_sha256": proposal_value["protected_manifest_sha256"],
        "generated_manifest_sha256": proposal_value["generated_manifest_sha256"],
    }
    value["approval_sha256"] = payload_sha(value, "approval_sha256")
    write_json(approval_path, value)


def verify(root: Path, task_dir: Path) -> None:
    branch = task_dir / "03-repair-certify"
    proposal_value = validate_proposal(root, task_dir)
    approval_value = read_json(branch / "approval.json")
    if approval_value.get("decision") != "approved":
        fail("repair decision is not approved")
    if approval_value.get("approval_sha256") != payload_sha(approval_value, "approval_sha256"):
        fail("repair approval self-hash is invalid")
    for field in (
        "source_case_id",
        "result_case_ids",
        "proposal_sha256",
        "after_ref_manifest_sha256",
        "protected_manifest_sha256",
        "generated_manifest_sha256",
    ):
        if approval_value.get(field) != proposal_value.get(field):
            fail(f"repair approval does not match proposal field {field}")
    print(approval_value["approval_sha256"])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("snapshot", "proposal", "approve", "verify"))
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--task-dir", type=Path, required=True)
    parser.add_argument("--approved-by", default=os.environ.get("USER", "local-user"))
    args = parser.parse_args()
    root = args.root.resolve()
    task_dir = args.task_dir.resolve()
    if args.action == "snapshot":
        snapshot(root, task_dir)
    elif args.action == "proposal":
        proposal(root, task_dir)
    elif args.action == "approve":
        approve(root, task_dir, args.approved_by)
    else:
        verify(root, task_dir)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        raise SystemExit(f"repair gate error: {exc}")
