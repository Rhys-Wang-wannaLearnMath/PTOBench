#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
LOG="$ROOT/benchmarks/mig_data/serial_not_started_18_codex_01580_20260929.log"
export CODEX_BIN="${CODEX_BIN:-/tmp/codex-cli-01580-20260928/node_modules/.bin/codex}"
cd "$ROOT"

exec > >(tee -a "$LOG") 2>&1
echo "STARTED $(date -Is)"
echo "CODEX_BIN=$CODEX_BIN"
"$CODEX_BIN" --version

cases=(
  deepseek_v4.moe_expert
  deepseek_v4.moe_router
  deepseek_v4.mtp_projection
  deepseek_v4.moe_ep_ep2
  deepseek_v4.moe_ep_ep4
  deepseek_v4.moe_ep_ep8
  deepseek_v4.prefill_layer_ep8_csa
  deepseek_v4.prefill_layer_ep8_hca
  deepseek_v4.prefill_layer_ep8_swa
  deepseek_v4.prefill_moe_ep2
  deepseek_v4.prefill_moe_ep4
  deepseek_v4.prefill_moe_ep8
  deepseek_v4_flash_mtp.prefill_cp_csa_cp4
  deepseek_v4_flash_mtp.prefill_cp_csa_cp8
  deepseek_v4_flash_mtp.prefill_cp_hca_cp2
  deepseek_v4_flash_mtp.prefill_cp_hca_cp8
  deepseek_v4_flash_mtp.prefill_cp_swa_cp2
  deepseek_v4_flash_mtp.prefill_cp_swa_cp4
)

failed=0
for case_id in "${cases[@]}"; do
  echo "===== START $case_id ====="
  if ! bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id"; then
    echo "FAILED $case_id"
    failed=1
  fi
done
echo "FINISHED $(date -Is) attempted=${#cases[@]} failed=$failed"
exit "$failed"
