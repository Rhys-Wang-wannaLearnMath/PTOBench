#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
export MIGRATION_GIT_PROXY=""
if [[ "${1:-}" == --dry-run ]]; then
  python3 benchmarks/mig_workflow/prepare_progress_requeue.py
  exit 0
fi
exec 9>benchmarks/mig_workflow/.serial_queue.lock
flock -n 9 || { echo "Another serial migration queue is already running" >&2; exit 1; }
manifest="$(python3 benchmarks/mig_workflow/prepare_progress_requeue.py --apply)"
echo "Recovery manifest and archived retry records: $manifest"
mapfile -t queue < <(python3 - "$manifest" <<'PY'
import json, sys
for task in json.load(open(sys.argv[1]))['tasks']:
    print('\t'.join((task['case_id'], task['mode'], task['stage'])))
PY
)
echo "Selected ${#queue[@]} Case(s); one serial queue; one active Case"
for ((index=0; index<${#queue[@]}; index++)); do
  IFS=$'\t' read -r case_id mode stage <<<"${queue[$index]}"
  args=(--resume)
  [[ "$mode" != rework ]] || args=(--rework "$stage")
  echo "===== CASE $((index + 1))/${#queue[@]}: $case_id ${args[*]} (from $stage) ====="
  if bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" "${args[@]}"; then
    echo "COMPLETED $case_id"
  else
    echo "FAILED $case_id; continuing the serial queue"
  fi
done
echo "Serial recovery queue finished"
