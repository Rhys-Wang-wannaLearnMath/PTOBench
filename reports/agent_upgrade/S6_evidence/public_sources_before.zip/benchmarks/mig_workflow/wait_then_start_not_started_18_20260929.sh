#!/usr/bin/env bash
set -u

CURRENT_SESSION="pypto_mig_retry_codex01580_v3_20260928"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

while tmux has-session -t "$CURRENT_SESSION" 2>/dev/null; do
  sleep 30
done

exec bash benchmarks/mig_workflow/start_not_started_18_codex_01580_20260929.sh
