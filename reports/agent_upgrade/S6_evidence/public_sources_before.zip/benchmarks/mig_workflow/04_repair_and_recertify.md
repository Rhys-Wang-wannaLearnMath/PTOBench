# Optional branch after Stage 3: repair and recertify

Skill: `repair-and-recertify-pypto-case-v02`

This branch is manually invoked after strict Stage 3 stops with a reproducible
NPU Ref correctness failure. It is not an automatic seventh stage and never
runs during an ordinary migration. Strict Stage 3 remains unchanged: preserve
the selected algorithm and topology, make interface-only adaptations, and stop
normally when those constraints cannot produce a correct Ref.

Invoke the branch explicitly:

```bash
benchmarks/mig_workflow/run_migrations.sh \
  --case <family.case> --repair
```

The command requires the current strict Stage 3 result to be `FAIL` with
`owner_stage: implement-certify`. It snapshots the pre-repair Ref and protected
contract hashes, then runs the Repair skill with the same profile, execution
provider, model, reasoning, sandbox, API retry, output retry, tool-session
retry, and gpt-5.5 fallback policy as Stage 3. Its Astra bootstrap follows the
workflow-wide credential split independently of the execution provider.

## Boundary

The branch may edit only the result Case Ref, generated cached Ref outputs,
certification/performance records, its own task artifacts, and handoff. Public
contract, comparator, official source, Fixture inputs and metadata, CPU Oracle,
evaluator, environment, Candidate Seed, shared code, and unrelated Cases are
read-only.

The branch first audits source/comparator/API/toolchain evidence. It is for a
small semantics-preserving Ref lowering repair, not for loosening correctness,
changing workload meaning, repairing an Oracle to match an NPU error, or
working around unavailable infrastructure. Wrong source/contract/comparator/
Fixture/Oracle/evaluator decisions return to their normal owner.

When the Ref is multi-file, `MULTI_FILE_MIGRATION.md` still applies. The
proposal binds the full before/after manifest and may not carry unrelated
helper/resource or import-layout drift.

A branch `PASS` requires plain `bench prepare-ref` against the existing fixed
Fixture inputs, ready certification with the canonical comparator hash, and a
nonempty Ref performance record. It produces a deterministic proposal binding
the strict failure, before/after Ref manifests and patch, protected contract
hashes, certifications, and repair result. It then stops with status:

```text
AWAITING_REPAIR_APPROVAL
```

## Human gate

Review `03-repair-certify/proposal.json`, `repair.patch`, the handoff, and test
evidence. Approval is an explicit separate command:

```bash
benchmarks/mig_workflow/run_migrations.sh \
  --case <family.case> --approve-repair
```

The command re-hashes every bound artifact. Any Ref or protected-file drift
invalidates the proposal. A valid approval writes immutable `approval.json`,
archives stale Stage 4-6 evidence, and continues at Stage 4. The explicit
command is the human decision; a model cannot approve its own proposal.

Stage 4-6 accept only the exact approved Ref deviation. They still enforce
Candidate identity, closure, comparator fidelity, environment isolation,
profiling, and fresh correctness. Unapproved, stale, or additional algorithm/
topology changes fail at the owning stage.
