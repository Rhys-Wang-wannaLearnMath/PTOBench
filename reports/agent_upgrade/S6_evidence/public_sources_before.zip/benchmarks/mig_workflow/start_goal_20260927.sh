#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_goal_20260927.log"
exec >>"$LOG" 2>&1

echo "===== goal serial queue $(date -Is) ====="
queue_rc=0
while IFS= read -r case_id; do
  [[ -z "$case_id" || "$case_id" == \#* ]] && continue
  echo "CASE $case_id START $(date -Is)"
  MAX_STAGE_REWORKS=3 bash benchmarks/mig_workflow/run_migrations.sh \
    --case "$case_id" --resume
  rc=$?
  echo "CASE $case_id EXIT=$rc $(date -Is)"
  ((rc == 0)) || queue_rc=1
done < benchmarks/mig_workflow/serial_queue_goal_20260927.txt
echo "GOAL_SERIAL_EXIT=$queue_rc $(date -Is)"
exit "$queue_rc"
