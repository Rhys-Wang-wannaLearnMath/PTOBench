#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_new10_after_qkv_20260927.log"
exec >>"$LOG" 2>&1

echo "===== new10 queue waiter $(date -Is) ====="
# QKV is already running in the dedicated serial tmux. Do not overlap any
# migration or compiler/NPU work with it.
while pgrep -f '[r]un_migrations.sh --case deepseek_v4.prefill_qkv_proj_rope_v1' >/dev/null; do
  sleep 20
done

echo "QKV wrapper is idle; starting ten-case serial queue $(date -Is)"
QUEUE_EXIT=0
while IFS= read -r case_id; do
  [[ -z "$case_id" || "$case_id" == \#* ]] && continue
  echo "CASE $case_id START $(date -Is)"
  MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh \
    --case "$case_id" --resume
  rc=$?
  echo "CASE $case_id EXIT=$rc $(date -Is)"
  ((rc == 0)) || QUEUE_EXIT=1
done < benchmarks/mig_workflow/serial_queue_new10_20260927.txt

echo "NEW10_QUEUE_EXIT=$QUEUE_EXIT"
echo "===== new10 queue finished $(date -Is) ====="
exit "$QUEUE_EXIT"
