#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
RUN_ROOT="$ROOT/benchmarks/mig_data/runs"
LOG="$ROOT/benchmarks/mig_data/serial_retry_infra_codex_01540_20260928.log"
RETRY_LIMIT="${RETRY_LIMIT:-0}"
export CODEX_BIN="${CODEX_BIN:-codex}"
cd "$ROOT"

exec > >(tee -a "$LOG") 2>&1
echo "STARTED $(date -Is)"
echo "CODEX_BIN=$CODEX_BIN"
"$CODEX_BIN" --version

mapfile -t run_dirs < <(
  while IFS= read -r status_file; do
    status="$(<"$status_file")"
    case "$status" in
      API_FAILED|CODEX_SESSION_FAILED|EXEC_FAILED)
        printf '%s\n' "${status_file%/status}" ;;
    esac
  done < <(find "$RUN_ROOT" -mindepth 2 -maxdepth 2 -type f -name status | sort)
)

echo "SELECTED ${#run_dirs[@]} infrastructure-failed cases"
failed=0
started=0
for task_dir in "${run_dirs[@]}"; do
  if ((RETRY_LIMIT > 0 && started >= RETRY_LIMIT)); then
    break
  fi
  ((started += 1))
  safe="${task_dir##*/}"
  case_id="${safe/__/.}"
  echo "===== RETRY $case_id ====="
  if ! bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume; then
    echo "FAILED $case_id"
    failed=1
  fi
done
echo "FINISHED $(date -Is) attempted=$started failed=$failed"
exit "$failed"
