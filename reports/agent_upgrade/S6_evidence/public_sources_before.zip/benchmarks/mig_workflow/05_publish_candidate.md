# Stage 4: publish Candidate Seed and self-test

Skill: `publish-pypto-case-v02-candidate`

Publish the certified Ref implementation as Candidate Seed, then test it from a
fresh workspace. This stage does not redesign or optimize the implementation.

Writable paths:

```text
benchmarks/pypto_lib_bench-v0.2/cases/<family>/<case>/public/candidate_seed/**
<task-dir>/workspaces/**
<task-dir>/results/**
<task-dir>/handoff.md
```

Copy the complete final Ref tree. Rename only `ref_npu.py` to the module path
declared by `case.json` and adjust imports only where that filename makes it
unavoidable. No symlinks.
Config, comparator, Ref, Oracle, evaluator, fixtures, certification, common
infrastructure, and unrelated Cases are read-only.

Before publication, require either a strict Stage 3 `PASS`, or a valid
hash-bound human Repair approval produced by the optional branch. In both cases
require ready certification whose recorded comparator SHA-256 matches the
canonical public JSON. Re-verify an approval before copying; stale or missing
approval is a Stage 3 defect. A missing/mismatched certification hash is also a
Stage 3 defect; do not refresh it or rerun `prepare-ref` here. Every fresh Candidate
evaluation must exercise the canonical comparator through that Case's sealed
evaluator. Before launching it, read-only verify that `evaluate.py` itself owns
JSON parsing, strict validation, dispatch for every method declared by the
canonical JSON, and PASS/FAIL execution and does not call shared/family
comparator-semantic code. Unused local standard-method branches are permitted
and need no Stage 4 testing; they must not affect the active callbacks. A defect
returns to Stage 3; this stage does not repair it.

For a multi-file tree, compare sorted file manifests after the entry mapping,
byte-compare every same-path helper/resource, and record the minimal entry diff.
Preserve package markers, resource files and relative layout. Reject logs,
build output, dumps, absolute developer paths and cross-Case imports. Canonical
`__pycache__/` and `*.pyc` files are allowed and ignored by this audit.
Also reconcile every path and isolation check required by
`MULTI_FILE_MIGRATION.md`; a recursive copy or equal file count is insufficient.

For every result Case, run fresh `bench init` and clean `bench evaluate`. Then
read the complete supported profiling set from
`evaluator/profile_modes.py:PROFILE_MODES`, attempt each one, and record a
status for each. The current commands are `bench profile runtime`, `bench
profile hardware` and `bench profile compile`. Inspect result JSON and isolated
mode artifacts, not only exit status. If a mode is genuinely unavailable for
the Case/platform, record `UNSUPPORTED` and the short reason; an unexpected
error is `FAIL` and names its owner. Finally rerun clean `bench evaluate` and
confirm it is the official clean score. Clean evaluation is the pass gate, so a
Case may pass with `Profiling: PARTIAL`; correctness failure still stops the
stage. Do not repair an earlier stage here.

When an approved Repair exists, copy the exact approved Ref. Record the
approval/proposal hashes in the handoff and fail if the current Ref contains
any additional change beyond the approved manifest. Human approval permits
only that recorded deviation; it does not relax Candidate identity or runtime
qualification.

Never use `bench fork` for this self-test: it copies a parent workspace, not the
canonical seed. Verify the initialized workspace binding and `starting_point/`
snapshot. Initial and final clean runs must use `phase=all`, contain positive
configured timing samples, and keep build output under the workspace's
`.benchmark_outputs/clean/`; an explicit `--result` relocates only summary JSON.

Use each mode's one-shot `correctness` phase. Profiling validates that the mode
runs and emits real diagnostics; do not run or require performance samples.
Run clean evaluation, each profiling mode, and final clean strictly
sequentially on the selected device.

## Prompt

```text
Use $publish-pypto-case-v02-candidate for <CASE_ID>. Read the shared contract and
handoff. Copy each certified Ref implementation tree to candidate_seed, changing
only ref_npu.py to the module declared by case.json and unavoidable imports. Do
not optimize it.
Use a fresh workspace for init and clean evaluate, then attempt every mode
declared by PROFILE_MODES (currently runtime, hardware and compile), inspect
each result and artifact directory, assign `PASS`, `UNSUPPORTED`, or `FAIL`,
and finish with a second clean evaluate. Only Candidate Seed and task-run
artifacts are writable. Report failures to the owning stage without repairing
outside this boundary. The stage may return PASS when clean evaluate passes and
the handoff clearly says `Profiling: PARTIAL`.
```
