#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_followup_20260927.log"
exec >>"$LOG" 2>&1

echo "===== follow-up queue waiting $(date -Is) ====="
# The active recovery queue and its explicit CSA tail must finish first.
while pgrep -f '[r]un_migrations.sh --all --cases-file benchmarks/mig_workflow/rework_queue_20260926' >/dev/null \
   || pgrep -f '[r]un_migrations.sh --case deepseek_v4.decode_attention_csa --rework implement-certify' >/dev/null; do
  sleep 20
done

QUEUE_EXIT=0
run_repair() {
  local case_id="$1"
  MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --repair
  local rc=$?
  echo "$case_id REPAIR_EXIT=$rc"
  ((rc == 0)) || QUEUE_EXIT=1
}

# Repair is deliberately invoked through the workflow so proposals, hashes,
# approval gates, and later stages remain governed by the migration skills.
run_repair deepseek_v4.prefill_qkv_proj_rope_v1

# CSA is not a correctness-only repair: DEMO/FLASH fail compilation and PRO
# fails allocator lowering. Keep it on the owning Stage 3 rework path.
MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.decode_attention_csa --rework implement-certify
rc=$?
echo "deepseek_v4.decode_attention_csa REWORK_EXIT=$rc"
((rc == 0)) || QUEUE_EXIT=1

# Continue with ten new Cases serially. A failure is recorded and does not
# allow a later Case to run concurrently with the failed one.
while IFS= read -r case_id; do
  [[ -z "$case_id" || "$case_id" == \#* ]] && continue
  [[ "$case_id" == deepseek_v4.prefill_qkv_proj_rope_v1 || "$case_id" == deepseek_v4.decode_attention_csa ]] && continue
  MAX_STAGE_REWORKS=4 bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume
  rc=$?
  echo "$case_id RESUME_EXIT=$rc"
  ((rc == 0)) || QUEUE_EXIT=1
done < benchmarks/mig_workflow/serial_queue_followup_20260927.txt

echo "FOLLOWUP_QUEUE_EXIT=$QUEUE_EXIT"
echo "===== follow-up queue finished $(date -Is) ====="
exit "$QUEUE_EXIT"
