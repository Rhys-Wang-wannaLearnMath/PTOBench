# Comparator reconciliation policy

This policy is authoritative for every v0.2 migration stage. It separates the
fixed workload selected for migration from later upstream improvements to that
workload's correctness comparator.

## 1. Fixed workload, current comparator evidence

Stage 1 first selects one coherent workload source as required by the common
migration contract. That selection fixes the implementation semantics, ABI,
outputs, shapes, layouts, dtypes, state, Fixture construction, input
distribution, and CPU golden/Oracle behavior. Comparator reconciliation must
not upgrade any of those items.

After fixing that baseline, inspect the comparator at the current upstream
default-branch commit. Record the repository URL, full commit, retrieval date,
path, entry, runner, and relevant commit or pull-request rationale. Follow file
renames. If the exact workload was removed, inspect both its last upstream
revision and any identifiable current successor; do not pretend a related
family member is the same Case.

The selected historical comparator is the baseline. The final v0.2 comparator
is that baseline plus every applicable semantic change found in the latest
upstream evidence.

## 2. Reconcile semantic changes, not lines or numbers

Build a semantic diff between the baseline and latest upstream comparator.
Group changes that depend on each other. A group may include:

- the comparison method;
- all method parameters, including `rtol`, `atol`, and `max_error_ratio`;
- casts, reshapes, slices, masks, valid-region selection, and NaN/Inf handling;
- the error-ratio denominator and aggregation scope;
- dependencies between multiple outputs.

Treat a coupled group atomically. For example, changing `allclose` to
`ratio_allclose` and adding `max_error_ratio` is one group; a tolerance derived
for a new cast or mask cannot be adopted without that cast or mask. Independent
groups and independent outputs may receive different decisions.

For every group choose exactly one decision:

- `ADOPT`: all assumptions already hold for the fixed migration workload, and
  the behavior can be represented faithfully using its existing inputs and
  outputs through `public/comparator.json` and the Case evaluator.
- `KEEP_SELECTED`: any assumption depends on changing the selected source,
  Ref/Candidate algorithm, ABI, output meaning, shape/layout, dtype, state,
  Fixture data/distribution, or CPU golden/Oracle. Keep the baseline behavior
  for this group and state the failed assumption.

If evidence is unavailable or contradictory, Stage 1 is not allowed to guess a
decision. Return `BLOCKED` for unavailable upstream infrastructure or `FAIL`
for an incomplete/contradictory migration analysis.

The fact that Python code can implement a rule in only two files is necessary
but not sufficient for `ADOPT`: the rule's semantic assumptions must already
be true. Never adopt a looser rule because the current Ref or Candidate fails.

## 3. Required Stage 1 record

For every result Case, the handoff must contain:

```text
upstream repository | upstream commit | retrieval date
selected comparator path/commit | latest comparator path/commit
output or comparison group | selected behavior | upstream change
dependency group | ADOPT/KEEP_SELECTED | applicability evidence
final method and complete parameters | evaluator behavior required
```

The table must account for every correctness output and every semantic change.
It must distinguish an unchanged upstream rule from a rule that was examined
and rejected. A source-shared analysis may be reused by sibling preset Cases
only after checking each sibling's fixed output contract and preset-dependent
assumptions.

## 4. Public JSON contract

`public/comparator.json` is the complete machine-readable PASS/FAIL contract.
It has no implicit defaults:

```json
{
  "schema_version": 1,
  "outputs": {
    "out": {
      "method": "ratio_allclose",
      "rtol": 0.003,
      "atol": 0.003,
      "max_error_ratio": 0.02
    }
  }
}
```

The standard methods and exact fields are:

| method | required fields | meaning |
| --- | --- | --- |
| `exact` | `method` | `torch.equal`; no tolerance or ratio fields |
| `allclose` | `method`, `rtol`, `atol` | every element satisfies the declared tolerance |
| `ratio_allclose` | `method`, `rtol`, `atol`, `max_error_ratio` | the declared fraction of elements may exceed the declared tolerance |

`rtol` and `atol` must be finite and nonnegative.
`max_error_ratio` must be finite and in `[0, 1]`. Every output named by
`case.json.correctness.outputs` appears exactly once, and no other output may
appear. Do not use an implicit `default`, mix `kind` and `method`, add ignored
fields, or hide fixed comparison semantics in Python constants.

Use `custom` only when official behavior is genuinely not expressible by a
standard method. A custom rule must name its Case-local implementation and
declare every fixed parameter needed to reproduce the decision. Its complete
cross-output, preprocessing, special-value, and aggregation semantics belong
in the Stage 1 record.

## 5. Evaluator execution contract

Every Case-local `evaluate.py` owns its complete active comparator execution
boundary, including reading `public/comparator.json`, validating its top-level
schema and exact output coverage, validating every method actually declared by
that JSON with its complete fields and numeric ranges, constructing exactly the
declared callbacks, and executing their PASS/FAIL rules. This responsibility is
deliberately duplicated between Cases: do not add a shared comparator factory,
method registry, schema dispatcher, or family helper to `evaluator/common.py`
or `evaluator/workflow.py` merely to remove repetition. Shared code may provide
generic JSON/file utilities, but it must not interpret comparator methods or
fields.

Implementation scope is explicit:

- a Case evaluator must implement and test every method used by its current
  canonical `public/comparator.json`;
- it is not required to implement or test a standard method that its current
  JSON does not use;
- it may retain local implementations of other standard methods. Such unused
  branches are permitted compatibility code, are not part of the active Case
  policy, need no acceptance coverage, and must not affect callback selection
  or PASS/FAIL;
- an undeclared `custom` comparator is not permitted as compatibility code.
  Implement custom behavior only when Stage 1 approved it and the canonical
  JSON declares it.

Whenever one of the standard methods is declared, its implementation has these
exact semantics:

- `exact`: `torch.equal`;
- `allclose`: every element satisfies `atol + rtol * abs(expected)` using the
  declared finite nonnegative values;
- `ratio_allclose`: compare FP32 views, reject non-finite values, count elements
  exceeding `atol + rtol * abs(expected)`, and pass when the count is at most
  `round(max_error_ratio * numel)`.

The local evaluator must reject methods outside the supported standard methods
and approved custom methods, missing or extra fields for the method selected by
JSON, invalid numeric values, missing outputs, and undeclared outputs. It must
not substitute `ratio_allclose(..., max_error_ratio=0)` for declared
`allclose`, ignore `method`, override a JSON value, or rely on the runner's
fallback `rtol`/`atol` as hidden per-output policy. Fixed PASS/FAIL values live
only in JSON; local Python contains implementation mechanics, not a second
policy. The presence of an unused standard-method branch does not authorize an
implicit default or a callback not named by the canonical JSON.

The current runner invokes every callback with fallback keyword arguments
including `rtol` and `atol`. A callback must not capture JSON policy values in
formal parameters with those names, because the runner will silently replace
the captured defaults. Capture them lexically or under non-colliding names such
as `policy_rtol` and `policy_atol`, and absorb unrelated runner keywords through
`**kwargs`. Focused tests must invoke the callback with deliberately conflicting
runner fallback values and prove that the JSON policy still controls PASS/FAIL.

A custom comparator is also Case-local. It may inspect the callback's existing
`actual_outputs`, `expected_outputs`, and `inputs`, but it may not obtain new
Fixture data, change the Oracle, or silently extend the output ABI. Diagnostic
text may report mismatches, maxima, and sample coordinates, but diagnostics
must not introduce an undeclared PASS/FAIL condition.

Stage 3 proves the active contract with focused tests or inspection in every
result Case: every method and field in the canonical JSON affects execution as
declared, the constructed callback names exactly match the correctness outputs,
no evaluator constant changes the decision outside JSON/custom policy, and no
comparator semantic implementation is imported from shared benchmark code.
The proof must exercise the callback through the current runner keyword shape,
not only call it as `compare(actual, expected)`.
Stage 3 does not need to exercise unused standard-method branches.

## 6. Certification and stale evidence

`prepare-ref` compares the NPU Ref with the CPU Oracle using the final public
comparator, then caches the accepted NPU Ref outputs. Certification records the
SHA-256 of the exact comparator bytes. Candidate evaluation must reject a
missing or mismatched comparator hash before using cached outputs.

A comparator-only change does not alter deterministic Fixture inputs. It does
invalidate the previous correctness decision, cached Ref outputs as certified
evidence, certification, Ref performance record, Candidate results, profiling
results, and downstream acceptance workspaces. Rerun `prepare-ref`, then use
fresh Stage 4 and Stage 6 workspaces. Regenerate Fixture inputs only when their
own source/config/builder/seed contract changed, using
`prepare-ref --regenerate-fixtures`; plain `prepare-ref` reuses complete inputs
and rewrites the cached `fixtures/fixture_000/out/` outputs.

## 7. Stage ownership

- Stage 1 discovers current upstream evidence, builds the grouped semantic
  diff, makes every `ADOPT`/`KEEP_SELECTED` decision, and specifies the final
  complete comparator. It is read-only except for the handoff.
- Stage 2 writes exactly that decision to `public/comparator.json`. It does not
  reinterpret upstream evidence or implement evaluator callbacks.
- Stage 3 implements the complete parsing, validation, and execution boundary
  for every standard/custom method declared by the Case independently in each
  `evaluate.py`, runs focused checks for that active contract, and performs
  fresh Ref certification. It never changes the public comparator to make
  execution pass. Unused standard methods may remain but are not required.
- Stage 4 publishes unchanged Ref code and tests the already certified
  comparator from fresh workspaces. It does not repair comparator or evaluator
  defects.
- Stage 5 verifies comparator/evaluator/validation support did not enter the
  editable Ref or Candidate closure.
- Stage 6 independently repeats provenance, applicability, JSON/evaluator
  fidelity, certification-hash, and fresh-runtime checks. It assigns a defect
  to the earliest owning stage and never repairs it.

Certification formats and workflow changes are infrastructure maintenance
outside one Case migration. Comparator parsing, schema validation, method
dispatch, and PASS/FAIL execution are not shared infrastructure: they belong to
the owning Case evaluator and must not be moved into common code during a Case
migration.
