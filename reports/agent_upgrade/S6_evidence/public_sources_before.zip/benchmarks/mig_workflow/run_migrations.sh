#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
# Migration workers use direct network access.  Do not source the interactive
# mihomo helpers or inherit proxy variables into Codex/API subprocesses.
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
INVENTORY="$ROOT/benchmarks/mig_data/case_migration_inventory.md"
RUN_ROOT="$ROOT/benchmarks/mig_data/runs"
SCHEMA="$ROOT/benchmarks/mig_workflow/migration_result.schema.json"
RESULT_VALIDATOR="$ROOT/benchmarks/mig_workflow/validate_stage_result.py"
BOOTSTRAP_VALIDATOR="$ROOT/benchmarks/mig_workflow/validate_bootstrap.py"
REPAIR_GATE="$ROOT/benchmarks/mig_workflow/repair_gate.py"
PROFILES_ROOT="$ROOT/benchmarks/mig_workflow/profiles_codex"
MIMO_PROFILE="$PROFILES_ROOT/gpt-5.6-sol-high-mimo"
PACKY_PROFILE="$PROFILES_ROOT/gpt-5.6-sol-high-packycode-s3"
GLM_PROFILE="$PROFILES_ROOT/glm-5.3-flash-max"
MIMO_ASTRA_CODEX_PROVIDER="mimo_astra"
MIMO_SOL_CODEX_PROVIDER="mimo_sol"
ASTRA_PROFILE="$MIMO_PROFILE"
ASTRA_PROVIDER="b8dfaa37-58ed-4dec-9ea3-6807ed870ac8"
ASTRA_CODEX_PROVIDER="$MIMO_ASTRA_CODEX_PROVIDER"
# Shaobianer is the fallback for both MIMO Astra and Packy Sol paths.
ASTRA_FALLBACK_PROFILE="$PROFILES_ROOT/gpt-5.6-sol-high-shaobianer-plus8-1"
ASTRA_FALLBACK_PROVIDER="aa1c0c9f-7aa4-4fe2-8cc7-add9ea37588d-copy"
ASTRA_FALLBACK_CODEX_PROVIDER="astra_shaobianer"
MIMO_SOL_API_KEY_FILE="${MIMO_SOL_API_KEY_FILE:-$MIMO_PROFILE/.secrets/mimo_sol_api_key}"
MODEL=""
LIMIT=1
FORCE=0
DRY_RUN=0
RENAME=1
REWORK=""
RESUME=0
REPAIR=0
APPROVE_REPAIR=0
MAX_STAGE_REWORKS="${MAX_STAGE_REWORKS:-3}"
MAX_CODEX_SESSION_RETRIES="${MAX_CODEX_SESSION_RETRIES:-8}"
MAX_CODEX_MODEL_FALLBACK_RETRIES="${MAX_CODEX_MODEL_FALLBACK_RETRIES:-3}"
MAX_API_RETRIES="${MAX_API_RETRIES:-6}"
MAX_API_THREAD_RESUMES="${MAX_API_THREAD_RESUMES:-2}"
API_RETRY_BACKOFF_BASE_SECONDS="${API_RETRY_BACKOFF_BASE_SECONDS:-2}"
API_RETRY_BACKOFF_MAX_SECONDS="${API_RETRY_BACKOFF_MAX_SECONDS:-5}"
MAX_OUTPUT_RETRIES="${MAX_OUTPUT_RETRIES:-2}"
# Final, low-complexity safety net after the MIMO fallback is exhausted.
API_FALLBACK_PROVIDER="$ASTRA_FALLBACK_PROVIDER"
API_FALLBACK_PROFILE="$ASTRA_FALLBACK_PROFILE"
STAGE5_SECONDARY_PROVIDER="aa1c0c9f-7aa4-4fe2-8cc7-add9ea37588d-copy"
STAGE5_SECONDARY_PROFILE="$PROFILES_ROOT/gpt-5.6-sol-high-shaobianer-plus8-1"
CODEX_FIRST_EVENT_TIMEOUT_SECONDS="${CODEX_FIRST_EVENT_TIMEOUT_SECONDS:-${CODEX_TOOL_START_TIMEOUT_SECONDS:-120}}"
CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS="${CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS:-${CODEX_TOOL_START_TIMEOUT_SECONDS:-120}}"
CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS="${CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS:-300}"
CODEX_INACTIVITY_TIMEOUT_SECONDS="${CODEX_INACTIVITY_TIMEOUT_SECONDS:-3600}"
CODEX_BIN="${CODEX_BIN:-codex}"
MIGRATION_GIT_PROXY="${MIGRATION_GIT_PROXY:-}"
BOOTSTRAP_MODEL="${BOOTSTRAP_MODEL:-gpt-6.1-sol}"
BOOTSTRAP_REASONING="${BOOTSTRAP_REASONING:-high}"
REQUESTED=()
CASES_FILE=""

MAIN_STAGE_COUNT=6
REPAIR_INDEX=6
STAGE_KEYS=(analyze contract implement-certify publish closure-audit accept repair-certify)
STAGE_DIRS=(01-analyze 02-contract 03-implement-certify 04-publish 05-closure-audit 06-accept 03-repair-certify)
STAGE_SANDBOXES=(workspace-write workspace-write danger-full-access danger-full-access danger-full-access danger-full-access danger-full-access)
STAGE_PROVIDERS=(
  58e86975-9b43-4e24-b1ee-2cddb52a6ebb
  58e86975-9b43-4e24-b1ee-2cddb52a6ebb
  aa1c0c9f-7aa4-4fe2-8cc7-add9ea37588d-copy
  e3c77ec9-0be4-477e-a4fa-e17669e47326
  58e86975-9b43-4e24-b1ee-2cddb52a6ebb
  58e86975-9b43-4e24-b1ee-2cddb52a6ebb
  aa1c0c9f-7aa4-4fe2-8cc7-add9ea37588d-copy
)
STAGE_PROFILES=(
  "$PROFILES_ROOT/gpt-5.6-sol-high-packycode-s3"
  "$PROFILES_ROOT/gpt-5.6-sol-high-packycode-s3"
  "$PACKY_PROFILE"
  "$GLM_PROFILE"
  "$PROFILES_ROOT/gpt-5.6-sol-high-packycode-s3"
  "$PROFILES_ROOT/gpt-5.6-sol-high-packycode-s3"
  "$PACKY_PROFILE"
)
# Manual recovery is opt-in and scoped to Stage 6.  It is useful when the
# configured acceptance provider is unavailable, while keeping the normal
# provider/profile policy unchanged for every unattended run.
if [[ -n "${MIGRATION_ACCEPT_PROFILE_OVERRIDE:-}" ]]; then
  STAGE_PROFILES[5]="$MIGRATION_ACCEPT_PROFILE_OVERRIDE"
  if [[ -n "${MIGRATION_ACCEPT_PROVIDER_OVERRIDE:-}" ]]; then
    STAGE_PROVIDERS[5]="$MIGRATION_ACCEPT_PROVIDER_OVERRIDE"
  fi
fi
STAGE_MODELS=(
  gpt-6.1-sol
  gpt-6.1-sol
  gpt-6.1-sol
  glm-5.3-flash
  gpt-6.1-sol
  gpt-6.1-sol
  gpt-6.1-sol
)
STAGE_REASONING=(high high high max high high high)
STAGE_SKILLS=(
  analyze-pypto-case-v02-migration
  build-pypto-case-v02-contract
  implement-and-certify-pypto-case-v02
  publish-pypto-case-v02-candidate
  audit-pypto-case-v02-closure
  verify-pypto-case-v02-migration
  repair-and-recertify-pypto-case-v02
)
STAGE_DOCS=(
  02_analyze.md
  03_contract.md
  04_implement_and_certify.md
  05_publish_candidate.md
  06_closure_audit.md
  06_accept.md
  04_repair_and_recertify.md
)

usage() {
  cat <<'EOF'
Usage: run_migrations.sh [options]

Run six focused Codex stages for the next unfinished source Case. Cases follow
the inventory's suggested-batch and row order and are never run in parallel.

  --case FAMILY.CASE       Select one Case; FAMILY/CASE is also accepted
  --cases-file FILE        Select Case IDs from a file, one per line
  --limit N                Run the next N selected Cases (default: 1)
  --all                    Run all selected Cases sequentially
  --inventory FILE         Use another inventory Markdown file
  --model MODEL            Override the configured model for every stage
  --run-dir DIR            Store prompts, sessions, logs and status here
  --force                  Rerun completed stages and Cases
  --rework STAGE           Rerun from STAGE through final acceptance; use "owner"
                           to infer the owning stage from the failed result
  --resume                 Continue explicit Cases from their first missing Stage;
                           reject an existing non-PASS Stage result as rework
  --repair                 Run the optional, human-gated Repair branch after an
                           eligible strict Stage 3 correctness failure
  --approve-repair         Approve the exact hash-bound Repair proposal and
                           continue the six-stage workflow from Stage 4
  --no-rename              Do not rename Codex sessions
  --dry-run                Write all stage prompts and print the plan only
  -h, --help               Show this help

An Astra bootstrap API/network failure on shaobianer switches immediately to
AIxuanHub. AIxuanHub then receives a fresh six-retry API budget with the same
backoff and same-thread resume policy; shaobianer's consumed attempts do not
count against it. An API/network failure on the mimo profile is retried twice
on that profile; other execution profiles are retried once on their current
profile. The dedicated execution API fallback profile is used after those
same-profile retries, for up to six total API retries.
API retries are separate from tool/session retries.
Publish starts on glm-5.3-flash/max. If that execution fails without a valid
Stage result, it starts a fresh thread on the Shaobianer profile using
gpt-6.1-sol/high. API errors before tool execution consume API retries, not
tool/session retries. Valid content failures remain normal Stage outcomes.
Invalid stage-result JSON is retried up to two times on the same stage and is
separate from API, tool/session, model fallback, and rework counts.
A gpt-5.6-sol thread that receives no execution tools or stops producing events
is recreated up to 8 times using that stage's configured profile (9 attempts
including the initial thread). Once those retries are exhausted, gpt-5.5 with
xhigh reasoning receives up to 3 additional attempts. These session retries
are separate from Stage rework. Content failures from closure audit/final
acceptance can automatically rework their named owner.
EOF
}

while (($#)); do
  case "$1" in
    --case) REQUESTED+=("$2"); shift 2 ;;
    --cases-file) CASES_FILE="$2"; shift 2 ;;
    --limit) LIMIT="$2"; shift 2 ;;
    --all) LIMIT=0; shift ;;
    --inventory) INVENTORY="$2"; shift 2 ;;
    --model) MODEL="$2"; shift 2 ;;
    --run-dir) RUN_ROOT="$2"; shift 2 ;;
    --force) FORCE=1; shift ;;
    --rework) REWORK="$2"; shift 2 ;;
    --resume) RESUME=1; shift ;;
    --repair) REPAIR=1; shift ;;
    --approve-repair) APPROVE_REPAIR=1; shift ;;
    --no-rename) RENAME=0; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

mode_count=$((FORCE + RESUME + REPAIR + APPROVE_REPAIR))
[[ -z "$REWORK" ]] || ((mode_count += 1))
if ((mode_count > 1)); then
  echo "--force, --rework, --resume, --repair, and --approve-repair are mutually exclusive" >&2
  exit 2
fi
if [[ -n "$REWORK" ]] && ((${#REQUESTED[@]} == 0)) && [[ -z "$CASES_FILE" ]]; then
  echo "--rework requires --case or --cases-file" >&2
  exit 2
fi
if ((RESUME)) && ((${#REQUESTED[@]} == 0)) && [[ -z "$CASES_FILE" ]]; then
  echo "--resume requires --case or --cases-file" >&2
  exit 2
fi
if ((REPAIR || APPROVE_REPAIR)) && ((${#REQUESTED[@]} == 0)) && [[ -z "$CASES_FILE" ]]; then
  echo "--repair and --approve-repair require --case or --cases-file" >&2
  exit 2
fi

[[ "$LIMIT" =~ ^[0-9]+$ ]] || {
  echo "--limit must be a non-negative integer" >&2
  exit 2
}
command -v "$CODEX_BIN" >/dev/null || { echo "codex CLI not found: $CODEX_BIN" >&2; exit 1; }
[[ "$MAX_CODEX_SESSION_RETRIES" =~ ^[0-9]+$ ]] || {
  echo "MAX_CODEX_SESSION_RETRIES must be a non-negative integer" >&2
  exit 2
}
[[ "$MAX_CODEX_MODEL_FALLBACK_RETRIES" =~ ^[0-9]+$ ]] || {
  echo "MAX_CODEX_MODEL_FALLBACK_RETRIES must be a non-negative integer" >&2
  exit 2
}
[[ "$MAX_API_RETRIES" =~ ^[1-9][0-9]*$ ]] || {
  echo "MAX_API_RETRIES must be a positive integer" >&2
  exit 2
}
[[ "$MAX_API_THREAD_RESUMES" =~ ^[0-9]+$ ]] || {
  echo "MAX_API_THREAD_RESUMES must be a non-negative integer" >&2
  exit 2
}
[[ "$MAX_OUTPUT_RETRIES" =~ ^[0-9]+$ ]] || {
  echo "MAX_OUTPUT_RETRIES must be a non-negative integer" >&2
  exit 2
}
[[ "$CODEX_FIRST_EVENT_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] || {
  echo "CODEX_FIRST_EVENT_TIMEOUT_SECONDS must be a positive integer" >&2
  exit 2
}
[[ "$CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] || {
  echo "CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS must be a positive integer" >&2
  exit 2
}
[[ "$CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] || {
  echo "CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS must be a positive integer" >&2
  exit 2
}
[[ "$CODEX_INACTIVITY_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]] || {
  echo "CODEX_INACTIVITY_TIMEOUT_SECONDS must be a positive integer" >&2
  exit 2
}
[[ -f "$SCHEMA" ]] || { echo "missing output schema: $SCHEMA" >&2; exit 1; }
[[ -f "$RESULT_VALIDATOR" ]] || { echo "missing result validator: $RESULT_VALIDATOR" >&2; exit 1; }
[[ -f "$BOOTSTRAP_VALIDATOR" ]] || { echo "missing bootstrap validator: $BOOTSTRAP_VALIDATOR" >&2; exit 1; }
[[ -f "$REPAIR_GATE" ]] || { echo "missing Repair gate: $REPAIR_GATE" >&2; exit 1; }
for profile in "${STAGE_PROFILES[@]}"; do
  [[ -f "$profile/config.toml" && -f "$profile/auth.json" ]] || {
    echo "incomplete Codex profile: $profile" >&2
    exit 1
  }
done
[[ -f "$API_FALLBACK_PROFILE/config.toml" && -f "$API_FALLBACK_PROFILE/auth.json" ]] || {
  echo "incomplete API fallback Codex profile: $API_FALLBACK_PROFILE" >&2
  exit 1
}
[[ -f "$ASTRA_PROFILE/config.toml" && -f "$ASTRA_PROFILE/auth.json" ]] || {
  echo "incomplete Astra Codex profile: $ASTRA_PROFILE" >&2
  exit 1
}

codex_provider_for_phase() {
  local profile="$1" phase="$2"
  if [[ "$profile" == "$MIMO_PROFILE" ]]; then
    if [[ "$phase" == bootstrap ]]; then
      printf '%s\n' "$MIMO_ASTRA_CODEX_PROVIDER"
    else
      printf '%s\n' "$MIMO_SOL_CODEX_PROVIDER"
    fi
  else
    printf '%s\n' custom
  fi
}

load_mimo_sol_api_key() {
  local key="${MIMO_SOL_API_KEY:-}"
  if [[ -z "$key" ]]; then
    [[ -r "$MIMO_SOL_API_KEY_FILE" ]] || {
      echo "missing Mimo Sol API key file: $MIMO_SOL_API_KEY_FILE" >&2
      return 1
    }
    IFS= read -r key <"$MIMO_SOL_API_KEY_FILE" || true
    key="${key%$'\r'}"
  fi
  if [[ -z "$key" || "$key" == REPLACE_WITH_MIMO_SOL_API_KEY ]]; then
    echo "Mimo Sol API key is not configured; write it to $MIMO_SOL_API_KEY_FILE" >&2
    return 1
  fi
  printf '%s' "$key"
}

load_astra_api_key() {
  local profile="${1:-$ASTRA_PROFILE}"
  python3 - "$profile/auth.json" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as handle:
    key = json.load(handle).get("OPENAI_API_KEY", "")
if not key:
    raise SystemExit(1)
print(key)
PY
}

refresh_upstream_main() {
  local refspec="+refs/heads/main:refs/remotes/upstream/main"
  if [[ "${MIGRATION_SKIP_UPSTREAM_REFRESH:-0}" == 1 ]]; then
    return 0
  fi
  if git -C "$ROOT" -c "http.proxy=$MIGRATION_GIT_PROXY" \
      fetch --no-tags upstream "$refspec"; then
    echo "UPSTREAM main refreshed to $(git -C "$ROOT" rev-parse refs/remotes/upstream/main)"
    return 0
  fi
  echo "WARNING: could not refresh upstream/main outside the Codex sandbox; Stage 1 will record current network evidence" >&2
  return 0
}

normalize_case() {
  local value="${1//\//.}"
  [[ "$value" =~ ^[A-Za-z0-9_-]+\.[A-Za-z0-9_.-]+$ ]] || {
    echo "invalid Case ID: $1" >&2
    return 2
  }
  printf '%s\n' "$value"
}

inventory_cases() {
  [[ -f "$INVENTORY" ]] || {
    echo "missing inventory: $INVENTORY" >&2
    return 1
  }
  awk -F'|' '
    /^\|/ {
      case_id=$2; migrated=$3; batch=$11
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", case_id)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", migrated)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", batch)
      if (case_id != "case_id" && migrated == "否" && batch ~ /^[0-9]+$/) {
        printf "%06d\t%09d\t%s\n", batch, NR, case_id
      }
    }
  ' "$INVENTORY" | sort -n -k1,1 -k2,2 | cut -f3
}

if ((${#REQUESTED[@]})); then
  RAW_CASES=("${REQUESTED[@]}")
elif [[ -n "$CASES_FILE" ]]; then
  mapfile -t RAW_CASES < <(sed -e 's/#.*//' -e '/^[[:space:]]*$/d' "$CASES_FILE")
else
  mapfile -t RAW_CASES < <(inventory_cases)
fi

CASES=()
for raw_case in "${RAW_CASES[@]}"; do
  case_id="$(normalize_case "$raw_case")"
  safe="${case_id/./__}"
  if ((FORCE == 0 && RESUME == 0 && REPAIR == 0 && APPROVE_REPAIR == 0)) && \
      [[ -z "$REWORK" ]] && [[ -f "$RUN_ROOT/$safe/status" ]]; then
    continue
  fi
  CASES+=("$case_id")
  if ((LIMIT > 0 && ${#CASES[@]} >= LIMIT)); then
    break
  fi
done

((${#CASES[@]})) || { echo "no unfinished Cases selected"; exit 0; }
mkdir -p "$RUN_ROOT"

write_prompt() {
  local case_id="$1" task_dir="$2" safe="$3" index="$4"
  local stage="${STAGE_KEYS[$index]}"
  local skill="${STAGE_SKILLS[$index]}"
  local doc="${STAGE_DOCS[$index]}"
  local stage_dir="$task_dir/${STAGE_DIRS[$index]}"
  mkdir -p "$stage_dir"

  cat >"$stage_dir/prompt.txt" <<EOF
Task label: migrate-$safe-$stage

Use \$$skill to perform only stage "$stage" for source Case $case_id.
Read completely:
  benchmarks/mig_workflow/CASE_MIGRATION_CONTRACT.md
  benchmarks/mig_workflow/MULTI_FILE_MIGRATION.md
  benchmarks/mig_workflow/$doc
  $task_dir/handoff.md

The stage document and Skill define the exact writable paths. Treat every other
path as read-only. Do not repair work owned by another stage, do not edit shared
evaluator code or an existing environment profile used by other Cases, and do
not touch workflow/Skill code or unrelated Cases. A new Case-specific environment
JSON is writable only in Stages 2-3 under their documented conditions.
If an earlier-stage defect prevents this stage, append concise evidence to the
handoff, set owner_stage to that stage, return FAIL, and stop. In the closure
audit and final acceptance stages, content failures must identify the earliest
stage that owns the repair in owner_stage; the orchestrator automatically
reworks from that stage and reruns every downstream stage. Never set
owner_stage to accept or closure-audit for a content failure.
If unavailable external infrastructure owns the failure, set owner_stage to
infrastructure and return BLOCKED, even when an individual check or profiling
mode has status FAIL.

This migration is Case-specific. Inspect actual source, symbols, dependencies,
ABI and artifacts required by this stage; do not mechanically copy a related
Case. Preserve algorithms, topology, shapes, state and correctness semantics.
When the selected source has named complete presets, Stage 1 must account for
every preset and split distinct contracts that can be instantiated by config
binding alone, even when one preset is the source's default. A sibling series
uses explicit, symmetric preset suffixes for every result Case (for example,
base_demo, base_flash, and base_pro); the source's default preset must not keep
the unsuffixed base name. Stage 2 must keep each directory, case_id, description,
dynamic module identity, and generated certification identity consistent.
When a real separate original_config.py exists, public config preserves the
source-shaped config class, exactly one selected preset, CASE_CONFIG, and then
fixed operator bindings; it is not minimized to Candidate imports and does not
fold meaningful Case-relevant derivations into literals. Keep their source
operands and expressions, while excluding derivation branches owned only by
other workloads. Do not copy unrelated sibling presets or implementation tuning knobs. Preserved official
source/dependencies must be byte-exact, use original_config.py for a real source
config dependency, and include SHA-verified source_provenance.json.
For implementation/publication/closure-audit/acceptance stages, preserve and verify any real
multi-file closure using MULTI_FILE_MIGRATION.md, including its per-file ledger,
import/resource isolation, normalized manifests, and global result-ID collision
rules. Publication and acceptance must test every mode declared by
  evaluator/profile_modes.py:PROFILE_MODES, then rerun clean evaluate; do not
  silently skip a supported profiling mode. Each profiling mode is a single
  correctness dispatch with no performance warmups or rounds. Run clean evaluation and profiling
modes strictly sequentially; never launch two device commands concurrently.
Canonical \`__pycache__/\` and \`*.pyc\` files are permitted and must not be
reported as migration defects; inspect the actual Ref/Candidate source closure
for forbidden support code instead.

If this is stage repair-certify, the narrow exception in
04_repair_and_recertify.md and its Skill replaces the generic topology-preservation
sentence above only for the exact internal Ref change being proposed. It does
not relax any public or protected contract. If this is Stage 4, 5, or 6 and
03-repair-certify/approval.json exists, first run
\`python3 benchmarks/mig_workflow/repair_gate.py verify --root "$ROOT" --task-dir "$task_dir"\`.
The approved, hash-bound Ref deviation is then the input baseline; reject any
drift, but do not reject that exact approved deviation merely because strict
Stage 3 would not have allowed it.

Append this stage's decisions, files, commands, evidence, outcome and next owner
to $task_dir/handoff.md. Return a final JSON object matching the supplied schema.
Return only the JSON object, without a Markdown fence or explanatory text. Its
top-level keys must be exactly: case_id, stage, outcome, result_case_ids,
changed_files, checks, profiling, blockers, owner_stage, handoff, summary.
Use outcome, never result; use owner_stage, never next_owner. checks must contain
one evidence-backed row for every required stage check. Every checks item has
exactly the keys name, status, evidence; use name, never check. Every profiling
item has exactly the keys mode, status, evidence. For PASS, checks must contain
no FAIL or NOT_RUN item, blockers must be empty, and owner_stage must be none.
owner_stage must be exactly one of none, analyze, contract, implement-certify,
publish, or infrastructure. Never use a stage number, "Stage N", accept, or any
other alias; for example, a defect owned by Stage 3 uses implement-certify.
handoff and summary must be nonempty strings.
This invocation must collect fresh evidence in the current Stage artifact
directories. Prior handoff failures are historical context, not a current
verdict: do not return their outcome without rerunning every required command
that is now runnable. A rework invocation archives old workspaces/results, so
never inspect a before_rework timestamp directory as evidence for the new outcome.
Set case_id to $case_id and stage to $stage. Set result_case_ids to the exact
v0.2 Case IDs established by the handoff (or an empty array only if analysis is
blocked before they can be decided). changed_files must contain only paths this
stage was allowed to write. Read evaluator/profile_modes.py at execution time
and include exactly one profiling array item for every current PROFILE_MODES
key. Each item contains mode, status, and evidence. Use PASS, UNSUPPORTED, FAIL,
or NOT_RUN; Stages 1-3 normally use NOT_RUN. UNSUPPORTED requires a concise
evidence-backed reason and does not by itself fail the Case when both phase=all
clean evaluations pass. An unexpected profiling FAIL prevents stage PASS and
must name its owning stage or infrastructure. PASS means every required check
in this stage is complete; unavailable infrastructure that prevents a required
clean command is BLOCKED.
EOF
}


extract_thread_id() {
  sed -n '/"type"[[:space:]]*:[[:space:]]*"thread.started"/s/.*"thread_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$1" | head -1
}

rename_thread() {
  local thread_id="$1" name="$2" output="$3" errors="$4" profile="$5"
  {
    printf '%s\n' '{"id":1,"method":"initialize","params":{"clientInfo":{"name":"pypto-migration-batch","version":"1"}}}'
    sleep 0.5
    printf '%s\n' '{"method":"initialized"}'
    printf '{"id":2,"method":"thread/name/set","params":{"threadId":"%s","name":"%s"}}\n' "$thread_id" "$name"
    sleep 0.5
  } | env CODEX_HOME="$profile" "$CODEX_BIN" app-server --stdio \
      >"$output" 2>"$errors" || true
}

has_execution_tool_event() {
  grep -Eq '"type":"(command_execution|file_change)"' "$1"
}

has_tool_router_failure() {
  local errors="$1"
  grep -Eqi 'codex_core::tools::router|failed to parse function arguments|missing field.*cell_id' "$errors"
}

# Codex can finish the structured response in JSONL while its convenience
# --output-last-message file remains empty if the CLI hangs during shutdown.
# Recover only a complete agent_message payload; the normal schema validator
# still decides whether the recovered payload is a valid stage result.
recover_last_message_from_events() {
  local events="$1" raw="$2"
  [[ -s "$raw" ]] || [[ -s "$events" ]] || return 1
  [[ -s "$raw" ]] && return 0
  python3 - "$events" "$raw" <<'PY'
import json
import sys
from pathlib import Path

events = Path(sys.argv[1])
raw = Path(sys.argv[2])
candidate = None
for line in events.read_text(encoding="utf-8", errors="replace").splitlines():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        continue
    item = event.get("item")
    if not isinstance(item, dict) or item.get("type") != "agent_message":
        continue
    text = item.get("text")
    if not isinstance(text, str):
        continue
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        continue
    if isinstance(parsed, dict):
        candidate = parsed
if candidate is None:
    raise SystemExit(1)
raw.write_text(json.dumps(candidate, ensure_ascii=False) + "\n", encoding="utf-8")
PY
}

# Intermediate handoff messages are schema-shaped too. Recover only a
# terminal message whose profiling entries are all complete, so a CLI that
# hangs during IPC shutdown cannot block a finished Stage indefinitely.
recover_completed_result_from_events() {
  local events="$1" raw="$2"
  [[ -s "$events" ]] || return 1
  python3 - "$events" "$raw" <<'PY'
import json
import sys
from pathlib import Path

events = Path(sys.argv[1])
raw = Path(sys.argv[2])
candidate = None
for line in events.read_text(encoding="utf-8", errors="replace").splitlines():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        continue
    item = event.get("item")
    if not isinstance(item, dict) or item.get("type") != "agent_message":
        continue
    text = item.get("text")
    if not isinstance(text, str):
        continue
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        continue
    if not isinstance(parsed, dict):
        continue
    profiling = parsed.get("profiling")
    if not isinstance(profiling, list) or not profiling:
        continue
    statuses = [entry.get("status") for entry in profiling if isinstance(entry, dict)]
    if len(statuses) != len(profiling) or any(status == "NOT_RUN" for status in statuses):
        continue
    if any(status not in {"PASS", "FAIL", "BLOCKED", "INVALID"} for status in statuses):
        continue
    candidate = parsed
if candidate is None:
    raise SystemExit(1)
raw.write_text(json.dumps(candidate, ensure_ascii=False) + "\n", encoding="utf-8")
PY
}

terminate_process_group() {
  local pid="$1" step
  kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
  for step in {1..20}; do
    kill -0 "$pid" 2>/dev/null || return 0
    sleep 0.1
  done
  kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
}

is_api_failure() {
  local events="$1" errors="$2"
  local pattern='(^|[^0-9])(401|403|429|500|502|503|504)([^0-9]|$)|insufficient[ _-]?balance|quota|rate.?limit|API (error|request)|network|connection (reset|refused|closed)|timed? out|timeout|temporarily unavailable|service unavailable|server error|overloaded|stream.*(closed|disconnect)'
  grep -Eqi "$pattern" "$errors" && return 0
  grep -E '"type":"(error|turn.failed)"' "$events" | grep -Eqi "$pattern"
}

api_retry_backoff() {
  local retry_number="$1" delay
  ((API_RETRY_BACKOFF_BASE_SECONDS > 0)) || return 0
  delay=$((API_RETRY_BACKOFF_BASE_SECONDS * (retry_number + 1)))
  ((delay > API_RETRY_BACKOFF_MAX_SECONDS)) && delay="$API_RETRY_BACKOFF_MAX_SECONDS"
  echo "API retry backoff: ${delay}s (retry $((retry_number + 1)))" >&2
  sleep "$delay"
}

json_outcome() {
  sed -n 's/.*"outcome"[[:space:]]*:[[:space:]]*"\([A-Z]*\)".*/\1/p' "$1" | head -1
}

json_field() {
  local field="$1" file="$2"
  sed -n "s/.*\"$field\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" "$file" | head -1
}

stage_index() {
  case "$1" in
    1|analyze|01-analyze) echo 0 ;;
    2|contract|02-contract) echo 1 ;;
    3|implement-certify|03-implement-certify) echo 2 ;;
    4|publish|04-publish) echo 3 ;;
    5|closure-audit|05-closure-audit) echo 4 ;;
    6|accept|06-accept) echo 5 ;;
    *) return 1 ;;
  esac
}

rework_index() {
  local task_dir="$1" requested="$2" index result owner stage
  if [[ "$requested" != owner ]]; then
    stage_index "$requested"
    return
  fi
  for ((index=MAIN_STAGE_COUNT - 1; index >= 0; index--)); do
    result="$task_dir/${STAGE_DIRS[$index]}/result.json"
    [[ -f "$result" ]] || continue
    [[ "$(json_outcome "$result")" != PASS ]] || continue
    owner="$(json_field owner_stage "$result")"
    stage="$(json_field stage "$result")"
    if [[ "$owner" == infrastructure ]]; then
      stage_index "$stage"
    else
      stage_index "$owner"
    fi
    return
  done
  echo "cannot infer rework owner: no non-PASS stage result in $task_dir" >&2
  return 1
}

has_approved_repair() {
  local task_dir="$1"
  python3 "$REPAIR_GATE" verify --root "$ROOT" --task-dir "$task_dir" >/dev/null 2>&1
}

resume_index() {
  local task_dir="$1" index result outcome
  for ((index=0; index<MAIN_STAGE_COUNT; index++)); do
    result="$task_dir/${STAGE_DIRS[$index]}/result.json"
    if [[ ! -f "$result" ]]; then
      echo "$index"
      return
    fi
    outcome="$(json_outcome "$result")"
    if [[ "$outcome" != PASS ]]; then
      if ((index == 2)) && has_approved_repair "$task_dir"; then
        continue
      fi
      echo "cannot resume past non-PASS ${STAGE_KEYS[$index]} result; use --rework owner or --rework ${STAGE_KEYS[$index]}" >&2
      return 1
    fi
  done
  echo "$MAIN_STAGE_COUNT"
}

next_attempt() {
  local stage_dir="$1" path base number max=0
  shopt -s nullglob
  for path in "$stage_dir"/attempt_*.jsonl "$stage_dir"/attempt_*.bootstrap.jsonl; do
    base="${path##*/}"
    number="${base#attempt_}"
    number="${number%%.*}"
    [[ "$number" =~ ^[0-9]+$ ]] || continue
    ((number > max)) && max="$number"
  done
  shopt -u nullglob
  echo $((max + 1))
}

has_prior_attempt() {
  local stage_dir="$1"
  compgen -G "$stage_dir/attempt_*.jsonl" >/dev/null
}

stage_rework_count() {
  local stage_dir="$1" count_file="$1/.rework_count" path count=0
  if [[ -f "$count_file" ]]; then
    read -r count <"$count_file"
    [[ "$count" =~ ^[0-9]+$ ]] || {
      echo "invalid rework count: $count_file" >&2
      return 2
    }
    echo "$count"
    return
  fi

  # Bootstrap pre-counter history without treating API retries as rework.
  shopt -s nullglob
  for path in "$stage_dir"/repair_*.result.json \
              "$stage_dir"/result.before_rework_*.json; do
    ((count += 1))
  done
  shopt -u nullglob
  echo "$count"
}

check_stage_rework_limit() {
  local stage_dir="$1" count
  has_prior_attempt "$stage_dir" || return 0
  count="$(stage_rework_count "$stage_dir")" || return
  if ((count >= MAX_STAGE_REWORKS)); then
    echo "rework limit reached for $stage_dir: $count/$MAX_STAGE_REWORKS" >&2
    return 1
  fi
}

record_stage_rework() {
  local stage_dir="$1" reason="$2" count
  has_prior_attempt "$stage_dir" || return 0
  count="$(stage_rework_count "$stage_dir")" || return
  ((count += 1))
  printf '%s\n' "$count" >"$stage_dir/.rework_count"
  printf '%s\t%s\t%s\n' "$(date +%Y%m%dT%H%M%S)" "$count" "$reason" \
    >>"$stage_dir/reworks.tsv"
}

check_rework_limits() {
  local task_dir="$1" start="$2" index
  for ((index=start; index<MAIN_STAGE_COUNT; index++)); do
    check_stage_rework_limit "$task_dir/${STAGE_DIRS[$index]}" || return
  done
}

freeze_rework_counts() {
  local task_dir="$1" start="$2" index stage_dir count
  for ((index=start; index<MAIN_STAGE_COUNT; index++)); do
    stage_dir="$task_dir/${STAGE_DIRS[$index]}"
    has_prior_attempt "$stage_dir" || continue
    [[ -f "$stage_dir/.rework_count" ]] && continue
    count="$(stage_rework_count "$stage_dir")" || return
    printf '%s\n' "$count" >"$stage_dir/.rework_count"
  done
}

archive_rework_state() {
  local task_dir="$1" start="$2" stamp index result artifact_dir
  stamp="$(date +%Y%m%dT%H%M%S)"
  for ((index=start; index<MAIN_STAGE_COUNT; index++)); do
    result="$task_dir/${STAGE_DIRS[$index]}/result.json"
    [[ ! -f "$result" ]] || mv "$result" "${result%.json}.before_rework_$stamp.json"
    for artifact_dir in workspaces results acceptance_workspaces acceptance_results; do
      artifact_dir="$task_dir/${STAGE_DIRS[$index]}/$artifact_dir"
      [[ ! -e "$artifact_dir" ]] || \
        mv "$artifact_dir" "$artifact_dir.before_rework_$stamp"
    done
  done
  if ((start <= 4)); then
    for artifact_dir in acceptance_workspaces acceptance_results; do
      artifact_dir="$task_dir/$artifact_dir"
      [[ ! -e "$artifact_dir" ]] || \
        mv "$artifact_dir" "$artifact_dir.before_rework_$stamp"
    done
  fi
  if ((start <= 2)) && [[ -d "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}" ]]; then
    mv "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}" \
      "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}.before_rework_$stamp"
  fi
  [[ ! -f "$task_dir/result.json" ]] || \
    mv "$task_dir/result.json" "$task_dir/result.before_rework_$stamp.json"
  [[ ! -f "$task_dir/status" ]] || \
    mv "$task_dir/status" "$task_dir/status.before_rework_$stamp"
  printf 'REWORKING_FROM=%s\nSTARTED_AT=%s\n' \
    "${STAGE_KEYS[$start]}" "$stamp" >"$task_dir/status"
}

run_single_attempt() {
  local case_id="$1" task_dir="$2" safe="$3" index="$4" attempt="$5"
  local stage_dir="$task_dir/${STAGE_DIRS[$index]}"
  local events="$stage_dir/attempt_${attempt}.jsonl"
  local errors="$stage_dir/attempt_${attempt}.stderr.log"
  local raw="$stage_dir/attempt_${attempt}.last_message.txt"
  local final="$stage_dir/attempt_${attempt}.result.json"
  local validation="$stage_dir/attempt_${attempt}.validation.log"
  local profile_log="$stage_dir/attempt_${attempt}.profile.log"
  local guard_log="$stage_dir/attempt_${attempt}.session_guard.log"
  local session_name="migrate-$safe-${STAGE_DIRS[$index]}"
  local provider="${STAGE_PROVIDERS[$index]}"
  local profile="${STAGE_PROFILES[$index]}"
  local model="${STAGE_MODELS[$index]}"
  local reasoning="${STAGE_REASONING[$index]}"
  local resume_thread="${10:-}" input_prompt="${11:-$stage_dir/prompt.txt}"
  local execution_codex_provider="${12:-}"
  local codex_provider credential_source
  [[ -z "$6" ]] || model="$6"
  [[ -z "$7" ]] || reasoning="$7"
  [[ -z "${8:-}" ]] || provider="$8"
  [[ -z "${9:-}" ]] || profile="$9"
  [[ -z "$MODEL" ]] || model="$MODEL"
  ((attempt == 1)) || session_name+="-retry$attempt"

  : >"$events"
  : >"$errors"
  : >"$raw"
  : >"$guard_log"
  codex_provider="$(codex_provider_for_phase "$profile" execution)"
  if [[ -n "$execution_codex_provider" ]]; then
    codex_provider="$execution_codex_provider"
  fi
  credential_source=auth.json
  [[ "$codex_provider" != "$ASTRA_FALLBACK_CODEX_PROVIDER" ]] || \
    credential_source="profile:OPENAI_API_KEY"
  [[ "$MIMO_SOL_CODEX_PROVIDER" == custom || "$codex_provider" != "$MIMO_SOL_CODEX_PROVIDER" ]] || \
    credential_source="env:MIMO_SOL_API_KEY"
  printf 'provider=%s\nprofile=%s\nmodel=%s\nreasoning=%s\ncodex_provider=%s\ncredential_source=%s\n' \
    "$provider" "$profile" "$model" "$reasoning" "$codex_provider" \
    "$credential_source" >"$profile_log"

  local -a args workspace_network_args=()
  local -a execution_provider_config_args=()
  if [[ "$execution_codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" || \
        "$codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" ]]; then
    execution_provider_config_args=(
      --config 'model_providers.astra_shaobianer.name="astra-shaobianer"'
      --config 'model_providers.astra_shaobianer.wire_api="responses"'
      --config 'model_providers.astra_shaobianer.env_key="ASTRA_SHAOBIANER_API_KEY"'
      --config 'model_providers.astra_shaobianer.requires_openai_auth=false'
      --config 'model_providers.astra_shaobianer.base_url="https://shaobianer.com/v1"'
    )
  fi
  if [[ "${STAGE_SANDBOXES[$index]}" == workspace-write ]]; then
    workspace_network_args=(
      --config "sandbox_workspace_write.network_access=true"
    )
  fi
  if [[ -n "$resume_thread" ]]; then
    args=(exec resume --json --model "$model"
      --config "model_provider=\"$codex_provider\""
      --config "model_reasoning_effort=\"$reasoning\""
      --config "sandbox_mode=\"${STAGE_SANDBOXES[$index]}\""
      "${execution_provider_config_args[@]}"
      "${workspace_network_args[@]}"
      --output-schema "$SCHEMA" --output-last-message "$raw"
      "$resume_thread" -)
  else
    args=(exec -C "$ROOT" --sandbox "${STAGE_SANDBOXES[$index]}" --json
      --model "$model" --config "model_provider=\"$codex_provider\""
      --config "model_reasoning_effort=\"$reasoning\""
      "${execution_provider_config_args[@]}"
      "${workspace_network_args[@]}"
      --output-schema "$SCHEMA" --output-last-message "$raw")
  fi

  local sol_api_key="" aixuan_api_key=""
  if [[ "$codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" ]]; then
    aixuan_api_key="$(load_astra_api_key "$ASTRA_FALLBACK_PROFILE")" || return 78
    ASTRA_SHAOBIANER_API_KEY="$aixuan_api_key" setsid env CODEX_HOME="$profile" \
      GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy \
      GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" <"$input_prompt" \
      >"$events" 2>"$errors" &
  elif [[ "$MIMO_SOL_CODEX_PROVIDER" != custom && "$codex_provider" == "$MIMO_SOL_CODEX_PROVIDER" ]]; then
    sol_api_key="$(load_mimo_sol_api_key)" || return 78
    MIMO_SOL_API_KEY="$sol_api_key" setsid env CODEX_HOME="$profile" \
      GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy \
      GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" <"$input_prompt" \
      >"$events" 2>"$errors" &
  else
    setsid env CODEX_HOME="$profile" GIT_CONFIG_COUNT=1 \
      GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" \
      <"$input_prompt" >"$events" 2>"$errors" &
  fi
  local pid=$! thread_id="$resume_thread" thread_recorded=0 tool_seen=0 first_event_seen=0
  local structured_result_ready=0
  unset sol_api_key aixuan_api_key
  [[ -z "$resume_thread" ]] || thread_recorded=1
  local started_at=$SECONDS last_event_at=$SECONDS event_size=0 current_size=0
  # The inactivity guard is an external orchestration safeguard, not a model
  # prompt policy.  Stage 4 uses GLM as well as Sol; leaving GLM unguarded lets
  # a provider request wait indefinitely and blocks the serial queue.
  local guard_enabled=1 guard_reason=""
  while kill -0 "$pid" 2>/dev/null; do
    if ((thread_recorded == 0)); then
      thread_id="$(extract_thread_id "$events")"
    fi
    if [[ -n "$thread_id" ]] && ((thread_recorded == 0)); then
      if ((RENAME)); then
        rename_thread "$thread_id" "$session_name" \
          "$stage_dir/attempt_${attempt}.rename.jsonl" \
          "$stage_dir/attempt_${attempt}.rename.stderr.log" "$profile"
      fi
      printf '%s\t%s\n' "$thread_id" "$session_name" >>"$stage_dir/sessions.tsv"
      thread_recorded=1
    fi
    if has_tool_router_failure "$errors"; then
      guard_reason="Codex tool router rejected function arguments"
    elif ((guard_enabled)); then
      if ((tool_seen == 0)) && has_execution_tool_event "$events"; then
        tool_seen=1
        last_event_at=$SECONDS
      fi
      current_size="$(stat -c %s "$events" 2>/dev/null || echo 0)"
      if ((current_size > event_size)); then
        event_size=$current_size
        first_event_seen=1
        last_event_at=$SECONDS
      fi
      if ((tool_seen == 0 && first_event_seen == 0 && SECONDS - started_at >= CODEX_FIRST_EVENT_TIMEOUT_SECONDS)); then
        guard_reason="no JSONL event within ${CODEX_FIRST_EVENT_TIMEOUT_SECONDS}s"
      elif ((tool_seen == 0 && SECONDS - started_at >= CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS)); then
        guard_reason="no command_execution or file_change event within the ${CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS}s pre-tool hard limit"
      elif ((tool_seen == 0 && first_event_seen == 1 && SECONDS - last_event_at >= CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS)); then
        guard_reason="no JSONL progress for ${CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS}s before tool execution"
      elif ((tool_seen == 1 && SECONDS - last_event_at >= CODEX_INACTIVITY_TIMEOUT_SECONDS)); then
        guard_reason="no JSONL progress for ${CODEX_INACTIVITY_TIMEOUT_SECONDS}s after tool execution began"
      fi
      if [[ -n "$guard_reason" ]]; then
        printf '%s\n' "$guard_reason" >"$guard_log"
        terminate_process_group "$pid"
        break
      fi
    fi
    if ((structured_result_ready == 0)) &&
       recover_completed_result_from_events "$events" "$raw" &&
       python3 "$RESULT_VALIDATOR" --schema "$SCHEMA" \
         --input "$raw" --output "$final" --case "$case_id" --stage "$stage" \
         >/dev/null 2>&1; then
      structured_result_ready=1
      printf '%s\n' "completed structured result recovered from JSONL; ending CLI shutdown" >"$guard_log"
      terminate_process_group "$pid"
      break
    fi
    # `--output-last-message` can write a complete schema-valid result before
    # the CLI process finishes draining its provider/IPC shutdown. Once that
    # result is present, the remaining process lifetime is not useful work;
    # finish the externally supervised attempt instead of letting inactivity
    # guard recreate an already completed Stage.
    if [[ -s "$raw" ]] && python3 "$RESULT_VALIDATOR" --schema "$SCHEMA" \
        --input "$raw" --output "$final" --case "$case_id" --stage "$stage" \
        >/dev/null 2>&1; then
      structured_result_ready=1
      printf '%s\n' "valid structured result emitted; ending CLI shutdown" >"$guard_log"
      terminate_process_group "$pid"
      break
    fi
    # A stage agent may write the stage-level PASS record and then hang while
    # the CLI drains its IPC session. The orchestrator has already archived
    # any older result before a rework, so this current PASS is authoritative.
    if [[ -f "$stage_dir/result.json" ]] && \
       [[ "$(json_outcome "$stage_dir/result.json")" == PASS ]]; then
      cp "$stage_dir/result.json" "$final"
      structured_result_ready=1
      printf '%s\n' "current stage PASS already emitted; ending CLI shutdown" >"$guard_log"
      terminate_process_group "$pid"
      break
    fi
    sleep 0.2
  done

  local rc=0
  wait "$pid" || rc=$?
  ((structured_result_ready == 0)) || rc=0
  # Provider/CLI shutdown can append a tool-router rejection after the agent
  # has already emitted a complete Stage result. Always recover and validate
  # that result before classifying stderr or the process exit code. A valid
  # result remains subject to the normal schema and Stage outcome handling;
  # the recovered router rejection is retained as a non-fatal warning.
  if ((structured_result_ready == 0)); then
    recover_last_message_from_events "$events" "$raw" || true
    if [[ -s "$raw" ]] && python3 "$RESULT_VALIDATOR" --schema "$SCHEMA" \
        --input "$raw" --output "$final" --case "$case_id" --stage "$stage" \
        >"$validation" 2>&1; then
      structured_result_ready=1
      rc=0
      if has_tool_router_failure "$errors"; then
        printf '%s\n' \
          "RECOVERED_TOOL_REJECTION: valid structured result accepted after tool-router rejection" \
          >"$guard_log"
      else
        printf '%s\n' \
          "valid structured result recovered after process exit; accepting attempt" \
          >"$guard_log"
      fi
    fi
  fi
  if ((structured_result_ready)); then
    return 0
  fi
  # A rejected API request can exit before the first tool event. Classify the
  # actual provider error before the no-tools/session guards so quota and
  # transport failures reach API fallback instead of exhausting session retries.
  if is_api_failure "$events" "$errors"; then
    printf '%s\n' "API_FAILURE: provider request failed without a valid Stage result" >"$guard_log"
    return 1
  fi
  if [[ -n "$guard_reason" ]] && ((structured_result_ready == 0)); then
    # A completed agent message may still be present in the JSONL event stream
    # even when the CLI was terminated during its quiet shutdown. Recover and
    # validate it before charging this attempt as an orchestration retry.
    recover_last_message_from_events "$events" "$raw" || true
    if [[ -s "$raw" ]] && python3 "$RESULT_VALIDATOR" --schema "$SCHEMA" \
        --input "$raw" --output "$final" --case "$case_id" --stage "$stage" \
        >"$validation" 2>&1; then
      printf '%s\n' "valid structured result recovered after guard; accepting attempt" >"$guard_log"
      return 0
    fi
    return 75
  fi
  if has_tool_router_failure "$errors"; then
    printf '%s\n' "Codex tool router rejected function arguments" >"$guard_log"
    return 75
  fi
  if ((thread_recorded == 0)); then
    thread_id="$(extract_thread_id "$events")"
    [[ -z "$thread_id" ]] || printf '%s\t%s\n' "$thread_id" "$session_name" >>"$stage_dir/sessions.tsv"
  fi
  if ((guard_enabled)) && ! has_execution_tool_event "$events"; then
    printf '%s\n' "thread exited without any command_execution or file_change event" >"$guard_log"
    return 75
  fi
  if ((rc == 0)); then
    recover_last_message_from_events "$events" "$raw" || true
    if ! python3 "$RESULT_VALIDATOR" --schema "$SCHEMA" --input "$raw" \
        --output "$final" --case "$case_id" --stage "$stage" \
        >"$validation" 2>&1; then
      cat "$validation" >&2
      return 65
    fi
  fi
  return "$rc"
}

run_bootstrap_attempt() {
  local case_id="$1" task_dir="$2" safe="$3" index="$4" attempt="$5"
  local provider="${6:-${STAGE_PROVIDERS[$index]}}"
  local profile="${7:-${STAGE_PROFILES[$index]}}"
  local resume_thread="${8:-}"
  local bootstrap_codex_provider="${9:-$ASTRA_CODEX_PROVIDER}"
  local bootstrap_model="${10:-$BOOTSTRAP_MODEL}"
  local bootstrap_reasoning="${11:-$BOOTSTRAP_REASONING}"
  if [[ "$bootstrap_codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" ]]; then
    provider="$ASTRA_FALLBACK_PROVIDER"
  elif [[ "$bootstrap_codex_provider" == "$ASTRA_CODEX_PROVIDER" ]]; then
    provider="$ASTRA_PROVIDER"
  fi
  local stage_dir="$task_dir/${STAGE_DIRS[$index]}"
  local events="$stage_dir/attempt_${attempt}.bootstrap.jsonl"
  local errors="$stage_dir/attempt_${attempt}.bootstrap.stderr.log"
  local raw="$stage_dir/attempt_${attempt}.bootstrap.last_message.txt"
  local validation="$stage_dir/attempt_${attempt}.bootstrap.validation.log"
  local profile_log="$stage_dir/attempt_${attempt}.bootstrap.profile.log"
  local guard_log="$stage_dir/attempt_${attempt}.bootstrap.session_guard.log"
  local thread_file="$stage_dir/attempt_${attempt}.thread_id"
  local session_name="migrate-$safe-${STAGE_DIRS[$index]}" codex_provider credential_source
  ((attempt == 1)) || session_name+="-retry$attempt"

  : >"$events"
  : >"$errors"
  : >"$raw"
  : >"$validation"
  : >"$guard_log"
  codex_provider="$bootstrap_codex_provider"
  if [[ "$codex_provider" == "$ASTRA_CODEX_PROVIDER" ]]; then
    credential_source=profile:OPENAI_API_KEY
  elif [[ "$codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" ]]; then
    credential_source=profile:OPENAI_API_KEY
  else
    credential_source=auth.json
  fi
  [[ "$MIMO_SOL_CODEX_PROVIDER" == custom || "$codex_provider" != "$MIMO_SOL_CODEX_PROVIDER" ]] || \
    credential_source="env:MIMO_SOL_API_KEY"
  printf 'provider=%s\nprofile=%s\nmodel=%s\nreasoning=%s\nphase=bootstrap\ncodex_provider=%s\ncredential_source=%s\n' \
    "$provider" "$profile" "$bootstrap_model" "$bootstrap_reasoning" \
    "$codex_provider" "$credential_source" >"$profile_log"

  local input_prompt="$stage_dir/prompt.txt"
  local -a args provider_config_args=(
    --config 'model_providers.astra_shaobianer.name="astra-shaobianer"'
    --config 'model_providers.astra_shaobianer.wire_api="responses"'
    --config 'model_providers.astra_shaobianer.env_key="ASTRA_SHAOBIANER_API_KEY"'
    --config 'model_providers.astra_shaobianer.requires_openai_auth=false'
    --config 'model_providers.astra_shaobianer.base_url="https://shaobianer.com/v1"'
    --config 'model_providers.astra_aixuanhub.name="astra-aixuanhub"'
    --config 'model_providers.astra_aixuanhub.wire_api="responses"'
    --config 'model_providers.astra_aixuanhub.env_key="ASTRA_AIXUANHUB_API_KEY"'
    --config 'model_providers.astra_aixuanhub.requires_openai_auth=false'
    --config 'model_providers.astra_aixuanhub.base_url="https://api.aixuanhub.me/v1"'
    --config 'model_providers.mimo_astra.name="mimo-astra"'
    --config 'model_providers.mimo_astra.wire_api="responses"'
    --config 'model_providers.mimo_astra.requires_openai_auth=true'
    --config 'model_providers.mimo_astra.base_url="http://sub.reddoctor.work/v1"'
    --config 'model_providers.mimo_sol.name="mimo-sol"'
    --config 'model_providers.mimo_sol.wire_api="responses"'
    --config 'model_providers.mimo_sol.env_key="MIMO_SOL_API_KEY"'
    --config 'model_providers.mimo_sol.requires_openai_auth=false'
    --config 'model_providers.mimo_sol.base_url="http://sub.reddoctor.work/v1"'
  )
  if [[ -n "$resume_thread" ]]; then
    input_prompt="$stage_dir/api_resume_prompt.txt"
    args=(exec resume --json --model "$bootstrap_model"
      --config "model_provider=\"$codex_provider\""
      --config "model_reasoning_effort=\"$bootstrap_reasoning\""
      --config 'sandbox_mode="read-only"'
      "${provider_config_args[@]}"
      --output-last-message "$raw" "$resume_thread" -)
  else
    args=(exec -C "$ROOT" --sandbox read-only --json
      --model "$bootstrap_model"
      --config "model_provider=\"$codex_provider\""
      --config "model_reasoning_effort=\"$bootstrap_reasoning\""
      "${provider_config_args[@]}"
      --output-last-message "$raw")
  fi
  local sol_api_key="" astra_api_key=""
  if [[ "$codex_provider" == "$ASTRA_CODEX_PROVIDER" ]]; then
    astra_api_key="$(load_astra_api_key "$ASTRA_PROFILE")" || return 78
    OPENAI_API_KEY="$astra_api_key" setsid env CODEX_HOME="$profile" \
      GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy \
      GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" \
      <"$input_prompt" >"$events" 2>"$errors" &
  elif [[ "$codex_provider" == "$ASTRA_FALLBACK_CODEX_PROVIDER" ]]; then
    astra_api_key="$(load_astra_api_key "$ASTRA_FALLBACK_PROFILE")" || return 78
    ASTRA_SHAOBIANER_API_KEY="$astra_api_key" setsid env CODEX_HOME="$profile" \
      GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy \
      GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" \
      <"$input_prompt" >"$events" 2>"$errors" &
  elif [[ "$MIMO_SOL_CODEX_PROVIDER" != custom && "$codex_provider" == "$MIMO_SOL_CODEX_PROVIDER" ]]; then
    sol_api_key="$(load_mimo_sol_api_key)" || return 78
    MIMO_SOL_API_KEY="$sol_api_key" setsid env CODEX_HOME="$profile" \
      GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy \
      GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" \
      <"$input_prompt" >"$events" 2>"$errors" &
  else
    setsid env CODEX_HOME="$profile" GIT_CONFIG_COUNT=1 \
      GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0="$MIGRATION_GIT_PROXY" \
      "$CODEX_BIN" "${args[@]}" \
      <"$input_prompt" >"$events" 2>"$errors" &
  fi
  local pid=$! thread_id="$resume_thread" thread_recorded=0 tool_seen=0 first_event_seen=0
  unset sol_api_key astra_api_key
  [[ -z "$resume_thread" ]] || thread_recorded=1
  local started_at=$SECONDS last_event_at=$SECONDS event_size=0 current_size=0
  local guard_reason="" switched=0
  while kill -0 "$pid" 2>/dev/null; do
    if ((thread_recorded == 0)); then
      thread_id="$(extract_thread_id "$events")"
    fi
    if [[ -n "$thread_id" ]] && ((thread_recorded == 0)); then
      if ((RENAME)); then
        rename_thread "$thread_id" "$session_name" \
          "$stage_dir/attempt_${attempt}.rename.jsonl" \
          "$stage_dir/attempt_${attempt}.rename.stderr.log" "$profile"
      fi
      printf '%s\t%s\n' "$thread_id" "$session_name" >>"$stage_dir/sessions.tsv"
      thread_recorded=1
    fi
    if has_tool_router_failure "$errors"; then
      guard_reason="Codex tool router rejected function arguments during bootstrap"
    elif ((tool_seen == 0)) && has_execution_tool_event "$events"; then
      tool_seen=1
      last_event_at=$SECONDS
    fi
    current_size="$(stat -c %s "$events" 2>/dev/null || echo 0)"
    if ((current_size > event_size)); then
      event_size=$current_size
      first_event_seen=1
      last_event_at=$SECONDS
    fi
    if ((tool_seen == 0 && first_event_seen == 0 && SECONDS - started_at >= CODEX_FIRST_EVENT_TIMEOUT_SECONDS)); then
      guard_reason="no JSONL event within ${CODEX_FIRST_EVENT_TIMEOUT_SECONDS}s during bootstrap"
    elif ((tool_seen == 0 && SECONDS - started_at >= CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS)); then
      guard_reason="no command_execution event within the ${CODEX_PRE_TOOL_HARD_TIMEOUT_SECONDS}s bootstrap hard limit"
    elif ((tool_seen == 0 && first_event_seen == 1 && SECONDS - last_event_at >= CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS)); then
      guard_reason="no JSONL progress for ${CODEX_PRE_TOOL_INACTIVITY_TIMEOUT_SECONDS}s before bootstrap tool execution"
    elif ((tool_seen == 1 && SECONDS - last_event_at >= CODEX_INACTIVITY_TIMEOUT_SECONDS)); then
      guard_reason="no JSONL progress for ${CODEX_INACTIVITY_TIMEOUT_SECONDS}s after bootstrap tool execution began"
    fi
    if [[ -n "$guard_reason" ]]; then
      printf '%s\n' "$guard_reason" >"$guard_log"
      terminate_process_group "$pid"
      break
    fi
    if [[ -n "$thread_id" ]] && python3 "$BOOTSTRAP_VALIDATOR" \
        --events "$events" --thread-id "$thread_id" >"$validation" 2>&1; then
      printf "External handoff: two completed tools, no active tool; thread=%s\n" "$thread_id" >"$stage_dir/attempt_${attempt}.handoff.log"
      kill -INT -- "-$pid" 2>/dev/null || true
      for step in {1..30}; do
        kill -0 "$pid" 2>/dev/null || break
        sleep 0.1
      done
      kill -0 "$pid" 2>/dev/null && terminate_process_group "$pid"
      switched=1
      break
    fi
    sleep 0.2
  done

  local rc=0
  wait "$pid" || rc=$?
  if [[ -n "$guard_reason" ]]; then
    return 75
  fi
  if has_tool_router_failure "$errors"; then
    printf '%s\n' "Codex tool router rejected function arguments during bootstrap" >"$guard_log"
    return 75
  fi
  if ((thread_recorded == 0)); then
    thread_id="$(extract_thread_id "$events")"
    if [[ -n "$thread_id" ]]; then
      printf '%s\t%s\n' "$thread_id" "$session_name" >>"$stage_dir/sessions.tsv"
    fi
  fi
  if ((rc != 0 && switched == 0)); then
    return "$rc"
  fi
  if ! python3 "$BOOTSTRAP_VALIDATOR" --events "$events" --message "$raw" \
      --thread-id "$thread_id" \
      >"$validation" 2>&1; then
    cat "$validation" >&2
    printf '%s\n' "Astra bootstrap validation failed" >"$guard_log"
    return 75
  fi
  if [[ -z "$thread_id" ]]; then
    thread_id="$(extract_thread_id "$events")"
  fi
  printf '%s\n' "$thread_id" >"$thread_file"
}

copy_bootstrap_failure_artifacts() {
  local stage_dir="$1" attempt="$2" suffix
  for suffix in jsonl stderr.log last_message.txt profile.log session_guard.log; do
    cp "$stage_dir/attempt_${attempt}.bootstrap.$suffix" \
      "$stage_dir/attempt_${attempt}.$suffix"
  done
  : >"$stage_dir/attempt_${attempt}.validation.log"
}

run_attempt() {
  local case_id="$1" task_dir="$2" safe="$3" index="$4" attempt="$5"
  local active_model="$6" active_reasoning="$7"
  local active_provider="${8:-${STAGE_PROVIDERS[$index]}}"
  local active_profile="${9:-${STAGE_PROFILES[$index]}}"
  local api_resume_thread="${10:-}" api_resume_phase="${11:-}"
  local bootstrap_codex_provider="${12:-$ASTRA_CODEX_PROVIDER}"
  local execution_codex_provider="${13:-}"
  local stage_dir="$task_dir/${STAGE_DIRS[$index]}" rc thread_id

  # Stage 4 intentionally retains its established single GLM turn.
  if ((index == 3)); then
    run_single_attempt "$case_id" "$task_dir" "$safe" "$index" "$attempt" \
      "$active_model" "$active_reasoning" "$active_provider" "$active_profile" \
      "$api_resume_thread" \
      "${api_resume_thread:+$stage_dir/api_resume_prompt.txt}" \
      "$execution_codex_provider"
    return
  fi

  if [[ -n "$api_resume_thread" && "$api_resume_phase" == execution ]]; then
    run_single_attempt "$case_id" "$task_dir" "$safe" "$index" "$attempt" \
      "$active_model" "$active_reasoning" "$active_provider" "$active_profile" \
      "$api_resume_thread" "$stage_dir/api_resume_prompt.txt" "$execution_codex_provider"
    return
  fi

  local bootstrap_profile="$active_profile"
  local bootstrap_provider="$bootstrap_codex_provider"
  local bootstrap_model="${active_model:-${STAGE_MODELS[$index]}}"
  local bootstrap_reasoning="${active_reasoning:-${STAGE_REASONING[$index]}}"
  # Sol stages must bootstrap on their configured Sol profile.  Astra is only
  # selected after an API failure switches the active profile to fallback.
  if [[ "$active_profile" == "$PACKY_PROFILE" ]]; then
    bootstrap_provider="$(codex_provider_for_phase "$active_profile" bootstrap)"
  fi
  run_bootstrap_attempt "$case_id" "$task_dir" "$safe" "$index" \
    "$attempt" "$active_provider" "$active_profile" \
      "${api_resume_phase:+$api_resume_thread}" "$bootstrap_provider" \
      "$bootstrap_model" "$bootstrap_reasoning" || {
    rc=$?
    copy_bootstrap_failure_artifacts "$stage_dir" "$attempt"
    return "$rc"
  }
  read -r thread_id <"$stage_dir/attempt_${attempt}.thread_id"
  run_single_attempt "$case_id" "$task_dir" "$safe" "$index" "$attempt" \
      "$active_model" "$active_reasoning" "$active_provider" "$active_profile" \
      "$thread_id" \
      "$stage_dir/prompt.txt" "$execution_codex_provider"
}

run_stage() {
  local case_id="$1" task_dir="$2" safe="$3" index="$4" rework_reason="${5:-}"
  local stage="${STAGE_KEYS[$index]}" stage_label
  local stage_dir="$task_dir/${STAGE_DIRS[$index]}"

  if ((FORCE == 0)) && [[ -f "$stage_dir/result.json" ]] && \
      [[ "$(json_outcome "$stage_dir/result.json")" == PASS ]]; then
    echo "SKIP passed stage $stage for $case_id"
    return 0
  fi

  local attempt rc tool_retries=0 api_retries=0 api_same_profile_retry=0 output_retries=0 fallback_retries=0
  local api_thread_resumes=0 api_resume_thread="" api_resume_phase="" candidate_thread=""
  local bootstrap_codex_provider="$ASTRA_CODEX_PROVIDER" astra_fallback_used=0
  local execution_codex_provider=""
  local stage5_secondary_used=0
  local api_same_profile_limit=1
  [[ "${STAGE_PROFILES[$index]}" == "$MIMO_PROFILE" ]] && api_same_profile_limit=2
  local fallback_model="${STAGE_MODELS[$index]}" fallback_reasoning="${STAGE_REASONING[$index]}"
  local active_model="" active_reasoning="" active_provider="" active_profile=""
  if [[ -n "$rework_reason" ]]; then
    record_stage_rework "$stage_dir" "$rework_reason" || {
      echo REWORK_LIMIT >"$task_dir/status"
      return 1
    }
  fi
  attempt="$(next_attempt "$stage_dir")"
  cat >"$stage_dir/api_resume_prompt.txt" <<'EOF'
Continue the interrupted stage from the existing session state. Do not repeat
completed work. Inspect existing artifacts before any write or rerun. Complete
the original requested stage and emit its required structured result.
EOF
  while :; do
    # A thread is local to its Codex profile/provider. Never resume it after a
    # fallback changes the execution profile; start a fresh thread instead.
    if [[ -n "$api_resume_thread" && -f "$stage_dir/api_resume_profile" ]] && \
       [[ "$(<"$stage_dir/api_resume_profile")" != "${active_profile:-${STAGE_PROFILES[$index]}}" ]]; then
      api_resume_thread=""
      api_resume_phase=""
      api_thread_resumes=0
    fi
    display_model="${active_model:-${MODEL:-${STAGE_MODELS[$index]}}}"
    display_reasoning="${active_reasoning:-${STAGE_REASONING[$index]}}"
    display_provider="${active_provider:-${STAGE_PROVIDERS[$index]}}"
    display_profile="${active_profile:-${STAGE_PROFILES[$index]}}"
    if ((index == REPAIR_INDEX)); then
      stage_label="REPAIR"
    else
      stage_label="STAGE $((index + 1))/$MAIN_STAGE_COUNT"
    fi
    echo "$stage_label $stage: $case_id (attempt $attempt, provider $display_provider, profile $display_profile, model $display_model, reasoning $display_reasoning, sandbox ${STAGE_SANDBOXES[$index]})"
    if run_attempt "$case_id" "$task_dir" "$safe" "$index" "$attempt" "$active_model" "$active_reasoning" "$active_provider" "$active_profile" "$api_resume_thread" "$api_resume_phase" "$bootstrap_codex_provider" "$execution_codex_provider"; then
      cp "$stage_dir/attempt_${attempt}.result.json" "$stage_dir/result.json"
      break
    else
      rc=$?
    fi
    if ((rc == 78)); then
      echo CREDENTIAL_MISSING >"$task_dir/status"
      echo "Credential configuration failed at $stage for $case_id; no API, tool/session, output, or content retry was consumed" >&2
      return 1
    fi
    if ((index == 3)) && \
       [[ "${active_profile:-${STAGE_PROFILES[$index]}}" == "$GLM_PROFILE" ]]; then
      active_profile="$ASTRA_FALLBACK_PROFILE"
      active_provider="$ASTRA_FALLBACK_PROVIDER"
      active_model="gpt-6.1-sol"
      active_reasoning="high"
      execution_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      bootstrap_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      api_retries=0
      api_same_profile_retry=0
      api_thread_resumes=0
      api_resume_thread=""
      api_resume_phase=""
      echo "GLM execution failed at $stage for $case_id (exit $rc); switching to Shaobianer gpt-6.1-sol/high on a fresh thread" \
        | tee -a "$stage_dir/glm_provider_fallback.log"
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if is_api_failure "$stage_dir/attempt_${attempt}.jsonl" "$stage_dir/attempt_${attempt}.stderr.log" && \
       [[ "$execution_codex_provider" != "$ASTRA_FALLBACK_CODEX_PROVIDER" ]] && \
       [[ "${active_profile:-${STAGE_PROFILES[$index]}}" == "$PACKY_PROFILE" ]]; then
      execution_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      bootstrap_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      active_profile="$ASTRA_FALLBACK_PROFILE"
      active_provider="$ASTRA_FALLBACK_PROVIDER"
      api_retries=0
      api_same_profile_retry=0
      api_thread_resumes=0
      api_resume_thread=""
      api_resume_phase=""
      echo "Sol API failure at $stage for $case_id; switching Packy to Shaobianer and resetting Sol API retry budget to 0/$MAX_API_RETRIES" \
        | tee -a "$stage_dir/sol_provider_fallback.log"
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if ((rc == 75)); then
      api_resume_thread=""
      api_resume_phase=""
      api_thread_resumes=0
      if ((tool_retries >= MAX_CODEX_SESSION_RETRIES)); then
        if [[ "$fallback_model" == gpt-5.6-sol || "$fallback_model" == gpt-6.1-sol ]] && \
           ((fallback_retries < MAX_CODEX_MODEL_FALLBACK_RETRIES)); then
          ((fallback_retries += 1))
          active_model="gpt-5.5"
          active_reasoning="xhigh"
          echo "Codex session guard exhausted at $stage for $case_id after $tool_retries retries; switching to gpt-5.5/xhigh (fallback retry $fallback_retries/$MAX_CODEX_MODEL_FALLBACK_RETRIES)" \
            | tee -a "$stage_dir/session_retries.log"
          attempt="$(next_attempt "$stage_dir")"
          continue
        fi
        echo "Codex session guard exhausted at $stage for $case_id after $tool_retries retries" \
          | tee -a "$stage_dir/session_retries.log"
        echo CODEX_SESSION_FAILED >"$task_dir/status"
        return 1
      fi
      ((tool_retries += 1))
      echo "Codex session guard at $stage for $case_id; recreating the thread with profile ${active_profile:-${STAGE_PROFILES[$index]}} (retry $tool_retries/$MAX_CODEX_SESSION_RETRIES)" \
        | tee -a "$stage_dir/session_retries.log"
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if is_api_failure "$stage_dir/attempt_${attempt}.jsonl" "$stage_dir/attempt_${attempt}.stderr.log"; then
      candidate_thread="$(extract_thread_id "$stage_dir/attempt_${attempt}.jsonl")"
      if [[ -z "$candidate_thread" && -s "$stage_dir/attempt_${attempt}.thread_id" ]]; then
        read -r candidate_thread <"$stage_dir/attempt_${attempt}.thread_id"
      fi
      if [[ -z "$candidate_thread" && -n "$api_resume_thread" ]]; then
        candidate_thread="$api_resume_thread"
      fi
      if [[ -n "$candidate_thread" ]] && \
         { has_execution_tool_event "$stage_dir/attempt_${attempt}.jsonl" || [[ -n "$api_resume_thread" ]]; } && \
         ((api_thread_resumes < MAX_API_THREAD_RESUMES)); then
        ((api_thread_resumes += 1))
        api_resume_thread="$candidate_thread"
        printf '%s\n' "${active_profile:-${STAGE_PROFILES[$index]}}" >"$stage_dir/api_resume_profile"
        if grep -q '^phase=bootstrap$' "$stage_dir/attempt_${attempt}.profile.log" 2>/dev/null; then
          api_resume_phase=bootstrap
        else
          api_resume_phase=execution
        fi
        echo "API failure at $stage for $case_id after successful tool execution; resuming thread $api_resume_thread on the current profile (same-thread resume $api_thread_resumes/$MAX_API_THREAD_RESUMES; independent of profile/API, tool/session, output, and rework retries)" \
          | tee -a "$stage_dir/api_thread_resume.log"
        attempt="$(next_attempt "$stage_dir")"
        continue
      fi
      api_resume_thread=""
      api_resume_phase=""
      api_thread_resumes=0
    fi
    if is_api_failure "$stage_dir/attempt_${attempt}.jsonl" "$stage_dir/attempt_${attempt}.stderr.log" && \
       grep -q '^phase=bootstrap$' "$stage_dir/attempt_${attempt}.profile.log" 2>/dev/null && \
       [[ "$bootstrap_codex_provider" == "$ASTRA_CODEX_PROVIDER" ]]; then
      bootstrap_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      execution_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
      active_profile="$ASTRA_FALLBACK_PROFILE"
      active_provider="$ASTRA_FALLBACK_PROVIDER"
      astra_fallback_used=1
      api_retries=0
      api_same_profile_retry=0
      api_resume_thread=""
      api_resume_phase=""
      api_thread_resumes=0
      echo "Astra API failure at $stage for $case_id; switching from shaobianer to MIMO Astra and resetting the Astra API retry budget to 0/$MAX_API_RETRIES" \
        | tee -a "$stage_dir/astra_provider_fallback.log"
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if is_api_failure "$stage_dir/attempt_${attempt}.jsonl" "$stage_dir/attempt_${attempt}.stderr.log" && \
       ((api_retries < MAX_API_RETRIES)); then
      api_retry_backoff "$api_retries"
      ((api_retries += 1))
      if ((astra_fallback_used == 1)) && \
         grep -q '^phase=bootstrap$' "$stage_dir/attempt_${attempt}.profile.log" 2>/dev/null; then
        echo "Astra API failure at $stage for $case_id; retrying MIMO Astra with its fresh API budget (API retry $api_retries/$MAX_API_RETRIES; independent of shaobianer, tool/session, output, and rework retries)" \
          | tee -a "$stage_dir/api_retry.log"
      elif ((api_same_profile_retry < api_same_profile_limit)); then
        ((api_same_profile_retry += 1))
        echo "API failure at $stage for $case_id; retrying on the current profile (same-profile retry $api_same_profile_retry/$api_same_profile_limit; API retry $api_retries/$MAX_API_RETRIES; independent of tool/session retries)" \
          | tee -a "$stage_dir/api_retry.log"
      elif ((index == 4 && stage5_secondary_used == 0)) && \
           [[ "${active_profile:-${STAGE_PROFILES[$index]}}" == "$MIMO_PROFILE" ]]; then
        stage5_secondary_used=1
        active_provider="$STAGE5_SECONDARY_PROVIDER"
        active_profile="$STAGE5_SECONDARY_PROFILE"
        active_model="gpt-6.1-sol"
        active_reasoning="high"
        api_resume_thread=""
        api_resume_phase=""
        api_same_profile_retry=0
        api_same_profile_limit=1
        echo "API failure at $stage for $case_id; switching from MIMO to Stage 5 secondary shaobianer profile (API retry $api_retries/$MAX_API_RETRIES; independent of tool/session retries)" \
          | tee -a "$stage_dir/api_secondary.log"
      else
        active_provider="$API_FALLBACK_PROVIDER"
        active_profile="$API_FALLBACK_PROFILE"
        bootstrap_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
        execution_codex_provider="$ASTRA_FALLBACK_CODEX_PROVIDER"
        api_resume_thread=""
        api_resume_phase=""
        if ((index == 3)) || [[ "${STAGE_MODELS[$index]}" == gpt-6.1-sol ]]; then
          active_model="gpt-6.1-sol"
          active_reasoning="high"
        fi
        echo "API failure at $stage for $case_id; switching to API fallback provider $API_FALLBACK_PROVIDER (API retry $api_retries/$MAX_API_RETRIES; independent of tool/session retries)" \
          | tee -a "$stage_dir/api_fallback.log"
      fi
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if [[ -s "$stage_dir/attempt_${attempt}.validation.log" ]] && \
       ((output_retries < MAX_OUTPUT_RETRIES)); then
      ((output_retries += 1))
      echo "Invalid stage result at $stage for $case_id; retrying the same stage (output retry $output_retries/$MAX_OUTPUT_RETRIES; independent of API/tool/session/rework retries)" \
        | tee -a "$stage_dir/output_retries.log"
      attempt="$(next_attempt "$stage_dir")"
      continue
    fi
    if [[ -s "$stage_dir/attempt_${attempt}.validation.log" ]]; then
      echo OUTPUT_INVALID >"$task_dir/status"
    elif is_api_failure "$stage_dir/attempt_${attempt}.jsonl" "$stage_dir/attempt_${attempt}.stderr.log"; then
      echo API_FAILED >"$task_dir/status"
    else
      echo EXEC_FAILED >"$task_dir/status"
    fi
    return 1
  done

  local outcome owner
  outcome="$(json_outcome "$stage_dir/result.json")"
  owner="$(json_field owner_stage "$stage_dir/result.json")"
  case "$outcome" in
    PASS) return 0 ;;
    BLOCKED) echo BLOCKED >"$task_dir/status" ;;
    FAIL)
      if [[ "$owner" == infrastructure ]]; then
        echo BLOCKED >"$task_dir/status"
      else
        echo INVALID >"$task_dir/status"
      fi
      ;;
    *) echo UNKNOWN >"$task_dir/status" ;;
  esac
  return 1
}

run_main_stages() {
  local case_id="$1" task_dir="$2" safe="$3" start="$4" rework_reason="${5:-}"
  local index auto_rework=0 outcome owner
  while :; do
    echo "RUN $case_id from ${STAGE_KEYS[$start]}"
    for ((index=start; index<MAIN_STAGE_COUNT; index++)); do
      if ((index == 0)); then
        refresh_upstream_main
      fi
      if run_stage "$case_id" "$task_dir" "$safe" "$index" "$rework_reason"; then
        rework_reason=""
        continue
      fi

      outcome="$(json_outcome "$task_dir/${STAGE_DIRS[$index]}/result.json")"
      owner="$(json_field owner_stage "$task_dir/${STAGE_DIRS[$index]}/result.json")"
      if ((index >= 3)) && [[ "$outcome" == FAIL ]] &&
         [[ "$owner" =~ ^(analyze|contract|implement-certify|publish)$ ]]; then
        start="$(stage_index "$owner")"
        if ((auto_rework >= MAX_STAGE_REWORKS)); then
          echo REWORK_LIMIT >"$task_dir/status"
          echo "STOP ${STAGE_KEYS[$index]} $case_id (automatic owner-directed rework limit reached)"
          return 1
        fi
        if ! check_rework_limits "$task_dir" "$start"; then
          echo REWORK_LIMIT >"$task_dir/status"
          echo "STOP $owner $case_id (rework limit reached)"
          return 1
        fi
        auto_rework=$((auto_rework + 1))
        rework_reason="${STAGE_KEYS[$index]} owner_stage=$owner"
        freeze_rework_counts "$task_dir" "$start" || return 1
        archive_rework_state "$task_dir" "$start"
        echo "REWORK ${STAGE_KEYS[$index]} $case_id from $owner (owner_stage selected; cycle $auto_rework/$MAX_STAGE_REWORKS)"
        break
      fi
      echo "STOP ${STAGE_KEYS[$index]} $case_id ($(cat "$task_dir/status"))"
      return 1
    done
    # The inner loop reaches here only after an automatic owner-directed rework.
    ((index == MAIN_STAGE_COUNT)) || continue
    break
  done

  cp "$task_dir/06-accept/result.json" "$task_dir/result.json"
  echo READY >"$task_dir/status"
  echo "READY $case_id"
}

archive_repair_attempt() {
  local task_dir="$1" stamp path
  stamp="$(date +%Y%m%dT%H%M%S)"
  for path in result.json proposal.json repair.patch approval.json; do
    [[ ! -f "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}/$path" ]] || \
      mv "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}/$path" \
        "$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}/${path}.before_rework_$stamp"
  done
  [[ ! -f "$task_dir/status" ]] || \
    mv "$task_dir/status" "$task_dir/status.before_repair_$stamp"
}

run_repair_case() {
  local case_id="$1" task_dir="$2" safe="$3"
  local stage_dir="$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}" reason=""
  write_prompt "$case_id" "$task_dir" "$safe" "$REPAIR_INDEX"
  if ((DRY_RUN)); then
    echo "DRY-RUN REPAIR $case_id -> $stage_dir (provider ${STAGE_PROVIDERS[$REPAIR_INDEX]}, profile ${STAGE_PROFILES[$REPAIR_INDEX]}, model ${MODEL:-${STAGE_MODELS[$REPAIR_INDEX]}}, reasoning ${STAGE_REASONING[$REPAIR_INDEX]})"
    return 0
  fi

  python3 "$REPAIR_GATE" snapshot --root "$ROOT" --task-dir "$task_dir" || {
    echo REPAIR_INELIGIBLE >"$task_dir/status"
    return 1
  }
  if [[ -f "$stage_dir/approval.json" ]]; then
    echo "Repair is already approved for $case_id; use --resume for interrupted downstream work" >&2
    return 1
  fi
  if [[ -f "$stage_dir/result.json" ]] && \
      [[ "$(json_outcome "$stage_dir/result.json")" == PASS ]] && \
      [[ -f "$stage_dir/proposal.json" ]]; then
    echo AWAITING_REPAIR_APPROVAL >"$task_dir/status"
    echo "AWAITING_REPAIR_APPROVAL $case_id"
    return 0
  fi
  if has_prior_attempt "$stage_dir"; then
    check_stage_rework_limit "$stage_dir" || {
      echo REWORK_LIMIT >"$task_dir/status"
      return 1
    }
    reason="--repair retry"
    archive_repair_attempt "$task_dir"
  fi
  if ! run_stage "$case_id" "$task_dir" "$safe" "$REPAIR_INDEX" "$reason"; then
    echo "STOP repair-certify $case_id ($(cat "$task_dir/status"))"
    return 1
  fi
  if ! python3 "$REPAIR_GATE" proposal --root "$ROOT" --task-dir "$task_dir"; then
    echo REPAIR_PROPOSAL_INVALID >"$task_dir/status"
    return 1
  fi
  echo AWAITING_REPAIR_APPROVAL >"$task_dir/status"
  echo "AWAITING_REPAIR_APPROVAL $case_id"
}

approve_repair_case() {
  local case_id="$1" task_dir="$2" safe="$3" index
  local approval="$task_dir/${STAGE_DIRS[$REPAIR_INDEX]}/approval.json"
  if ((DRY_RUN)); then
    echo "DRY-RUN APPROVE-REPAIR $case_id -> verify approval, then continue from publish"
    for ((index=3; index<MAIN_STAGE_COUNT; index++)); do
      echo "  ${STAGE_DIRS[$index]}: migrate-$safe-${STAGE_DIRS[$index]} (provider ${STAGE_PROVIDERS[$index]}, model ${MODEL:-${STAGE_MODELS[$index]}}, reasoning ${STAGE_REASONING[$index]})"
    done
    return 0
  fi
  # A prior manual approval is already the requested authorization.  Reuse it
  # after hash verification; repair_gate intentionally rejects approving the
  # same proposal twice.
  if [[ -f "$approval" ]]; then
    python3 "$REPAIR_GATE" verify --root "$ROOT" --task-dir "$task_dir" || return 1
  else
    python3 "$REPAIR_GATE" approve --root "$ROOT" --task-dir "$task_dir" || return 1
  fi
  python3 "$REPAIR_GATE" verify --root "$ROOT" --task-dir "$task_dir" >/dev/null || return 1
  archive_rework_state "$task_dir" 3
  run_main_stages "$case_id" "$task_dir" "$safe" 3 ""
}

run_case() {
  local case_id="$1" safe task_dir index start=0 rework_reason=""
  safe="${case_id/./__}"
  task_dir="$RUN_ROOT/$safe"
  mkdir -p "$task_dir"
  if [[ ! -f "$task_dir/handoff.md" ]]; then
    printf '# Migration handoff: %s\n\n' "$case_id" >"$task_dir/handoff.md"
  fi

  if ((REPAIR)); then
    run_repair_case "$case_id" "$task_dir" "$safe"
    return
  fi
  for ((index=0; index<MAIN_STAGE_COUNT; index++)); do
    write_prompt "$case_id" "$task_dir" "$safe" "$index"
  done
  if ((APPROVE_REPAIR)); then
    approve_repair_case "$case_id" "$task_dir" "$safe"
    return
  fi

  if ((DRY_RUN)); then
    if [[ -n "$REWORK" ]]; then
      start="$(rework_index "$task_dir" "$REWORK")" || return 1
      check_rework_limits "$task_dir" "$start" || return 1
    elif ((RESUME)); then
      start="$(resume_index "$task_dir")" || return 1
    fi
    if ((start == MAIN_STAGE_COUNT)); then
      echo "DRY-RUN $case_id -> already complete"
      return 0
    fi
    echo "DRY-RUN $case_id -> $task_dir (from ${STAGE_KEYS[$start]})"
    for ((index=start; index<MAIN_STAGE_COUNT; index++)); do
      echo "  ${STAGE_DIRS[$index]}: migrate-$safe-${STAGE_DIRS[$index]} (provider ${STAGE_PROVIDERS[$index]}, model ${MODEL:-${STAGE_MODELS[$index]}}, reasoning ${STAGE_REASONING[$index]})"
    done
    return 0
  fi

  if [[ -n "$REWORK" ]]; then
    start="$(rework_index "$task_dir" "$REWORK")" || return 1
    if ! check_rework_limits "$task_dir" "$start"; then
      echo REWORK_LIMIT >"$task_dir/status"
      return 1
    fi
    rework_reason="--rework $REWORK"
    freeze_rework_counts "$task_dir" "$start" || return 1
    archive_rework_state "$task_dir" "$start"
  elif ((RESUME)); then
    start="$(resume_index "$task_dir")" || return 1
    if ((start == MAIN_STAGE_COUNT)); then
      echo "READY $case_id (already complete)"
      return 0
    fi
  elif ((FORCE)); then
    if ! check_rework_limits "$task_dir" 0; then
      echo REWORK_LIMIT >"$task_dir/status"
      return 1
    fi
    rework_reason="--force"
    freeze_rework_counts "$task_dir" 0 || return 1
    archive_rework_state "$task_dir" 0
  fi
  run_main_stages "$case_id" "$task_dir" "$safe" "$start" "$rework_reason"
}

echo "Selected ${#CASES[@]} Case(s); one Case at a time; six sequential stages"
failed=0
batch=0
for case_id in "${CASES[@]}"; do
  ((batch += 1))
  echo "CASE $batch/${#CASES[@]}: $case_id"
  run_case "$case_id" || failed=1
done
exit "$failed"
