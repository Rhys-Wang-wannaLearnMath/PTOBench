# Stage 6: final independent acceptance

Skill: `verify-pypto-case-v02-migration`

This is the final unified check after Stages 1-5. An Agent that did not analyze,
implement, certify, publish, or closure-audit the Case independently rechecks the complete
migration and decides whether it is `READY`. Earlier `PASS` results and handoff
claims are context, not acceptance evidence.

For multi-file Cases, independently repeat `MULTI_FILE_MIGRATION.md`, including
the per-file ledger, normalized manifest, CWD/import-root/resource checks,
sibling load order, and global Case-ID ownership. Prior Stage tables are input,
not proof.

The verifier performs four complementary checks for every result Case:

1. recheck source selection, preset coverage, ABI, public contract, preserved
   official source/provenance, Fixture semantics, Oracle, evaluator,
   certification, environment, and current RunConfig compatibility;
2. inventory and classify every canonical file, trace the actual transitive
   Ref/Candidate call closure, and reject hidden dependencies, generated debris,
   or validation/support code carried into the editable implementation;
3. compare normalized Ref and Candidate manifests and file contents, accounting
   for every path and every allowed entry-module difference;
4. initialize a fresh workspace from canonical Candidate Seed, run initial
   clean evaluation, every current `PROFILE_MODES` mode, and final clean
   evaluation, then inspect JSON fields and isolated artifacts.

Comparator acceptance follows `COMPARATOR_POLICY.md` explicitly: independently
verify the recorded current-upstream commit/path and semantic diff, every
`ADOPT`/`KEEP_SELECTED` dependency decision, exact JSON schema, independent
Case-local execution of every standard/custom method actually declared by the
canonical JSON, absence of shared comparator semantics, and certification hash
freshness. Unused local standard-method branches are permitted, are not part of
the active contract, and need no acceptance coverage. A runtime PASS cannot
substitute for any of those static checks.

For a Case that used the optional Repair branch, verify the proposal and human
approval hashes before accepting any topology deviation. Recheck the strict
failure, protected-file invariants, semantic-equivalence rationale, known
limitations, fresh certification, and exact Ref/Candidate identity. Do not
reject the exact approved patch solely because it changes internal topology;
do reject a stale approval, changed protected artifact, additional Ref drift,
or public semantic change. Cases without a valid approval remain subject to
the original strict topology-preservation rule.

The anti-smuggling check is content- and reachability-based. It explicitly
looks for Fixture/input generation, CPU golden/Oracle logic, expected outputs,
comparator/evaluator logic, certification, RunConfig construction, profiling,
benchmark harnesses, test CLIs, dead copied modules, and cross-tree or
repository-root dependencies. A suspicious name alone is not a defect; every
match must be read in context. Canonical `__pycache__/` and `*.pyc` are allowed
and excluded from cleanliness, manifest, and identity comparisons.

All canonical Case, sealed, evaluator, environment, Skill, and workflow source
is read-only. Writable paths are limited to:

```text
<task-dir>/acceptance_workspaces/**
<task-dir>/acceptance_results/**
<task-dir>/handoff.md
```

Do not run `prepare-ref`, regenerate fixtures/certification, loosen comparator
rules, or repair canonical code. A defect is reported to its owning Stage 1-4;
shared or external failures belong to `infrastructure`. The workflow uses this
owner to automatically rework the Case and rerun all downstream stages. Never
select `accept` as the owner of a content defect found here.

Use `bench init`, never `bench fork`. Verify the Case binding and
`starting_point/` snapshot before running initial clean evaluate, all modes read
at execution time from `evaluator/profile_modes.py:PROFILE_MODES`, and final
clean evaluate. Commands sharing a device run strictly sequentially. A mode
passes only when correctness, result fields, and nonempty isolated diagnostics
pass; command exit alone is insufficient. An unavailable mode is
`UNSUPPORTED` only after an attempted command and concrete evidence.

Both clean commands use `phase=all`, require positive configured timing samples,
and are the correctness gates. `READY` with `Profiling: PARTIAL` is allowed only
when both clean runs pass and every non-passing profiling mode is explicitly
`UNSUPPORTED` with evidence. Any unclassified canonical file, unexplained
Ref/Candidate difference, omitted result Case/mode, required `NOT_RUN`, or
content defect prevents `PASS`.

The handoff must include four complete evidence tables: static check results,
canonical-file classification, Ref/Candidate file comparison, and one runtime
row for `clean`, every current profiling mode, and `final-clean`. Evidence cites
files/symbols, hashes/manifests, or commands plus result/artifact paths; generic
claims such as "inspected" are insufficient.

## Prompt

```text
Use $verify-pypto-case-v02-migration for <CASE_ID> as the final independent
acceptance gate. Read the shared contract, comparator policy, Stage 5
closure-audit document, complete handoff,
all prior stage results, all canonical files for every result Case, selected
source, and current evaluator/environment APIs. Treat canonical paths as
read-only and do not repair or regenerate them.

Independently recheck the migration decision and complete contract; inventory
and classify every canonical file; trace and inspect the full Ref/Candidate
closure for forbidden support code or hidden dependencies; prove normalized
Ref/Candidate manifest and byte identity with every allowed entry diff
explained. Ignore canonical __pycache__/ and *.pyc in these checks.

For each result Case, create a fresh bench-init workspace, verify its binding
and starting point, run initial phase-all clean evaluate, every mode currently
declared by PROFILE_MODES, and final phase-all clean evaluate sequentially.
Inspect result JSON fields and isolated artifacts, not only exit status.

Append complete static-check, file-classification, Ref/Candidate-comparison,
and runtime evidence tables. Name the owner of every defect. Return PASS only
when every result Case and required check is accounted for and satisfies the
Skill's final verdict rules.
```
