# Multi-file migration closure

This document defines the additional evidence required when any official,
Fixture, Ref/Candidate, or Oracle path reaches more than one local file or a
runtime resource. It supplements `CASE_MIGRATION_CONTRACT.md`; it does not
broaden any Stage write boundary.

Read and apply it when source inspection finds sibling imports, packages,
imports inside functions, dynamic imports, generated-source inputs, or local
file reads. A single-file Case records `single-file` for each closure and does
not need the detailed tables below.

## 1. Keep four closures separate

Build four independent closures. A file may appear in more than one only when
it is copied as a real file into each owning tree.

| closure | root | allowed responsibility |
| --- | --- | --- |
| official/Fixture | `official/` plus `fixture_builder.py` | byte-exact source dependencies and sealed Fixture construction |
| NPU Ref | `ref/` | complete Agent-editable NPU implementation |
| Candidate Seed | `candidate_seed/` | exact published snapshot of the NPU Ref |
| CPU Oracle | `oracle/` | independent sealed CPU correctness implementation |

Never satisfy one closure by importing another tree, another Case, a repository
checkout, or an accidental current working directory. Shared public fixed
configuration is the only intended cross-root Case import.

## 2. Stage 1 closure ledger

For every result Case, Stage 1 records one row for every reachable local path:

```text
closure | source path | destination-relative path | kind | discovered by |
import/resource spelling | load root | transformation | required by
```

`kind` is `python-module`, `package-marker`, `runtime-resource`, or
`generated-source-input`. `transformation` is exactly one of:

- `byte-exact`: preserved official files;
- `interface-adapt`: Ref/Oracle code requiring a documented current-API edit;
- `entry-rename-only`: the Ref entry when published as Candidate;
- `none`: already current and copied unchanged;
- `exclude`: generated debris or unreachable support code, with evidence.

The ledger must cover:

- ordinary, relative, conditional, and function-local imports;
- package `__init__.py` files and namespace assumptions;
- `importlib`, module-name strings, registries, and plugin lookups;
- files opened through `__file__`, relative paths, or the process CWD;
- tables, templates, source fragments, and code-generator inputs needed at
  import, compile, or execution time;
- symbols imported only for annotations or decorator execution;
- every sibling preset result Case, including deliberate per-preset differences.

Record the entry path, intended import root, and whether imports are package or
top-level. Do not defer destination layout or module-name decisions to Stage 3.

## 3. Global Case identity

Before approving result IDs, Stage 1 searches all canonical `case.json` files
and migration results. A result Case ID and canonical directory have one
owner. A new source Case must not silently overwrite an existing Case or reuse
an ID merely because the entry symbol and preset names resemble an older
workload.

The orchestrator independently rejects a Stage 1 `PASS` result when any
proposed ID is already claimed by another source migration's accepted
top-level result. This deterministic gate supplements, but does not replace,
the Stage 1 scan of canonical files and unfinished migration histories.

When an ID already exists:

- use a distinct, source-meaningful result ID for a different workload,
  mode, ABI, or independently inventoried revision;
- return `FAIL` if two histories claim the same ID and the intended identity
  cannot be established from source/inventory evidence;
- do not treat a requested new migration as authorization to replace an
  already accepted Case. Replacement requires an explicit workflow-level
  supersession mechanism and record; this workflow currently has none.

Stages 2-6 recheck that their result IDs are not owned by another active task.
An already-READY task does not make a conflicting overwrite acceptable.

## 4. Import and resource invariants

- Preserve the source-relative package layout when imports or resources depend
  on it. Do not flatten packages for convenience.
- Ref and Candidate use the same relative helper/resource layout. Only
  `ref_npu.py` may map to the Candidate module declared by `case.json`, with
  the smallest unavoidable import adjustment.
- Adapt historical absolute local imports inside Ref or Oracle only when needed
  for the current isolated loader. Preserve official imports byte-for-byte and
  handle only approved Fixture config aliasing in the Fixture adapter.
- Do not add repository roots to `PYTHONPATH`, mutate a global `sys.path` in
  canonical Case code, or rely on a module already present in `sys.modules`.
- Resource paths must be anchored to the owning tree, normally through
  `Path(__file__)`; CWD-relative behavior is accepted only when the official
  runtime contract deliberately requires it and the evaluator recreates it.
- Two sibling Cases must load correctly in either order. Common helper basenames
  must not cause one sibling to reuse another sibling's module object.

If current shared loaders cannot isolate a valid closure, report an
`infrastructure` blocker. Do not add a Case-specific `sys.path` or module-cache
workaround to shared evaluator code during migration.

## 5. Stage evidence

### Stage 2

- Copy every official dependency byte-for-byte and list each path and SHA-256
  in `source_provenance.json`.
- Prove that the Fixture adapter loads the intended official module/dependencies
  from `official/`, not a same-named repository module.
- Validate every result Case independently and then in a fresh process/order
  that could expose same-name module contamination.

### Stage 3

- Materialize exactly the approved Ref and Oracle ledger rows; do not copy an
  entire upstream directory.
- Record normalized Ref and Oracle manifests and the reason every path exists.
- Load Ref and Oracle through `common.load_ref`/`common.load_oracle` with a CWD
  outside their source directories and without repository-wide path injection.
- Exercise delayed imports and runtime resource reads on the real certification
  path. Import success alone is insufficient.
- Run each sibling's certification as a separate CLI process, sequentially.

### Stage 4

- Construct Candidate from the recorded Ref manifest, not from a glob that may
  include build output or stale files.
- After mapping the entry filename, require identical normalized manifests and
  byte-identical helpers/resources. Record the complete allowed entry diff.
- Verify the initialized workspace contains the same Candidate closure before
  clean/profile execution.

### Stages 5 and 6

- Rebuild the closure from imports and resource reads; do not trust the Stage 1
  ledger or equal file counts.
- Classify every non-bytecode path and reconcile it with both manifests.
- Test for cross-tree, cross-Case, repository-root, CWD, and module-cache
  dependencies.
- Treat missing required files, extra dead/support files, symlinks, and any
  unexplained Ref/Candidate difference as failures even when runtime passes.

## 6. Required handoff tables

Multi-file Stages append these tables with concrete paths and hashes:

```text
Closure ledger
closure | source path | destination-relative path | kind | discovered by |
import/resource spelling | load root | transformation | required by

Manifest reconciliation
Ref path | Candidate path | SHA-256/evidence |
identical/allowed-entry-diff/missing/extra | explanation

Isolation checks
Case | loader/command | CWD/import roots | sibling order | observed module/resource path | result
```

No row may summarize an unexplained directory as `helpers/**`. Every required
file is listed individually. Generated `__pycache__/` and `*.pyc` remain
permitted exclusions.
