#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_20260925.log"
exec >>"$LOG" 2>&1

echo "===== serial migration started $(date -Is) ====="
set +e

bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.decode_attention_csa \
  --rework owner
CSA_EXIT=$?
echo "CSA_REWORK_EXIT=$CSA_EXIT"

bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.hc_pre_v2_decode \
  --rework owner
HC_PRE_EXIT=$?
echo "HC_PRE_REWORK_EXIT=$HC_PRE_EXIT"

bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.legacy_decode_qkv_proj_rope_t16 \
  --rework owner
LEGACY_EXIT=$?
echo "LEGACY_REWORK_EXIT=$LEGACY_EXIT"

bash benchmarks/mig_workflow/run_migrations.sh \
  --cases-file benchmarks/mig_workflow/serial_queue_20260925.txt \
  --limit 7 --resume
QUEUE_EXIT=$?
echo "NEW_QUEUE_EXIT=$QUEUE_EXIT"
echo "===== serial migration finished $(date -Is) ====="
exit "$QUEUE_EXIT"
