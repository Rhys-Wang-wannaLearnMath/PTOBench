#!/usr/bin/env bash
set -u
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
cases=(
  deepseek_v4.mtp_projection
  deepseek_v4.prefill_attention_hca
  deepseek_v4.prefill_attention_swa
  deepseek_v4.prefill_compressor_ratio128
  deepseek_v4.prefill_compressor_ratio4
  deepseek_v4.prefill_indexer
  deepseek_v4.prefill_indexer_compressor
  deepseek_v4.prefill_layer_ep2_csa
)
for case_id in "${cases[@]}"; do
  safe="${case_id//./__}"
  if [[ -f "benchmarks/mig_data/runs/$safe/01-analyze/result.json" ]]; then
    mode=(--resume)
  else
    mode=(--rework analyze)
  fi
  echo "===== REQUEUE $case_id ${mode[*]} ====="
  bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" "${mode[@]}" || \
    echo "FAILED $case_id"
done
