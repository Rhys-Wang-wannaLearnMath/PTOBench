# Stage 3: implement execution and certify Ref

Skill: `implement-and-certify-pypto-case-v02`

Implement the NPU Ref, independent CPU Oracle, and thin Case evaluator, then run
`bench prepare-ref` for every result Case. Implementation and certification are
one stage because certification is the direct test of these three components.
Use `bench prepare-ref --regenerate-fixtures` when the Fixture builder, public
input contract, or seed policy changed. A comparator-only recertification must
reuse existing complete Fixture inputs and omit that flag.

Writable paths:

```text
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/ref/**
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/oracle/**
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/evaluate.py
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/fixtures/**
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/ref_performance.json
benchmarks/pypto_lib_bench-v0.2/sealed_assets/<family>/<case>/certification.json
benchmarks/pypto_lib_bench-v0.2/cases/<family>/<case>/case.json  # narrow runtime/environment interface amendments only
benchmarks/pypto_lib_bench-v0.2/environments/<case-profile>.json  # only this Case's new profile
<task-dir>/handoff.md
```

The public contract is read-only except for the explicitly allowed narrow
`case.json.runtime` or environment-reference amendment. Official files and
Candidate Seed are read-only. Shared evaluator files, existing shared
environment profiles and unrelated Cases are forbidden. If execution against
the current official stack proves that the Case needs a Case-specific runtime
override or a new environment profile, this stage may make that narrow
amendment, document the evidence, and rerun certification. It may not change
the workload contract or modify a profile used by another Case. A
shape/ABI/algorithm/configuration decision belongs back to Stage 1/2.

Use the shared workflow/load helpers, preserve complete multi-file closures,
keep the Oracle independent, and run `prepare-ref`. If certification exposes a
contract or Fixture error, return it to Stage 2. Do not widen tolerances or edit
public config. If the error is in Ref/Oracle/evaluator code, fix it within this
stage and rerun certification.

For a multi-file closure, apply `MULTI_FILE_MIGRATION.md`: materialize only
approved ledger rows, record normalized Ref/Oracle manifests, verify delayed
imports and resources from a non-source CWD, and certify siblings in separate
sequential CLI processes. Import success alone is not closure evidence.

Each result Case's `evaluate.py` must itself read `public/comparator.json`,
strictly validate top-level/output/method fields and numeric ranges, and
implement every standard or Stage-1-approved `custom` method actually declared
by that Case locally. A standard method absent from the canonical JSON is not
required and need not be tested; an existing unused standard-method branch may
remain, but must not affect callback selection or PASS/FAIL. Undeclared custom
behavior is forbidden. Do not call a common comparator factory or add one to
shared infrastructure. Prove that JSON output names, methods, and fields match
`case.json`, every declared value controls execution, no runner fallback or
Python constant overrides the public policy, and `certification.json` contains
the current comparator SHA-256. A comparator failure does not authorize
changing Stage 1's decision or Stage 2's JSON; return such a defect to its
owner.

The Ref tree must contain the complete future Agent-editable implementation,
including required packages and non-Python resources, while excluding logs,
dumps and generated build output. Canonical `__pycache__/` and `*.pyc` files
are allowed and ignored by closure checks. Exercise it through `common.load_ref` so
hidden repository-root or working-directory dependencies fail now. Record any
profiling-sensitive runner/RunConfig behavior for Stage 4.

Prefer the smallest interface-only patch for v0.1-to-current changes: renamed
imports, arguments, runner calls, TensorSpec/ScalarSpec construction, or
accepted RunConfig field/type. Preserve algorithm, topology, shapes/layouts,
dtypes, state, input distribution and comparator semantics. Record old/new
symbols and a short equivalence rationale in the handoff. Validate every
`case.json.runtime` field against the installed RunConfig signature; do not pass
obsolete or invented fields.

Strict Stage 3 must not use the optional Repair exception. If preserving the
selected algorithm and topology cannot pass Ref correctness, return the normal
`FAIL` with `owner_stage: implement-certify`, preserve the failing evidence,
and state whether the failure is a reproducible NPU Ref correctness failure
eligible for human consideration. Do not start Repair, loosen its constraints,
or continue to Stage 4. The human-only branch is defined separately in
`04_repair_and_recertify.md`.

## Prompt

```text
Use $implement-and-certify-pypto-case-v02 for <CASE_ID>. Read the shared
contract, comparator policy, and handoff. Implement only each approved Case's
ref/, oracle/, evaluate.py and
generated certification assets. A narrow amendment to this Case's `case.json`
runtime/environment reference or its new Case-specific environment JSON is
allowed only when current-stack execution proves it necessary. Do not create
Candidate Seed, edit other public/official files, or modify existing shared
environment profiles. Run bench prepare-ref for every result Case. Fix only
defects owned by this stage; report contract/Fixture defects back to Stage 2.
Append all commands and results to the handoff.
```
