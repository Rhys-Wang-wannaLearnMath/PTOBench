# Stage 1: analyze and decide

Skill: `analyze-pypto-case-v02-migration`

Read the complete common migration contract and inspect the actual source Case.
This stage makes every design decision needed by later sessions but creates no
v0.2 Case files.

If any closure contains multiple files or runtime resources, read and apply
`MULTI_FILE_MIGRATION.md`: produce its per-file ledger, fix import/resource
roots and destination layout, and check every proposed result ID globally.
Distinct inventoried workloads may not overwrite an existing canonical Case.

Writable path:

```text
benchmarks/mig_data/runs/<source-case>/handoff.md
```

Everything else is read-only.

The handoff must identify the selected official source, workload, split/no-split
decision, result Case IDs, entry call closure, ABI, state, scalar arguments,
fixed config, comparator source, Fixture builder/seed/input bindings, environment,
topology, Ref/Candidate/Oracle dependency closures, and unresolved risks.
For every result Case, follow `COMPARATOR_POLICY.md`: fix the current upstream
default-branch commit, compare the selected and latest comparator semantics,
group coupled changes, decide `ADOPT` or `KEEP_SELECTED` for every group, and
record the complete required table and final per-output rules. Inspect a
removed workload's last revision and current successor without treating a
related model as automatically applicable. This stage owns every comparator
applicability decision; later stages may not infer one from runtime results.
For each final rule, specify the complete Case-local evaluator behavior Stage 3
must implement and test for the methods actually declared by that Case. Do not
require unrelated standard methods, although an evaluator may retain them as
inactive local compatibility code. Do not propose a shared comparator factory,
registry, method dispatcher, or family helper; the uniform JSON schema does not
make execution a common-layer responsibility.
It must also state whether the official source imports a real, separate
historical config file. Embedded constants mean the source is self-contained;
they must not be proposed as an extracted or synthesized `original_config.py`.
For sources with named presets, include a complete preset coverage matrix with
definition path, default binding, entry/builder/runner evidence, resulting ABI,
and `split`, `exclude`, or `blocked` for every preset. A default import of one
preset does not exclude other complete official presets that the same source
can instantiate through configuration-only binding. Give all resulting sibling
Cases explicit, symmetric preset suffixes such as `_demo`, `_flash`, and `_pro`;
do not preserve an unsuffixed ID only for the source's default FLASH binding.
For multi-file code, classify every reachable file as editable implementation,
fixed public contract, sealed validation code, or generated debris, and record
package/resource/dynamic-import paths. Also record the full supported profiling
set from `evaluator/profile_modes.py:PROFILE_MODES` and Case-specific risks for
each mode.
Do not summarize a directory as copied helpers; list every path, discovery
edge, load root, permitted transformation, and result Case that requires it.
Inspect the current installed RunConfig signature and record every Case-specific
runtime field needed, plus whether an existing environment profile fits. If not,
specify the new profile's name, setup scripts, Python, platform/device, exports
and benchmark defaults.

For fixed values derived in source config, record both the in-scope operands
and the source expression. Do not hand Stage 2 only a folded literal when the
relationship carries Case meaning, and do not include unrelated workload
branches merely because they share the same config file.

The stage passes only when downstream sessions can implement the Case without
guessing any evaluation-contract decision.

## Prompt

```text
Use $analyze-pypto-case-v02-migration for <CASE_ID>. Read the shared migration
contract and comparator policy, then inspect the real v0.1, selected official,
and current upstream sources.
Write only <TASK_DIR>/handoff.md. Decide the exact result Case IDs and document
the full ABI, config, fixture, comparator reconciliation table and final rules,
state, dependencies and environment.
Do not create or edit v0.2 Case files. Return PASS only when no contract choice
is left for the implementation stages to guess.
```
