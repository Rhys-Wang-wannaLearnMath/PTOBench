#!/usr/bin/env python3
"""Normalize and validate one migration stage's structured result."""

from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
from typing import Any


def fail(path: str, message: str) -> None:
    raise ValueError(f"{path}: {message}")


def type_matches(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    fail("$schema", f"unsupported validator type {expected!r}")


def validate_schema(value: Any, schema: dict[str, Any], path: str = "$") -> None:
    expected_type = schema.get("type")
    if expected_type is not None and not type_matches(value, expected_type):
        fail(path, f"expected {expected_type}, got {type(value).__name__}")

    if "enum" in schema and value not in schema["enum"]:
        fail(path, f"{value!r} is not one of {schema['enum']!r}")

    if isinstance(value, dict):
        properties = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                fail(path, f"missing required property {key!r}")
        if schema.get("additionalProperties") is False:
            extras = sorted(set(value) - set(properties))
            if extras:
                fail(path, f"unexpected properties {extras!r}")
        for key, item in value.items():
            if key in properties:
                validate_schema(item, properties[key], f"{path}.{key}")

    if isinstance(value, list) and "items" in schema:
        for index, item in enumerate(value):
            validate_schema(item, schema["items"], f"{path}[{index}]")


def parse_model_output(text: str) -> Any:
    stripped = text.strip()
    fence = chr(96) * 3
    if stripped.startswith(fence):
        lines = stripped.splitlines()
        if len(lines) < 3 or lines[-1].strip() != fence:
            fail("$", "unterminated Markdown fence")
        if lines[0].strip() not in {fence, fence + "json"}:
            fail("$", f"unsupported Markdown fence {lines[0]!r}")
        stripped = "\n".join(lines[1:-1]).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError as original:
        start = stripped.find("{")
        if start <= 0 or "{" in stripped[:start]:
            fail(
                "$",
                f"invalid JSON at line {original.lineno}, column "
                f"{original.colno}: {original.msg}",
            )
        try:
            value, end = json.JSONDecoder().raw_decode(stripped, start)
        except json.JSONDecodeError as exc:
            fail(
                "$",
                f"invalid JSON object at line {exc.lineno}, column "
                f"{exc.colno}: {exc.msg}",
            )
        if stripped[end:].strip():
            fail("$", "non-whitespace content follows the JSON object")
        return value


def profile_modes(schema_path: Path) -> list[str]:
    path = (
        schema_path.parent.parent
        / "pypto_lib_bench-v0.2"
        / "evaluator"
        / "profile_modes.py"
    )
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(
            isinstance(target, ast.Name) and target.id == "PROFILE_MODES"
            for target in targets
        ):
            value = ast.literal_eval(node.value)
            if not isinstance(value, dict) or not all(
                isinstance(key, str) for key in value
            ):
                fail("$.profiling", "PROFILE_MODES is not a string-keyed object")
            return list(value)
    fail("$.profiling", f"PROFILE_MODES not found in {path}")


def accepted_result_case_owners(schema_path: Path) -> dict[str, set[str]]:
    """Return source migrations that already accepted each result Case ID."""
    runs_root = schema_path.parent.parent / "mig_data" / "runs"
    owners: dict[str, set[str]] = {}
    if not runs_root.is_dir():
        return owners

    for path in runs_root.glob("*/result.json"):
        try:
            result = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if result.get("outcome") != "PASS":
            continue
        source_case = result.get("case_id")
        result_cases = result.get("result_case_ids")
        if not isinstance(source_case, str) or not isinstance(result_cases, list):
            continue
        for result_case in result_cases:
            if isinstance(result_case, str):
                owners.setdefault(result_case, set()).add(source_case)
    return owners


def validate_analyze_case_ownership(
    result: dict[str, Any], expected_case: str, schema_path: Path
) -> None:
    """Prevent Stage 1 from reusing IDs accepted for another source migration."""
    owners = accepted_result_case_owners(schema_path)
    collisions = {
        result_case: sorted(owners[result_case] - {expected_case})
        for result_case in result["result_case_ids"]
        if result_case in owners and owners[result_case] - {expected_case}
    }
    if collisions:
        details = ", ".join(
            f"{result_case!r} owned by {source_cases!r}"
            for result_case, source_cases in sorted(collisions.items())
        )
        fail(
            "$.result_case_ids",
            "Stage 1 result Case ID collision with an accepted source migration: "
            + details,
        )


def validate_semantics(
    result: dict[str, Any],
    expected_case: str,
    expected_stage: str,
    modes: list[str],
    schema_path: Path,
) -> None:
    if result["case_id"] != expected_case:
        fail("$.case_id", f"expected {expected_case!r}, got {result['case_id']!r}")
    if result["stage"] != expected_stage:
        fail("$.stage", f"expected {expected_stage!r}, got {result['stage']!r}")

    for field in ("handoff", "summary"):
        if not result[field].strip():
            fail(f"$.{field}", "must be nonempty")
    if not result["checks"]:
        fail("$.checks", "must contain evidence for required stage checks")
    for collection in ("checks", "profiling"):
        fields = ("name", "evidence") if collection == "checks" else ("mode", "evidence")
        for index, item in enumerate(result[collection]):
            for field in fields:
                if not item[field].strip():
                    fail(f"$.{collection}[{index}].{field}", "must be nonempty")

    actual_modes = [item["mode"] for item in result["profiling"]]
    if actual_modes != modes:
        fail("$.profiling", f"expected modes in order {modes!r}, got {actual_modes!r}")

    outcome = result["outcome"]
    owner = result["owner_stage"]
    if outcome == "PASS":
        if owner != "none":
            fail("$.owner_stage", "PASS requires owner_stage 'none'")
        if result["blockers"]:
            fail("$.blockers", "PASS requires an empty blockers array")
        if not result["result_case_ids"]:
            fail("$.result_case_ids", "PASS requires at least one result Case")
        failed = [
            item["name"]
            for item in result["checks"]
            if item["status"] in {"FAIL", "NOT_RUN"}
        ]
        if failed:
            fail("$.checks", f"PASS cannot contain FAIL/NOT_RUN checks: {failed!r}")
        if expected_stage in {"publish", "accept"}:
            not_run = [
                item["mode"]
                for item in result["profiling"]
                if item["status"] == "NOT_RUN"
            ]
            if not_run:
                fail(
                    "$.profiling",
                    f"PASS {expected_stage} cannot leave modes NOT_RUN: {not_run!r}",
                )
        if expected_stage == "analyze":
            validate_analyze_case_ownership(result, expected_case, schema_path)
    elif outcome == "BLOCKED":
        if owner != "infrastructure":
            fail("$.owner_stage", "BLOCKED requires owner_stage 'infrastructure'")
        if not result["blockers"]:
            fail("$.blockers", "BLOCKED requires blocker evidence")
    elif owner == "none":
        fail("$.owner_stage", "FAIL requires a content owner or infrastructure")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--schema", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--case", required=True)
    parser.add_argument("--stage", required=True)
    args = parser.parse_args()

    schema = json.loads(args.schema.read_text(encoding="utf-8"))
    result = parse_model_output(args.input.read_text(encoding="utf-8"))
    validate_schema(result, schema)
    validate_semantics(
        result,
        args.case,
        args.stage,
        profile_modes(args.schema),
        args.schema,
    )
    args.output.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as exc:
        raise SystemExit(f"invalid migration stage result: {exc}")
