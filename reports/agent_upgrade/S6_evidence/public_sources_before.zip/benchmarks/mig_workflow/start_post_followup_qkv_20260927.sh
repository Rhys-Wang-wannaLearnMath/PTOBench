#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_post_followup_qkv_20260927.log"
exec >>"$LOG" 2>&1

echo "===== post-follow-up QKV waiter $(date -Is) ====="
# Keep this continuation strictly serial with the existing follow-up queue.
while pgrep -f '[s]tart_followup_20260927.sh' >/dev/null \
   || pgrep -f '[r]un_migrations.sh --case deepseek_v3_2.deepseek_v3_2_decode_front_scope3' >/dev/null; do
  sleep 20
done

echo "Existing follow-up queue is idle; continuing approved QKV repair $(date -Is)"
bash benchmarks/mig_workflow/run_migrations.sh \
  --case deepseek_v4.prefill_qkv_proj_rope_v1 --approve-repair
rc=$?
echo "deepseek_v4.prefill_qkv_proj_rope_v1 RESUME_EXIT=$rc"
exit "$rc"
