#!/usr/bin/env bash
set -u
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
cases=(
  deepseek_v4.moe_ep_ep2
  deepseek_v4.moe_router
  deepseek_v4.prefill_qkv_proj_rope_v2_decode
  deepseek_v4.prefill_qkv_proj_rope_v2_prefill
)
for case_id in "${cases[@]}"; do
  echo "===== REQUEUE $case_id ====="
  bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --rework analyze || \
    echo "FAILED $case_id"
done
