#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
RUN_ROOT="$ROOT/benchmarks/mig_data/runs"
LOG="$ROOT/benchmarks/mig_data/serial_retry_codex_01580_20260928.log"
export CODEX_BIN="${CODEX_BIN:-/tmp/codex-cli-01580-20260928/node_modules/.bin/codex}"
cd "$ROOT"

exec > >(tee -a "$LOG") 2>&1
echo "STARTED $(date -Is)"
echo "CODEX_BIN=$CODEX_BIN"
"$CODEX_BIN" --version

mapfile -t run_dirs < <(
  while IFS= read -r status_file; do
    status="$(<"$status_file")"
    case "$status" in
      API_FAILED|CODEX_SESSION_FAILED|EXEC_FAILED)
        printf '%s\n' "${status_file%/status}" ;;
    esac
  done < <(find "$RUN_ROOT" -mindepth 2 -maxdepth 2 -type f -name status | sort)
)

priority="deepseek_v4__decode_compressor_ratio128"
ordered=()
for task_dir in "${run_dirs[@]}"; do
  [[ "${task_dir##*/}" == "$priority" ]] && ordered+=("$task_dir")
done
for task_dir in "${run_dirs[@]}"; do
  [[ "${task_dir##*/}" != "$priority" ]] && ordered+=("$task_dir")
done

echo "SELECTED ${#ordered[@]} infrastructure-failed cases"
failed=0
for task_dir in "${ordered[@]}"; do
  safe="${task_dir##*/}"
  case_id="${safe/__/.}"
  echo "===== RETRY $case_id ====="
  if ! bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume; then
    echo "FAILED $case_id"
    failed=1
  fi
done
echo "FINISHED $(date -Is) failed=$failed"
exit "$failed"
