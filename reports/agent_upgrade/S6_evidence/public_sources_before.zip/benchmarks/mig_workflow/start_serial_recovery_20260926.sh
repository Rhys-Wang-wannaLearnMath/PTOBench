#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"
LOG="$ROOT/benchmarks/mig_data/serial_recovery_20260926.log"
exec >>"$LOG" 2>&1

echo "===== serial recovery started $(date -Is) ====="
set +e

QUEUE_EXIT=0
run_resume() {
  local case_id="$1"
  bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume
  local rc=$?
  echo "${case_id} RESUME_EXIT=$rc"
  ((rc == 0)) || QUEUE_EXIT=1
}
run_rework() {
  local case_id="$1"
  bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --rework owner
  local rc=$?
  echo "${case_id} REWORK_EXIT=$rc"
  ((rc == 0)) || QUEUE_EXIT=1
}

# Keep one case in flight at a time. READY cases are checked without archiving;
# non-PASS cases restart at their recorded owning stage.
run_resume deepseek_v4.prefill_hc_pre
run_rework deepseek_v4.prefill_sparse_attn
run_rework deepseek_v4.qkv_proj_rope_compat
run_rework deepseek_v4.rmsnorm_decode
run_resume deepseek_v4.sparse_attn
run_rework qwen3_14b.prefill_fwd
echo "RECOVERY_QUEUE_EXIT=$QUEUE_EXIT"
echo "===== serial recovery finished $(date -Is) ====="
exit "$QUEUE_EXIT"
