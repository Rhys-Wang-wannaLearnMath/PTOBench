#!/usr/bin/env bash
set -u
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
export MIGRATION_GIT_PROXY=""
# Keep a second invocation from advancing another Case alongside this worker.
exec 9>benchmarks/mig_workflow/.serial_queue.lock
flock -n 9 || { echo "Another serial migration queue is already running" >&2; exit 1; }
mapfile -t cases < <(python3 - <<'PY'
from pathlib import Path
wanted={'API_FAILED','CODEX_SESSION_FAILED','EXEC_FAILED','BLOCKED'}
selected=[]
for p in sorted(Path('benchmarks/mig_data/runs').glob('*/status')):
    lines=p.read_text(errors='replace').strip().splitlines()
    if lines and lines[0] in wanted:
        selected.append((lines[0]=='BLOCKED',p.parent.name.replace('__','.')))
# Recover transport/session failures before content-blocked reworks.
for _, case_id in sorted(selected):
    print(case_id)
PY
)
echo "Selected ${#cases[@]} infrastructure-failed Case(s)"
for case_id in "${cases[@]}"; do
  safe="${case_id//./__}"
  status_file="benchmarks/mig_data/runs/$safe/status"
  status="$(head -1 "$status_file")"
  if [[ "$status" == BLOCKED ]]; then
    owner_stage="$(python3 - "$safe" <<'PY'
import json, sys
from pathlib import Path
root=Path('benchmarks/mig_data/runs')/sys.argv[1]
for result in sorted(root.glob('*/result.json'), reverse=True):
    try:
        data=json.loads(result.read_text())
    except Exception:
        continue
    owner=data.get('owner_stage')
    if owner in {'analyze','contract','implement-certify','publish','closure-audit','accept'}:
        print(owner)
        break
PY
    )"
    if [[ -n "$owner_stage" ]]; then
      mode=(--rework "$owner_stage")
    else
      mode=(--rework analyze)
    fi
  elif [[ -f "benchmarks/mig_data/runs/$safe/01-analyze/result.json" ]]; then
    mode=(--resume)
  else
    mode=(--rework analyze)
  fi
  echo "===== REQUEUE $case_id ${mode[*]} ====="
  bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" "${mode[@]}" || \
    echo "FAILED $case_id"
done

# Consume explicit additions after the initial snapshot, in this same worker.
# The running Bash reads this section once the current loop finishes.
shopt -s nullglob
for pending_file in benchmarks/mig_workflow/pending_serial_20260929/*.case; do
  read -r case_id <"$pending_file"
  if [[ ! "$case_id" =~ ^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$ ]]; then
    echo "Invalid pending Case ID in $pending_file" >&2
    continue
  fi
  safe="${case_id//./__}"
  status="$(head -1 "benchmarks/mig_data/runs/$safe/status")"
  if [[ "$status" != READY ]]; then
    echo "===== REQUEUE ADDED $case_id --resume ====="
    bash benchmarks/mig_workflow/run_migrations.sh --case "$case_id" --resume || \
      echo "FAILED $case_id"
  fi
  mkdir -p benchmarks/mig_workflow/pending_serial_20260929/processed
  mv -- "$pending_file" benchmarks/mig_workflow/pending_serial_20260929/processed/
done
